﻿Public Class AdminEnroll
    Private Sub AdminEnroll_Load(sender As Object, e As EventArgs) Handles Me.Load
        ShowPanel(AdminEnrollStud)
        HighlightActiveButton(StudBtn)
    End Sub

    Private Sub StudBtn_Click(sender As Object, e As EventArgs) Handles StudBtn.Click
        ShowPanel(AdminEnrollStud)
        HighlightActiveButton(StudBtn)
    End Sub

    Private Sub ProfBtn_Click(sender As Object, e As EventArgs) Handles ProfBtn.Click
        ShowPanel(AdminEnrollProf)
        HighlightActiveButton(ProfBtn)
    End Sub

    Private Sub ShowPanel(panelToShow As Form)
        AdminEnrollStud.Hide()
        AdminEnrollProf.Hide()

        panelToShow.TopLevel = False
        panelToShow.Parent = EnrollPanel
        panelToShow.Dock = DockStyle.Fill
        panelToShow.Show()
    End Sub

    Private Sub HighlightActiveButton(activeButton As Button)
        StudBtn.BackColor = Color.Transparent
        ProfBtn.BackColor = Color.Transparent

        activeButton.BackColor = Color.Gray
    End Sub

    Private Sub EnrollPanel_Paint(sender As Object, e As PaintEventArgs) Handles EnrollPanel.Paint

    End Sub
End Class