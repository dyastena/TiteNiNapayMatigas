﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StudentForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel2 = New Panel()
        Label1 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        Panel1 = New Panel()
        Button2 = New Button()
        Button1 = New Button()
        Panel4 = New Panel()
        Label18 = New Label()
        TextBox1 = New TextBox()
        Label15 = New Label()
        Label16 = New Label()
        Label17 = New Label()
        Label13 = New Label()
        Label14 = New Label()
        Label10 = New Label()
        Label6 = New Label()
        Label9 = New Label()
        Label7 = New Label()
        DataGridView1 = New DataGridView()
        Label11 = New Label()
        Label12 = New Label()
        Label8 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Panel2.SuspendLayout()
        Panel1.SuspendLayout()
        Panel4.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.FromArgb(CByte(167), CByte(141), CByte(120))
        Panel2.Controls.Add(Label1)
        Panel2.Controls.Add(Label3)
        Panel2.Controls.Add(Label2)
        Panel2.Location = New Point(12, 12)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(1900, 71)
        Panel2.TabIndex = 10
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Cascadia Mono", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(745, 17)
        Label1.Name = "Label1"
        Label1.Size = New Size(273, 37)
        Label1.TabIndex = 8
        Label1.Text = "Report Of Grades"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(36, 23)
        Label3.Name = "Label3"
        Label3.Size = New Size(79, 20)
        Label3.TabIndex = 7
        Label3.Text = "Student"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Cascadia Mono", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(1650, 9)
        Label2.Name = "Label2"
        Label2.Size = New Size(0, 37)
        Label2.TabIndex = 6
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(190), CByte(181), CByte(169))
        Panel1.Controls.Add(Button2)
        Panel1.Controls.Add(Button1)
        Panel1.Controls.Add(Panel4)
        Panel1.Location = New Point(87, 103)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1753, 940)
        Panel1.TabIndex = 11
        ' 
        ' Button2
        ' 
        Button2.Font = New Font("Cascadia Code", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button2.Location = New Point(885, 865)
        Button2.Name = "Button2"
        Button2.Size = New Size(807, 51)
        Button2.TabIndex = 6
        Button2.Text = "Print Report Card"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Cascadia Code", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(61, 865)
        Button1.Name = "Button1"
        Button1.Size = New Size(807, 51)
        Button1.TabIndex = 5
        Button1.Text = "Logout"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Panel4
        ' 
        Panel4.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        Panel4.Controls.Add(Label18)
        Panel4.Controls.Add(TextBox1)
        Panel4.Controls.Add(Label15)
        Panel4.Controls.Add(Label16)
        Panel4.Controls.Add(Label17)
        Panel4.Controls.Add(Label13)
        Panel4.Controls.Add(Label14)
        Panel4.Controls.Add(Label10)
        Panel4.Controls.Add(Label6)
        Panel4.Controls.Add(Label9)
        Panel4.Controls.Add(Label7)
        Panel4.Controls.Add(DataGridView1)
        Panel4.Controls.Add(Label11)
        Panel4.Controls.Add(Label12)
        Panel4.Controls.Add(Label8)
        Panel4.Controls.Add(Label4)
        Panel4.Controls.Add(Label5)
        Panel4.Location = New Point(61, 54)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(1631, 789)
        Panel4.TabIndex = 1
        ' 
        ' Label18
        ' 
        Label18.AutoSize = True
        Label18.Font = New Font("Courier New", 36F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label18.Location = New Point(1404, 74)
        Label18.Name = "Label18"
        Label18.Size = New Size(100, 65)
        Label18.TabIndex = 31
        Label18.Text = "00"
        ' 
        ' TextBox1
        ' 
        TextBox1.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        TextBox1.BorderStyle = BorderStyle.FixedSingle
        TextBox1.Enabled = False
        TextBox1.Font = New Font("Segoe UI", 72F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        TextBox1.Location = New Point(1366, 29)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(173, 167)
        TextBox1.TabIndex = 30
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Font = New Font("Courier New", 12F)
        Label15.Location = New Point(921, 130)
        Label15.Name = "Label15"
        Label15.Size = New Size(202, 22)
        Label15.TabIndex = 29
        Label15.Text = "ToBeFilledWithDB"
        ' 
        ' Label16
        ' 
        Label16.AutoSize = True
        Label16.Font = New Font("Courier New", 12F)
        Label16.Location = New Point(921, 87)
        Label16.Name = "Label16"
        Label16.Size = New Size(202, 22)
        Label16.TabIndex = 28
        Label16.Text = "ToBeFilledWithDB"
        ' 
        ' Label17
        ' 
        Label17.AutoSize = True
        Label17.Font = New Font("Courier New", 12F)
        Label17.Location = New Point(921, 45)
        Label17.Name = "Label17"
        Label17.Size = New Size(202, 22)
        Label17.TabIndex = 27
        Label17.Text = "ToBeFilledWithDB"
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Courier New", 12F)
        Label13.Location = New Point(304, 173)
        Label13.Name = "Label13"
        Label13.Size = New Size(202, 22)
        Label13.TabIndex = 26
        Label13.Text = "ToBeFilledWithDB"
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Font = New Font("Courier New", 12F)
        Label14.Location = New Point(304, 130)
        Label14.Name = "Label14"
        Label14.Size = New Size(202, 22)
        Label14.TabIndex = 25
        Label14.Text = "ToBeFilledWithDB"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Courier New", 12F)
        Label10.Location = New Point(304, 88)
        Label10.Name = "Label10"
        Label10.Size = New Size(202, 22)
        Label10.TabIndex = 24
        Label10.Text = "ToBeFilledWithDB"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Courier New", 12F)
        Label6.Location = New Point(304, 45)
        Label6.Name = "Label6"
        Label6.Size = New Size(202, 22)
        Label6.TabIndex = 23
        Label6.Text = "ToBeFilledWithDB"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Courier New", 12F, FontStyle.Bold)
        Label9.Location = New Point(713, 131)
        Label9.Name = "Label9"
        Label9.Size = New Size(202, 23)
        Label9.TabIndex = 22
        Label9.Text = "Section        :"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Courier New", 12F, FontStyle.Bold)
        Label7.Location = New Point(713, 45)
        Label7.Name = "Label7"
        Label7.Size = New Size(202, 23)
        Label7.TabIndex = 21
        Label7.Text = "Course         :"
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(61, 233)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowHeadersWidth = 51
        DataGridView1.Size = New Size(1506, 503)
        DataGridView1.TabIndex = 20
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Courier New", 12F, FontStyle.Bold)
        Label11.Location = New Point(96, 173)
        Label11.Name = "Label11"
        Label11.Size = New Size(202, 23)
        Label11.TabIndex = 17
        Label11.Text = "Semester       :"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Courier New", 12F, FontStyle.Bold)
        Label12.Location = New Point(713, 88)
        Label12.Name = "Label12"
        Label12.Size = New Size(202, 23)
        Label12.TabIndex = 16
        Label12.Text = "Year Level     :"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Courier New", 12F, FontStyle.Bold)
        Label8.Location = New Point(96, 131)
        Label8.Name = "Label8"
        Label8.Size = New Size(202, 23)
        Label8.TabIndex = 13
        Label8.Text = "Academic Year  :"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Courier New", 12F, FontStyle.Bold)
        Label4.Location = New Point(96, 88)
        Label4.Name = "Label4"
        Label4.Size = New Size(202, 23)
        Label4.TabIndex = 9
        Label4.Text = "Student Name   :"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Courier New", 12F, FontStyle.Bold)
        Label5.Location = New Point(96, 45)
        Label5.Name = "Label5"
        Label5.Size = New Size(202, 23)
        Label5.TabIndex = 8
        Label5.Text = "Student No     :"
        ' 
        ' StudentForm
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(41), CByte(28), CByte(14))
        ClientSize = New Size(1924, 1055)
        Controls.Add(Panel1)
        Controls.Add(Panel2)
        FormBorderStyle = FormBorderStyle.None
        Name = "StudentForm"
        StartPosition = FormStartPosition.CenterScreen
        Text = "StudentForm"
        WindowState = FormWindowState.Maximized
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel1.ResumeLayout(False)
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label18 As Label
    Friend WithEvents TextBox1 As TextBox
End Class
