﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProfessorForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        TextBox1 = New TextBox()
        Panel1 = New Panel()
        Button1 = New Button()
        Panel4 = New Panel()
        rmrks = New TextBox()
        Panel3 = New Panel()
        Label14 = New Label()
        Label24 = New Label()
        fProjPer = New TextBox()
        fExamPer = New TextBox()
        Label23 = New Label()
        fExePer = New TextBox()
        fQuizPer = New TextBox()
        fAttPer = New TextBox()
        Label40 = New Label()
        Label41 = New Label()
        Label38 = New Label()
        Label39 = New Label()
        fProjOv = New TextBox()
        fExamOv = New TextBox()
        fExeOv = New TextBox()
        fQuizOv = New TextBox()
        fAttOv = New TextBox()
        fSub = New Button()
        fClr = New Button()
        fCmpt = New Button()
        fProj = New TextBox()
        fExam = New TextBox()
        Label11 = New Label()
        Label12 = New Label()
        fExe = New TextBox()
        fQuiz = New TextBox()
        fAtt = New TextBox()
        Label13 = New Label()
        Label15 = New Label()
        TextBox6 = New TextBox()
        semGrade = New TextBox()
        semPer = New TextBox()
        Label32 = New Label()
        sgLbl = New Label()
        Panel5 = New Panel()
        TextBox5 = New TextBox()
        Label6 = New Label()
        Label25 = New Label()
        Label20 = New Label()
        mtAtt = New TextBox()
        mtQuiz = New TextBox()
        mtExe = New TextBox()
        Label7 = New Label()
        Label8 = New Label()
        Label9 = New Label()
        Label22 = New Label()
        mtExam = New TextBox()
        mtRecitPer = New TextBox()
        mtCstud = New TextBox()
        mtCstudPer = New TextBox()
        mtRecit = New TextBox()
        mtExamPer = New TextBox()
        mtCmpt = New Button()
        Label21 = New Label()
        mtClr = New Button()
        mtExePer = New TextBox()
        mtSub = New Button()
        mtQuizPer = New TextBox()
        mtAttOv = New TextBox()
        mtAttPer = New TextBox()
        mtQuizOv = New TextBox()
        mtExeOv = New TextBox()
        mtExamOv = New TextBox()
        mtCstudOv = New TextBox()
        mtRecitOv = New TextBox()
        Label36 = New Label()
        Label34 = New Label()
        Label37 = New Label()
        Label35 = New Label()
        ssem = New ComboBox()
        fGrade = New Label()
        Label17 = New Label()
        mtGrade = New Label()
        CourseCodeTxb = New ComboBox()
        ssub = New TextBox()
        Label16 = New Label()
        Label1 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        Panel2 = New Panel()
        Label33 = New Label()
        Label5 = New Label()
        Label26 = New Label()
        Label27 = New Label()
        Label4 = New Label()
        Label10 = New Label()
        Panel1.SuspendLayout()
        Panel4.SuspendLayout()
        Panel3.SuspendLayout()
        Panel5.SuspendLayout()
        Panel2.SuspendLayout()
        SuspendLayout()
        ' 
        ' TextBox1
        ' 
        TextBox1.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        TextBox1.BorderStyle = BorderStyle.FixedSingle
        TextBox1.Enabled = False
        TextBox1.Font = New Font("Segoe UI", 72F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        TextBox1.Location = New Point(1352, 29)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(200, 167)
        TextBox1.TabIndex = 30
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(190), CByte(181), CByte(169))
        Panel1.Controls.Add(Button1)
        Panel1.Controls.Add(Panel4)
        Panel1.Location = New Point(78, 97)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1753, 940)
        Panel1.TabIndex = 13
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Cascadia Code", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(61, 865)
        Button1.Name = "Button1"
        Button1.Size = New Size(807, 51)
        Button1.TabIndex = 5
        Button1.Text = "Back"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Panel4
        ' 
        Panel4.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        Panel4.Controls.Add(Label10)
        Panel4.Controls.Add(Label27)
        Panel4.Controls.Add(Label26)
        Panel4.Controls.Add(Label5)
        Panel4.Controls.Add(Label4)
        Panel4.Controls.Add(rmrks)
        Panel4.Controls.Add(Panel3)
        Panel4.Controls.Add(semGrade)
        Panel4.Controls.Add(semPer)
        Panel4.Controls.Add(Label32)
        Panel4.Controls.Add(sgLbl)
        Panel4.Controls.Add(Panel5)
        Panel4.Controls.Add(ssem)
        Panel4.Controls.Add(fGrade)
        Panel4.Controls.Add(Label17)
        Panel4.Controls.Add(mtGrade)
        Panel4.Controls.Add(CourseCodeTxb)
        Panel4.Controls.Add(ssub)
        Panel4.Controls.Add(Label16)
        Panel4.Controls.Add(TextBox1)
        Panel4.Location = New Point(61, 50)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(1631, 789)
        Panel4.TabIndex = 1
        ' 
        ' rmrks
        ' 
        rmrks.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        rmrks.BorderStyle = BorderStyle.None
        rmrks.Font = New Font("Courier New", 12F, FontStyle.Bold)
        rmrks.Location = New Point(1359, 172)
        rmrks.Margin = New Padding(3, 4, 3, 4)
        rmrks.Name = "rmrks"
        rmrks.Size = New Size(186, 23)
        rmrks.TabIndex = 119
        rmrks.TextAlign = HorizontalAlignment.Center
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = SystemColors.Window
        Panel3.BorderStyle = BorderStyle.FixedSingle
        Panel3.Controls.Add(Label14)
        Panel3.Controls.Add(Label24)
        Panel3.Controls.Add(fProjPer)
        Panel3.Controls.Add(fExamPer)
        Panel3.Controls.Add(Label23)
        Panel3.Controls.Add(fExePer)
        Panel3.Controls.Add(fQuizPer)
        Panel3.Controls.Add(fAttPer)
        Panel3.Controls.Add(Label40)
        Panel3.Controls.Add(Label41)
        Panel3.Controls.Add(Label38)
        Panel3.Controls.Add(Label39)
        Panel3.Controls.Add(fProjOv)
        Panel3.Controls.Add(fExamOv)
        Panel3.Controls.Add(fExeOv)
        Panel3.Controls.Add(fQuizOv)
        Panel3.Controls.Add(fAttOv)
        Panel3.Controls.Add(fSub)
        Panel3.Controls.Add(fClr)
        Panel3.Controls.Add(fCmpt)
        Panel3.Controls.Add(fProj)
        Panel3.Controls.Add(fExam)
        Panel3.Controls.Add(Label11)
        Panel3.Controls.Add(Label12)
        Panel3.Controls.Add(fExe)
        Panel3.Controls.Add(fQuiz)
        Panel3.Controls.Add(fAtt)
        Panel3.Controls.Add(Label13)
        Panel3.Controls.Add(Label15)
        Panel3.Controls.Add(TextBox6)
        Panel3.Location = New Point(839, 308)
        Panel3.Margin = New Padding(3, 4, 3, 4)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(751, 384)
        Panel3.TabIndex = 122
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label14.Location = New Point(43, 174)
        Label14.Name = "Label14"
        Label14.Size = New Size(164, 21)
        Label14.TabIndex = 138
        Label14.Text = "Quiz         :"
        ' 
        ' Label24
        ' 
        Label24.AutoSize = True
        Label24.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label24.Location = New Point(671, 89)
        Label24.Name = "Label24"
        Label24.Size = New Size(21, 21)
        Label24.TabIndex = 134
        Label24.Text = "%"
        ' 
        ' fProjPer
        ' 
        fProjPer.BackColor = Color.GhostWhite
        fProjPer.BorderStyle = BorderStyle.None
        fProjPer.Enabled = False
        fProjPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fProjPer.Location = New Point(657, 174)
        fProjPer.Margin = New Padding(3, 4, 3, 4)
        fProjPer.MaxLength = 3
        fProjPer.Name = "fProjPer"
        fProjPer.Size = New Size(46, 20)
        fProjPer.TabIndex = 133
        fProjPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' fExamPer
        ' 
        fExamPer.BackColor = Color.GhostWhite
        fExamPer.BorderStyle = BorderStyle.None
        fExamPer.Enabled = False
        fExamPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fExamPer.Location = New Point(656, 118)
        fExamPer.Margin = New Padding(3, 4, 3, 4)
        fExamPer.MaxLength = 3
        fExamPer.Name = "fExamPer"
        fExamPer.Size = New Size(46, 20)
        fExamPer.TabIndex = 132
        fExamPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label23
        ' 
        Label23.AutoSize = True
        Label23.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label23.Location = New Point(335, 86)
        Label23.Name = "Label23"
        Label23.Size = New Size(21, 21)
        Label23.TabIndex = 131
        Label23.Text = "%"
        ' 
        ' fExePer
        ' 
        fExePer.BackColor = Color.GhostWhite
        fExePer.BorderStyle = BorderStyle.None
        fExePer.Enabled = False
        fExePer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fExePer.Location = New Point(323, 230)
        fExePer.Margin = New Padding(3, 4, 3, 4)
        fExePer.MaxLength = 3
        fExePer.Name = "fExePer"
        fExePer.Size = New Size(46, 20)
        fExePer.TabIndex = 130
        fExePer.TextAlign = HorizontalAlignment.Center
        ' 
        ' fQuizPer
        ' 
        fQuizPer.BackColor = Color.GhostWhite
        fQuizPer.BorderStyle = BorderStyle.None
        fQuizPer.Enabled = False
        fQuizPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fQuizPer.Location = New Point(323, 175)
        fQuizPer.Margin = New Padding(3, 4, 3, 4)
        fQuizPer.MaxLength = 3
        fQuizPer.Name = "fQuizPer"
        fQuizPer.Size = New Size(46, 20)
        fQuizPer.TabIndex = 129
        fQuizPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' fAttPer
        ' 
        fAttPer.BackColor = Color.GhostWhite
        fAttPer.BorderStyle = BorderStyle.None
        fAttPer.Enabled = False
        fAttPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fAttPer.Location = New Point(323, 119)
        fAttPer.Margin = New Padding(3, 4, 3, 4)
        fAttPer.MaxLength = 3
        fAttPer.Name = "fAttPer"
        fAttPer.Size = New Size(46, 20)
        fAttPer.TabIndex = 128
        fAttPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label40
        ' 
        Label40.AutoSize = True
        Label40.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label40.Location = New Point(613, 86)
        Label40.Name = "Label40"
        Label40.Size = New Size(21, 21)
        Label40.TabIndex = 119
        Label40.Text = "T"
        ' 
        ' Label41
        ' 
        Label41.AutoSize = True
        Label41.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label41.Location = New Point(558, 85)
        Label41.Name = "Label41"
        Label41.Size = New Size(21, 21)
        Label41.TabIndex = 118
        Label41.Text = "S"
        ' 
        ' Label38
        ' 
        Label38.AutoSize = True
        Label38.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label38.Location = New Point(280, 86)
        Label38.Name = "Label38"
        Label38.Size = New Size(21, 21)
        Label38.TabIndex = 117
        Label38.Text = "T"
        ' 
        ' Label39
        ' 
        Label39.AutoSize = True
        Label39.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label39.Location = New Point(223, 86)
        Label39.Name = "Label39"
        Label39.Size = New Size(21, 21)
        Label39.TabIndex = 116
        Label39.Text = "S"
        ' 
        ' fProjOv
        ' 
        fProjOv.BackColor = SystemColors.Window
        fProjOv.BorderStyle = BorderStyle.FixedSingle
        fProjOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fProjOv.Location = New Point(599, 170)
        fProjOv.Margin = New Padding(3, 4, 3, 4)
        fProjOv.MaxLength = 3
        fProjOv.Name = "fProjOv"
        fProjOv.Size = New Size(46, 27)
        fProjOv.TabIndex = 32
        fProjOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' fExamOv
        ' 
        fExamOv.BackColor = SystemColors.Window
        fExamOv.BorderStyle = BorderStyle.FixedSingle
        fExamOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fExamOv.Location = New Point(598, 115)
        fExamOv.Margin = New Padding(3, 4, 3, 4)
        fExamOv.MaxLength = 3
        fExamOv.Name = "fExamOv"
        fExamOv.Size = New Size(46, 27)
        fExamOv.TabIndex = 30
        fExamOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' fExeOv
        ' 
        fExeOv.BackColor = SystemColors.Window
        fExeOv.BorderStyle = BorderStyle.FixedSingle
        fExeOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fExeOv.Location = New Point(268, 227)
        fExeOv.Margin = New Padding(3, 4, 3, 4)
        fExeOv.MaxLength = 3
        fExeOv.Name = "fExeOv"
        fExeOv.Size = New Size(46, 27)
        fExeOv.TabIndex = 26
        fExeOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' fQuizOv
        ' 
        fQuizOv.BackColor = SystemColors.Window
        fQuizOv.BorderStyle = BorderStyle.FixedSingle
        fQuizOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fQuizOv.Location = New Point(268, 171)
        fQuizOv.Margin = New Padding(3, 4, 3, 4)
        fQuizOv.MaxLength = 3
        fQuizOv.Name = "fQuizOv"
        fQuizOv.Size = New Size(46, 27)
        fQuizOv.TabIndex = 24
        fQuizOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' fAttOv
        ' 
        fAttOv.BackColor = SystemColors.Window
        fAttOv.BorderStyle = BorderStyle.FixedSingle
        fAttOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fAttOv.Location = New Point(268, 116)
        fAttOv.Margin = New Padding(3, 4, 3, 4)
        fAttOv.MaxLength = 3
        fAttOv.Name = "fAttOv"
        fAttOv.Size = New Size(46, 27)
        fAttOv.TabIndex = 22
        fAttOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' fSub
        ' 
        fSub.BackColor = Color.AliceBlue
        fSub.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        fSub.Location = New Point(54, 298)
        fSub.Margin = New Padding(3, 4, 3, 4)
        fSub.Name = "fSub"
        fSub.Size = New Size(203, 58)
        fSub.TabIndex = 22
        fSub.Text = "Submit"
        fSub.UseVisualStyleBackColor = False
        ' 
        ' fClr
        ' 
        fClr.BackColor = Color.AliceBlue
        fClr.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        fClr.Location = New Point(263, 298)
        fClr.Margin = New Padding(3, 4, 3, 4)
        fClr.Name = "fClr"
        fClr.Size = New Size(203, 58)
        fClr.TabIndex = 90
        fClr.Text = "Clear"
        fClr.UseVisualStyleBackColor = False
        ' 
        ' fCmpt
        ' 
        fCmpt.BackColor = Color.AliceBlue
        fCmpt.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        fCmpt.Location = New Point(472, 298)
        fCmpt.Margin = New Padding(3, 4, 3, 4)
        fCmpt.Name = "fCmpt"
        fCmpt.Size = New Size(203, 58)
        fCmpt.TabIndex = 21
        fCmpt.Text = "Compute"
        fCmpt.UseVisualStyleBackColor = False
        ' 
        ' fProj
        ' 
        fProj.BackColor = SystemColors.Window
        fProj.BorderStyle = BorderStyle.FixedSingle
        fProj.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fProj.Location = New Point(542, 171)
        fProj.Margin = New Padding(3, 4, 3, 4)
        fProj.MaxLength = 3
        fProj.Name = "fProj"
        fProj.Size = New Size(48, 27)
        fProj.TabIndex = 33
        fProj.TextAlign = HorizontalAlignment.Center
        ' 
        ' fExam
        ' 
        fExam.BackColor = SystemColors.Window
        fExam.BorderStyle = BorderStyle.FixedSingle
        fExam.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fExam.Location = New Point(541, 115)
        fExam.Margin = New Padding(3, 4, 3, 4)
        fExam.MaxLength = 3
        fExam.Name = "fExam"
        fExam.Size = New Size(48, 27)
        fExam.TabIndex = 31
        fExam.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label11.Location = New Point(375, 174)
        Label11.Name = "Label11"
        Label11.Size = New Size(164, 21)
        Label11.TabIndex = 90
        Label11.Text = "Final Project:"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label12.Location = New Point(375, 118)
        Label12.Name = "Label12"
        Label12.Size = New Size(164, 21)
        Label12.TabIndex = 90
        Label12.Text = "Finals Exam  :"
        ' 
        ' fExe
        ' 
        fExe.BackColor = SystemColors.Window
        fExe.BorderStyle = BorderStyle.FixedSingle
        fExe.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fExe.Location = New Point(209, 227)
        fExe.Margin = New Padding(3, 4, 3, 4)
        fExe.MaxLength = 3
        fExe.Name = "fExe"
        fExe.Size = New Size(48, 27)
        fExe.TabIndex = 27
        fExe.TextAlign = HorizontalAlignment.Center
        ' 
        ' fQuiz
        ' 
        fQuiz.BackColor = SystemColors.Window
        fQuiz.BorderStyle = BorderStyle.FixedSingle
        fQuiz.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fQuiz.Location = New Point(209, 171)
        fQuiz.Margin = New Padding(3, 4, 3, 4)
        fQuiz.MaxLength = 3
        fQuiz.Name = "fQuiz"
        fQuiz.Size = New Size(48, 27)
        fQuiz.TabIndex = 25
        fQuiz.TextAlign = HorizontalAlignment.Center
        ' 
        ' fAtt
        ' 
        fAtt.BackColor = SystemColors.Window
        fAtt.BorderStyle = BorderStyle.FixedSingle
        fAtt.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fAtt.Location = New Point(209, 116)
        fAtt.Margin = New Padding(3, 4, 3, 4)
        fAtt.MaxLength = 3
        fAtt.Name = "fAtt"
        fAtt.Size = New Size(48, 27)
        fAtt.TabIndex = 23
        fAtt.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label13.Location = New Point(43, 230)
        Label13.Name = "Label13"
        Label13.Size = New Size(164, 21)
        Label13.TabIndex = 90
        Label13.Text = "Lab Exercises:"
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label15.Location = New Point(43, 119)
        Label15.Name = "Label15"
        Label15.Size = New Size(164, 21)
        Label15.TabIndex = 90
        Label15.Text = "Attendance   :"
        ' 
        ' TextBox6
        ' 
        TextBox6.BackColor = Color.Lavender
        TextBox6.BorderStyle = BorderStyle.FixedSingle
        TextBox6.Font = New Font("Courier New", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        TextBox6.Location = New Point(47, 30)
        TextBox6.Margin = New Padding(3, 4, 3, 4)
        TextBox6.Name = "TextBox6"
        TextBox6.ReadOnly = True
        TextBox6.Size = New Size(643, 34)
        TextBox6.TabIndex = 90
        TextBox6.Text = "FINALS"
        TextBox6.TextAlign = HorizontalAlignment.Center
        ' 
        ' semGrade
        ' 
        semGrade.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        semGrade.BorderStyle = BorderStyle.None
        semGrade.Font = New Font("Courier New", 24F, FontStyle.Bold)
        semGrade.Location = New Point(1375, 106)
        semGrade.Margin = New Padding(3, 4, 3, 4)
        semGrade.Name = "semGrade"
        semGrade.Size = New Size(156, 46)
        semGrade.TabIndex = 118
        semGrade.Text = "00.00"
        semGrade.TextAlign = HorizontalAlignment.Center
        ' 
        ' semPer
        ' 
        semPer.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        semPer.BorderStyle = BorderStyle.None
        semPer.Font = New Font("Courier New", 12F, FontStyle.Bold)
        semPer.Location = New Point(1406, 63)
        semPer.Margin = New Padding(3, 4, 3, 4)
        semPer.Name = "semPer"
        semPer.Size = New Size(94, 23)
        semPer.TabIndex = 117
        semPer.Text = "00.00"
        semPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label32
        ' 
        Label32.AutoSize = True
        Label32.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        Label32.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label32.Location = New Point(274, 257)
        Label32.Name = "Label32"
        Label32.Size = New Size(32, 21)
        Label32.TabIndex = 130
        Label32.Text = "S "
        ' 
        ' sgLbl
        ' 
        sgLbl.AutoSize = True
        sgLbl.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        sgLbl.Font = New Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        sgLbl.Location = New Point(1355, 39)
        sgLbl.Name = "sgLbl"
        sgLbl.Size = New Size(190, 23)
        sgLbl.TabIndex = 116
        sgLbl.Text = "Semestral Grade"
        ' 
        ' Panel5
        ' 
        Panel5.BackColor = SystemColors.Window
        Panel5.BorderStyle = BorderStyle.FixedSingle
        Panel5.Controls.Add(TextBox5)
        Panel5.Controls.Add(Label6)
        Panel5.Controls.Add(Label25)
        Panel5.Controls.Add(Label20)
        Panel5.Controls.Add(mtAtt)
        Panel5.Controls.Add(mtQuiz)
        Panel5.Controls.Add(mtExe)
        Panel5.Controls.Add(Label7)
        Panel5.Controls.Add(Label8)
        Panel5.Controls.Add(Label9)
        Panel5.Controls.Add(Label22)
        Panel5.Controls.Add(mtExam)
        Panel5.Controls.Add(mtRecitPer)
        Panel5.Controls.Add(mtCstud)
        Panel5.Controls.Add(mtCstudPer)
        Panel5.Controls.Add(mtRecit)
        Panel5.Controls.Add(mtExamPer)
        Panel5.Controls.Add(mtCmpt)
        Panel5.Controls.Add(Label21)
        Panel5.Controls.Add(mtClr)
        Panel5.Controls.Add(mtExePer)
        Panel5.Controls.Add(mtSub)
        Panel5.Controls.Add(mtQuizPer)
        Panel5.Controls.Add(mtAttOv)
        Panel5.Controls.Add(mtAttPer)
        Panel5.Controls.Add(mtQuizOv)
        Panel5.Controls.Add(mtExeOv)
        Panel5.Controls.Add(mtExamOv)
        Panel5.Controls.Add(mtCstudOv)
        Panel5.Controls.Add(mtRecitOv)
        Panel5.Controls.Add(Label36)
        Panel5.Controls.Add(Label34)
        Panel5.Controls.Add(Label37)
        Panel5.Controls.Add(Label35)
        Panel5.Location = New Point(45, 308)
        Panel5.Margin = New Padding(3, 4, 3, 4)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(751, 384)
        Panel5.TabIndex = 139
        ' 
        ' TextBox5
        ' 
        TextBox5.BackColor = Color.Lavender
        TextBox5.BorderStyle = BorderStyle.FixedSingle
        TextBox5.Font = New Font("Courier New", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        TextBox5.Location = New Point(53, 30)
        TextBox5.Margin = New Padding(3, 4, 3, 4)
        TextBox5.Name = "TextBox5"
        TextBox5.ReadOnly = True
        TextBox5.Size = New Size(643, 34)
        TextBox5.TabIndex = 90
        TextBox5.Text = "MIDTERM"
        TextBox5.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(53, 177)
        Label6.Name = "Label6"
        Label6.Size = New Size(164, 21)
        Label6.TabIndex = 137
        Label6.Text = "Quiz         :"
        ' 
        ' Label25
        ' 
        Label25.AutoSize = True
        Label25.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label25.Location = New Point(53, 118)
        Label25.Name = "Label25"
        Label25.Size = New Size(164, 21)
        Label25.TabIndex = 90
        Label25.Text = "Attendance   :"
        ' 
        ' Label20
        ' 
        Label20.AutoSize = True
        Label20.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label20.Location = New Point(53, 229)
        Label20.Name = "Label20"
        Label20.Size = New Size(164, 21)
        Label20.TabIndex = 90
        Label20.Text = "Lab Exercises:"
        ' 
        ' mtAtt
        ' 
        mtAtt.BackColor = SystemColors.Window
        mtAtt.BorderStyle = BorderStyle.FixedSingle
        mtAtt.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtAtt.Location = New Point(218, 115)
        mtAtt.Margin = New Padding(3, 4, 3, 4)
        mtAtt.MaxLength = 3
        mtAtt.Name = "mtAtt"
        mtAtt.Size = New Size(48, 27)
        mtAtt.TabIndex = 9
        mtAtt.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtQuiz
        ' 
        mtQuiz.BackColor = SystemColors.Window
        mtQuiz.BorderStyle = BorderStyle.FixedSingle
        mtQuiz.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtQuiz.Location = New Point(218, 169)
        mtQuiz.Margin = New Padding(3, 4, 3, 4)
        mtQuiz.MaxLength = 3
        mtQuiz.Name = "mtQuiz"
        mtQuiz.Size = New Size(48, 27)
        mtQuiz.TabIndex = 11
        mtQuiz.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtExe
        ' 
        mtExe.BackColor = SystemColors.Window
        mtExe.BorderStyle = BorderStyle.FixedSingle
        mtExe.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtExe.Location = New Point(218, 226)
        mtExe.Margin = New Padding(3, 4, 3, 4)
        mtExe.MaxLength = 3
        mtExe.Name = "mtExe"
        mtExe.Size = New Size(48, 27)
        mtExe.TabIndex = 13
        mtExe.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(385, 117)
        Label7.Name = "Label7"
        Label7.Size = New Size(153, 21)
        Label7.TabIndex = 90
        Label7.Text = "Midterm Exam:"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(385, 173)
        Label8.Name = "Label8"
        Label8.Size = New Size(153, 21)
        Label8.TabIndex = 90
        Label8.Text = "Case Study  :"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label9.Location = New Point(385, 228)
        Label9.Name = "Label9"
        Label9.Size = New Size(153, 21)
        Label9.TabIndex = 90
        Label9.Text = "Recitation  :"
        ' 
        ' Label22
        ' 
        Label22.AutoSize = True
        Label22.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label22.Location = New Point(660, 84)
        Label22.Name = "Label22"
        Label22.Size = New Size(21, 21)
        Label22.TabIndex = 127
        Label22.Text = "%"
        ' 
        ' mtExam
        ' 
        mtExam.BackColor = SystemColors.Window
        mtExam.BorderStyle = BorderStyle.FixedSingle
        mtExam.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtExam.Location = New Point(539, 114)
        mtExam.Margin = New Padding(3, 4, 3, 4)
        mtExam.MaxLength = 3
        mtExam.Name = "mtExam"
        mtExam.Size = New Size(48, 27)
        mtExam.TabIndex = 15
        mtExam.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtRecitPer
        ' 
        mtRecitPer.BackColor = Color.GhostWhite
        mtRecitPer.BorderStyle = BorderStyle.None
        mtRecitPer.Enabled = False
        mtRecitPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtRecitPer.Location = New Point(647, 229)
        mtRecitPer.Margin = New Padding(3, 4, 3, 4)
        mtRecitPer.MaxLength = 3
        mtRecitPer.Name = "mtRecitPer"
        mtRecitPer.Size = New Size(46, 20)
        mtRecitPer.TabIndex = 126
        mtRecitPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtCstud
        ' 
        mtCstud.BackColor = SystemColors.Window
        mtCstud.BorderStyle = BorderStyle.FixedSingle
        mtCstud.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtCstud.Location = New Point(539, 170)
        mtCstud.Margin = New Padding(3, 4, 3, 4)
        mtCstud.MaxLength = 3
        mtCstud.Name = "mtCstud"
        mtCstud.Size = New Size(48, 27)
        mtCstud.TabIndex = 17
        mtCstud.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtCstudPer
        ' 
        mtCstudPer.BackColor = Color.GhostWhite
        mtCstudPer.BorderStyle = BorderStyle.None
        mtCstudPer.Enabled = False
        mtCstudPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtCstudPer.Location = New Point(647, 171)
        mtCstudPer.Margin = New Padding(3, 4, 3, 4)
        mtCstudPer.MaxLength = 3
        mtCstudPer.Name = "mtCstudPer"
        mtCstudPer.Size = New Size(46, 20)
        mtCstudPer.TabIndex = 125
        mtCstudPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtRecit
        ' 
        mtRecit.BackColor = SystemColors.Window
        mtRecit.BorderStyle = BorderStyle.FixedSingle
        mtRecit.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtRecit.Location = New Point(539, 225)
        mtRecit.Margin = New Padding(3, 4, 3, 4)
        mtRecit.MaxLength = 3
        mtRecit.Name = "mtRecit"
        mtRecit.Size = New Size(48, 27)
        mtRecit.TabIndex = 19
        mtRecit.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtExamPer
        ' 
        mtExamPer.BackColor = Color.GhostWhite
        mtExamPer.BorderStyle = BorderStyle.None
        mtExamPer.Enabled = False
        mtExamPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtExamPer.Location = New Point(647, 116)
        mtExamPer.Margin = New Padding(3, 4, 3, 4)
        mtExamPer.MaxLength = 3
        mtExamPer.Name = "mtExamPer"
        mtExamPer.Size = New Size(46, 20)
        mtExamPer.TabIndex = 124
        mtExamPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtCmpt
        ' 
        mtCmpt.BackColor = Color.AliceBlue
        mtCmpt.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        mtCmpt.Location = New Point(481, 298)
        mtCmpt.Margin = New Padding(3, 4, 3, 4)
        mtCmpt.Name = "mtCmpt"
        mtCmpt.Size = New Size(203, 58)
        mtCmpt.TabIndex = 20
        mtCmpt.Text = "Compute"
        mtCmpt.UseVisualStyleBackColor = False
        ' 
        ' Label21
        ' 
        Label21.AutoSize = True
        Label21.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label21.Location = New Point(341, 85)
        Label21.Name = "Label21"
        Label21.Size = New Size(21, 21)
        Label21.TabIndex = 123
        Label21.Text = "%"
        ' 
        ' mtClr
        ' 
        mtClr.BackColor = Color.AliceBlue
        mtClr.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        mtClr.Location = New Point(272, 298)
        mtClr.Margin = New Padding(3, 4, 3, 4)
        mtClr.Name = "mtClr"
        mtClr.Size = New Size(203, 58)
        mtClr.TabIndex = 90
        mtClr.Text = "Clear"
        mtClr.UseVisualStyleBackColor = False
        ' 
        ' mtExePer
        ' 
        mtExePer.BackColor = Color.GhostWhite
        mtExePer.BorderStyle = BorderStyle.None
        mtExePer.Enabled = False
        mtExePer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtExePer.Location = New Point(328, 230)
        mtExePer.Margin = New Padding(3, 4, 3, 4)
        mtExePer.MaxLength = 3
        mtExePer.Name = "mtExePer"
        mtExePer.Size = New Size(46, 20)
        mtExePer.TabIndex = 122
        mtExePer.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtSub
        ' 
        mtSub.BackColor = Color.AliceBlue
        mtSub.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        mtSub.Location = New Point(63, 298)
        mtSub.Margin = New Padding(3, 4, 3, 4)
        mtSub.Name = "mtSub"
        mtSub.Size = New Size(203, 58)
        mtSub.TabIndex = 21
        mtSub.Text = "Submit"
        mtSub.UseVisualStyleBackColor = False
        ' 
        ' mtQuizPer
        ' 
        mtQuizPer.BackColor = Color.GhostWhite
        mtQuizPer.BorderStyle = BorderStyle.None
        mtQuizPer.Enabled = False
        mtQuizPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtQuizPer.Location = New Point(328, 173)
        mtQuizPer.Margin = New Padding(3, 4, 3, 4)
        mtQuizPer.MaxLength = 3
        mtQuizPer.Name = "mtQuizPer"
        mtQuizPer.Size = New Size(46, 20)
        mtQuizPer.TabIndex = 121
        mtQuizPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtAttOv
        ' 
        mtAttOv.BackColor = SystemColors.Window
        mtAttOv.BorderStyle = BorderStyle.FixedSingle
        mtAttOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtAttOv.Location = New Point(274, 115)
        mtAttOv.Margin = New Padding(3, 4, 3, 4)
        mtAttOv.MaxLength = 3
        mtAttOv.Name = "mtAttOv"
        mtAttOv.Size = New Size(46, 27)
        mtAttOv.TabIndex = 8
        mtAttOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtAttPer
        ' 
        mtAttPer.BackColor = Color.GhostWhite
        mtAttPer.BorderStyle = BorderStyle.None
        mtAttPer.Enabled = False
        mtAttPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtAttPer.Location = New Point(328, 118)
        mtAttPer.Margin = New Padding(3, 4, 3, 4)
        mtAttPer.MaxLength = 3
        mtAttPer.Name = "mtAttPer"
        mtAttPer.Size = New Size(46, 20)
        mtAttPer.TabIndex = 120
        mtAttPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtQuizOv
        ' 
        mtQuizOv.BackColor = SystemColors.Window
        mtQuizOv.BorderStyle = BorderStyle.FixedSingle
        mtQuizOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtQuizOv.Location = New Point(274, 169)
        mtQuizOv.Margin = New Padding(3, 4, 3, 4)
        mtQuizOv.MaxLength = 3
        mtQuizOv.Name = "mtQuizOv"
        mtQuizOv.Size = New Size(46, 27)
        mtQuizOv.TabIndex = 10
        mtQuizOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtExeOv
        ' 
        mtExeOv.BackColor = SystemColors.Window
        mtExeOv.BorderStyle = BorderStyle.FixedSingle
        mtExeOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtExeOv.Location = New Point(274, 226)
        mtExeOv.Margin = New Padding(3, 4, 3, 4)
        mtExeOv.MaxLength = 3
        mtExeOv.Name = "mtExeOv"
        mtExeOv.Size = New Size(46, 27)
        mtExeOv.TabIndex = 12
        mtExeOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtExamOv
        ' 
        mtExamOv.BackColor = SystemColors.Window
        mtExamOv.BorderStyle = BorderStyle.FixedSingle
        mtExamOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtExamOv.Location = New Point(595, 114)
        mtExamOv.Margin = New Padding(3, 4, 3, 4)
        mtExamOv.MaxLength = 3
        mtExamOv.Name = "mtExamOv"
        mtExamOv.Size = New Size(46, 27)
        mtExamOv.TabIndex = 14
        mtExamOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtCstudOv
        ' 
        mtCstudOv.BackColor = SystemColors.Window
        mtCstudOv.BorderStyle = BorderStyle.FixedSingle
        mtCstudOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtCstudOv.Location = New Point(595, 169)
        mtCstudOv.Margin = New Padding(3, 4, 3, 4)
        mtCstudOv.MaxLength = 3
        mtCstudOv.Name = "mtCstudOv"
        mtCstudOv.Size = New Size(46, 27)
        mtCstudOv.TabIndex = 16
        mtCstudOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtRecitOv
        ' 
        mtRecitOv.BackColor = SystemColors.Window
        mtRecitOv.BorderStyle = BorderStyle.FixedSingle
        mtRecitOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtRecitOv.Location = New Point(595, 225)
        mtRecitOv.Margin = New Padding(3, 4, 3, 4)
        mtRecitOv.MaxLength = 3
        mtRecitOv.Name = "mtRecitOv"
        mtRecitOv.Size = New Size(46, 27)
        mtRecitOv.TabIndex = 18
        mtRecitOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label36
        ' 
        Label36.AutoSize = True
        Label36.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label36.Location = New Point(607, 84)
        Label36.Name = "Label36"
        Label36.Size = New Size(21, 21)
        Label36.TabIndex = 115
        Label36.Text = "T"
        ' 
        ' Label34
        ' 
        Label34.AutoSize = True
        Label34.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label34.Location = New Point(233, 85)
        Label34.Name = "Label34"
        Label34.Size = New Size(21, 21)
        Label34.TabIndex = 112
        Label34.Text = "S"
        ' 
        ' Label37
        ' 
        Label37.AutoSize = True
        Label37.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label37.Location = New Point(553, 84)
        Label37.Name = "Label37"
        Label37.Size = New Size(21, 21)
        Label37.TabIndex = 114
        Label37.Text = "S"
        ' 
        ' Label35
        ' 
        Label35.AutoSize = True
        Label35.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label35.Location = New Point(287, 85)
        Label35.Name = "Label35"
        Label35.Size = New Size(21, 21)
        Label35.TabIndex = 113
        Label35.Text = "T"
        ' 
        ' ssem
        ' 
        ssem.DropDownStyle = ComboBoxStyle.DropDownList
        ssem.FlatStyle = FlatStyle.System
        ssem.Font = New Font("Courier New", 12F, FontStyle.Bold)
        ssem.ForeColor = Color.Black
        ssem.FormattingEnabled = True
        ssem.Items.AddRange(New Object() {"1st Semester", "2nd Semester"})
        ssem.Location = New Point(269, 112)
        ssem.Margin = New Padding(3, 4, 3, 4)
        ssem.Name = "ssem"
        ssem.Size = New Size(583, 31)
        ssem.TabIndex = 117
        ' 
        ' fGrade
        ' 
        fGrade.AutoSize = True
        fGrade.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        fGrade.Font = New Font("Courier New", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        fGrade.Location = New Point(1400, 704)
        fGrade.Name = "fGrade"
        fGrade.Size = New Size(82, 27)
        fGrade.TabIndex = 125
        fGrade.Text = "00.00"
        ' 
        ' Label17
        ' 
        Label17.AutoSize = True
        Label17.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        Label17.Font = New Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label17.Location = New Point(1240, 709)
        Label17.Name = "Label17"
        Label17.Size = New Size(154, 23)
        Label17.TabIndex = 124
        Label17.Text = "Final Grade:"
        ' 
        ' mtGrade
        ' 
        mtGrade.AutoSize = True
        mtGrade.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        mtGrade.Font = New Font("Courier New", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        mtGrade.Location = New Point(626, 705)
        mtGrade.Name = "mtGrade"
        mtGrade.Size = New Size(82, 27)
        mtGrade.TabIndex = 129
        mtGrade.Text = "00.00"
        ' 
        ' CourseCodeTxb
        ' 
        CourseCodeTxb.DropDownStyle = ComboBoxStyle.DropDownList
        CourseCodeTxb.FlatStyle = FlatStyle.System
        CourseCodeTxb.Font = New Font("Courier New", 12F, FontStyle.Bold)
        CourseCodeTxb.ForeColor = Color.Black
        CourseCodeTxb.FormattingEnabled = True
        CourseCodeTxb.Items.AddRange(New Object() {"Information Technology", "Computer Science", "Education", "Hotel Management", "Nursing", "Engineering", "Psychology"})
        CourseCodeTxb.Location = New Point(269, 53)
        CourseCodeTxb.Margin = New Padding(3, 4, 3, 4)
        CourseCodeTxb.Name = "CourseCodeTxb"
        CourseCodeTxb.Size = New Size(583, 31)
        CourseCodeTxb.TabIndex = 116
        ' 
        ' ssub
        ' 
        ssub.BorderStyle = BorderStyle.FixedSingle
        ssub.Font = New Font("Courier New", 12F, FontStyle.Bold)
        ssub.Location = New Point(269, 168)
        ssub.Margin = New Padding(3, 4, 3, 4)
        ssub.MaxLength = 30
        ssub.Name = "ssub"
        ssub.Size = New Size(583, 30)
        ssub.TabIndex = 118
        ' 
        ' Label16
        ' 
        Label16.AutoSize = True
        Label16.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        Label16.Font = New Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label16.Location = New Point(442, 709)
        Label16.Name = "Label16"
        Label16.Size = New Size(178, 23)
        Label16.TabIndex = 123
        Label16.Text = "Midterm Grade:"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Cascadia Mono", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(800, 20)
        Label1.Name = "Label1"
        Label1.Size = New Size(209, 37)
        Label1.TabIndex = 8
        Label1.Text = "Grading Form"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(36, 29)
        Label3.Name = "Label3"
        Label3.Size = New Size(99, 20)
        Label3.TabIndex = 7
        Label3.Text = "Professor"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Cascadia Mono", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(1650, 9)
        Label2.Name = "Label2"
        Label2.Size = New Size(0, 37)
        Label2.TabIndex = 6
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.FromArgb(CByte(167), CByte(141), CByte(120))
        Panel2.Controls.Add(Label1)
        Panel2.Controls.Add(Label3)
        Panel2.Controls.Add(Label2)
        Panel2.Location = New Point(3, -11)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(1900, 71)
        Panel2.TabIndex = 12
        ' 
        ' Label33
        ' 
        Label33.AutoSize = True
        Label33.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        Label33.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label33.Location = New Point(203, 404)
        Label33.Name = "Label33"
        Label33.Size = New Size(21, 21)
        Label33.TabIndex = 131
        Label33.Text = "T"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        Label5.Font = New Font("Courier New", 12F, FontStyle.Bold)
        Label5.Location = New Point(61, 171)
        Label5.Name = "Label5"
        Label5.Size = New Size(202, 23)
        Label5.TabIndex = 126
        Label5.Text = "Students Name  :"
        ' 
        ' Label26
        ' 
        Label26.AutoSize = True
        Label26.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        Label26.Font = New Font("Courier New", 12F, FontStyle.Bold)
        Label26.Location = New Point(61, 115)
        Label26.Name = "Label26"
        Label26.Size = New Size(202, 23)
        Label26.TabIndex = 121
        Label26.Text = "Course Title   :"
        ' 
        ' Label27
        ' 
        Label27.AutoSize = True
        Label27.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        Label27.Font = New Font("Courier New", 12F, FontStyle.Bold)
        Label27.Location = New Point(61, 56)
        Label27.Name = "Label27"
        Label27.Size = New Size(202, 23)
        Label27.TabIndex = 120
        Label27.Text = "Course Code    :"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        Label4.Font = New Font("Courier New", 10.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(81, 258)
        Label4.Name = "Label4"
        Label4.Size = New Size(152, 20)
        Label4.TabIndex = 132
        Label4.Text = ": Total Items"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        Label10.Font = New Font("Courier New", 10.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label10.Location = New Point(293, 258)
        Label10.Name = "Label10"
        Label10.Size = New Size(185, 20)
        Label10.TabIndex = 140
        Label10.Text = ": Score Obtained"
        ' 
        ' ProfessorForm
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(41), CByte(28), CByte(14))
        ClientSize = New Size(1906, 1069)
        Controls.Add(Label33)
        Controls.Add(Panel1)
        Controls.Add(Panel2)
        FormBorderStyle = FormBorderStyle.None
        Name = "ProfessorForm"
        Text = "ProfessorForm"
        WindowState = FormWindowState.Maximized
        Panel1.ResumeLayout(False)
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        Panel5.ResumeLayout(False)
        Panel5.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label33 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents ssem As ComboBox
    Friend WithEvents Label19 As Label
    Friend WithEvents CourseCodeTxb As ComboBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents ssub As TextBox
    Friend WithEvents ssec As ComboBox
    Friend WithEvents syr As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents fGrade As Label
    Friend WithEvents mtGrade As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label14 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents fProjPer As TextBox
    Friend WithEvents fExamPer As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents fExePer As TextBox
    Friend WithEvents fQuizPer As TextBox
    Friend WithEvents fAttPer As TextBox
    Friend WithEvents Label40 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents fProjOv As TextBox
    Friend WithEvents fExamOv As TextBox
    Friend WithEvents fExeOv As TextBox
    Friend WithEvents fQuizOv As TextBox
    Friend WithEvents fAttOv As TextBox
    Friend WithEvents fSub As Button
    Friend WithEvents fClr As Button
    Friend WithEvents fCmpt As Button
    Friend WithEvents fProj As TextBox
    Friend WithEvents fExam As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents fExe As TextBox
    Friend WithEvents fQuiz As TextBox
    Friend WithEvents fAtt As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents sname As TextBox
    Friend WithEvents sid As TextBox
    Friend WithEvents Panel5 As Panel
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents mtAtt As TextBox
    Friend WithEvents mtQuiz As TextBox
    Friend WithEvents mtExe As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents mtExam As TextBox
    Friend WithEvents mtRecitPer As TextBox
    Friend WithEvents mtCstud As TextBox
    Friend WithEvents mtCstudPer As TextBox
    Friend WithEvents mtRecit As TextBox
    Friend WithEvents mtExamPer As TextBox
    Friend WithEvents mtCmpt As Button
    Friend WithEvents Label21 As Label
    Friend WithEvents mtClr As Button
    Friend WithEvents mtExePer As TextBox
    Friend WithEvents mtSub As Button
    Friend WithEvents mtQuizPer As TextBox
    Friend WithEvents mtAttOv As TextBox
    Friend WithEvents mtAttPer As TextBox
    Friend WithEvents mtQuizOv As TextBox
    Friend WithEvents mtExeOv As TextBox
    Friend WithEvents mtExamOv As TextBox
    Friend WithEvents mtCstudOv As TextBox
    Friend WithEvents mtRecitOv As TextBox
    Friend WithEvents Label36 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents rmrks As TextBox
    Friend WithEvents semGrade As TextBox
    Friend WithEvents semPer As TextBox
    Friend WithEvents sgLbl As Label
End Class
