﻿Imports System.Text.RegularExpressions
Public Class GradingSystem
    Private Sub gradingSystem_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        disMT()
        disF()
        semPer.Visible = False
        semGrade.Visible = False
        sgLbl.Visible = False
        rmrks.Visible = False

    End Sub

    ' Method to disable midterm fields
    Private Sub disMT()
        mtAtt.Enabled = False
        mtQuiz.Enabled = False
        mtExe.Enabled = False
        mtExam.Enabled = False
        mtCstud.Enabled = False
        mtRecit.Enabled = False
        mtCmpt.Enabled = False
        mtClr.Enabled = False
        mtSub.Enabled = False
        mtAttOv.Enabled = False
        mtQuizOv.Enabled = False
        mtExeOv.Enabled = False
        mtExamOv.Enabled = False
        mtCstudOv.Enabled = False
        mtRecitOv.Enabled = False
    End Sub

    Private Sub enMT()
        mtCmpt.Enabled = True
        mtClr.Enabled = True
        mtAttOv.Enabled = True
        mtQuizOv.Enabled = True
        mtExeOv.Enabled = True
        mtExamOv.Enabled = True
        mtCstudOv.Enabled = True
        mtRecitOv.Enabled = True
    End Sub

    ' Method to disable final fields
    Private Sub disF()
        fAtt.Enabled = False
        fQuiz.Enabled = False
        fExe.Enabled = False
        fExam.Enabled = False
        fProj.Enabled = False
        fCmpt.Enabled = False
        fClr.Enabled = False
        fSub.Enabled = False
        fAttOv.Enabled = False
        fQuizOv.Enabled = False
        fExeOv.Enabled = False
        fExamOv.Enabled = False
        fProjOv.Enabled = False
    End Sub

    Private Sub enF()
        fCmpt.Enabled = True
        fClr.Enabled = True
        fAttOv.Enabled = True
        fQuizOv.Enabled = True
        fExeOv.Enabled = True
        fExamOv.Enabled = True
        fProjOv.Enabled = True
    End Sub

    Private Sub check()
        If sid.Text = "" OrElse sname.Text = "" OrElse syr.Text = "" OrElse ssec.Text = "" OrElse scrs.Text = "" OrElse
                    ssem.Text = "" OrElse ssub.Text = "" Then
            disMT()
        Else
            enMT()
        End If
    End Sub

    Private Sub isNum(ByVal sender As Object, ByVal e As KeyPressEventArgs)
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 45 Then
            ' Valid input
        Else
            e.Handled = True
            MessageBox.Show("Please input numeric values only.")
        End If
    End Sub

    Private Sub isLet(ByVal sender As Object, ByVal e As KeyPressEventArgs)
        If (Asc(e.KeyChar) >= 65 And Asc(e.KeyChar) <= 90) Or (Asc(e.KeyChar) >= 97 And Asc(e.KeyChar) <= 122) Or
            Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 46 Or Asc(e.KeyChar) = 44 Or Asc(e.KeyChar) = 32 Then
        Else
            e.Handled = True
            MessageBox.Show("Please input your name properly.")
        End If
    End Sub

    Private Sub sid_TextChanged(sender As Object, e As EventArgs) Handles syr.TextChanged, ssub.TextChanged, ssem.TextChanged, ssec.TextChanged, sname.TextChanged, sid.TextChanged, scrs.TextChanged
        check()
    End Sub

    Private Sub mtCmpt_Click(sender As Object, e As EventArgs) Handles mtCmpt.Click
        Dim attendance As Double
        Dim quizzes As Double
        Dim laboratoryExercises As Double
        Dim midtermExam As Double
        Dim caseStudy As Double
        Dim recitation As Double
        Dim attendanceOv As Double
        Dim quizzesOv As Double
        Dim laboratoryExercisesOv As Double
        Dim midtermExamOv As Double
        Dim caseStudyOv As Double
        Dim recitationOv As Double

        If Not Double.TryParse(mtAtt.Text, attendance) OrElse
           Not Double.TryParse(mtQuiz.Text, quizzes) OrElse
           Not Double.TryParse(mtExe.Text, laboratoryExercises) OrElse
           Not Double.TryParse(mtExam.Text, midtermExam) OrElse
           Not Double.TryParse(mtCstud.Text, caseStudy) OrElse
           Not Double.TryParse(mtRecit.Text, recitation) OrElse
           Not Double.TryParse(mtAttOv.Text, attendanceOv) OrElse
           Not Double.TryParse(mtQuizOv.Text, quizzesOv) OrElse
           Not Double.TryParse(mtExeOv.Text, laboratoryExercisesOv) OrElse
           Not Double.TryParse(mtExamOv.Text, midtermExamOv) OrElse
           Not Double.TryParse(mtCstudOv.Text, caseStudyOv) OrElse
           Not Double.TryParse(mtRecitOv.Text, recitationOv) Then

            MessageBox.Show("Please ensure all fields are filled with valid numeric inputs.")
            Return
        End If

        Dim mtattPercentage As Double = Double.Parse(mtAttPer.Text)
        Dim mtquizPercentage As Double = Double.Parse(mtQuizPer.Text)
        Dim mtexePercentage As Double = Double.Parse(mtExePer.Text)
        Dim mtexmPercentage As Double = Double.Parse(mtExamPer.Text)
        Dim mtcsstdPercentage As Double = Double.Parse(mtCstudPer.Text)
        Dim mtrctPercentage As Double = Double.Parse(mtRecitPer.Text)

        Dim totGrade As Double = mtattPercentage + mtquizPercentage + mtexePercentage + mtexmPercentage + mtcsstdPercentage + mtrctPercentage

        mtGrade.Text = totGrade.ToString("F2")
        mtSub.Enabled = True
    End Sub

    Private Sub fCmpt_Click(sender As Object, e As EventArgs) Handles fCmpt.Click
        Dim fAttendance As Double
        Dim fQuizzes As Double
        Dim fLaboratoryExercises As Double
        Dim finalExam As Double
        Dim proj As Double
        Dim fattendanceOv As Double
        Dim fquizzesOv As Double
        Dim flaboratoryExercisesOv As Double
        Dim finalExamOv As Double
        Dim projOv As Double

        ' Input validation for final grade fields
        If Not Double.TryParse(fAtt.Text, fAttendance) OrElse
           Not Double.TryParse(fQuiz.Text, fQuizzes) OrElse
           Not Double.TryParse(fExe.Text, fLaboratoryExercises) OrElse
           Not Double.TryParse(fExam.Text, finalExam) OrElse
           Not Double.TryParse(fProj.Text, proj) OrElse
           Not Double.TryParse(fAttOv.Text, fattendanceOv) OrElse
           Not Double.TryParse(fQuizOv.Text, fquizzesOv) OrElse
           Not Double.TryParse(fExeOv.Text, flaboratoryExercisesOv) OrElse
           Not Double.TryParse(fExamOv.Text, finalExamOv) OrElse
           Not Double.TryParse(fProjOv.Text, projOv) Then

            MessageBox.Show("Please ensure all fields are filled with valid numeric inputs.")
            Return
        End If

        Dim fattPercentage As Double = Double.Parse(fAttPer.Text)
        Dim fquizPercentage As Double = Double.Parse(fQuizPer.Text)
        Dim fexePercentage As Double = Double.Parse(fExePer.Text)
        Dim fexmPercentage As Double = Double.Parse(fExamPer.Text)
        Dim fprojPercentage As Double = Double.Parse(fProjPer.Text)

        Dim totGrade2 As Double = fattPercentage + fquizPercentage + fexePercentage + fexmPercentage + fprojPercentage

        fGrade.Text = totGrade2.ToString("F2")
        fSub.Enabled = True
    End Sub

    Private Sub fSub_Click(sender As Object, e As EventArgs) Handles fSub.Click
        Dim midtermGrade As Double
        Dim finalGrade As Double
        Dim tots As Double = 0.00

        ' Make sure to validate the grades are numbers
        If fAtt.Text = "" OrElse fQuiz.Text = "" OrElse fExe.Text = "" OrElse
            fExam.Text = "" OrElse fProj.Text = "" Then

            MessageBox.Show("Please ensure all fields are filled with valid numeric inputs.")
        Else

            If Not Double.TryParse(mtGrade.Text, midtermGrade) OrElse
           Not Double.TryParse(fGrade.Text, finalGrade) Then
                MessageBox.Show("Invalid grades. Please ensure numeric inputs.")
                Return
            End If

            Dim tot As Double = (midtermGrade + finalGrade) / 2
            If tot > 97.5 Then
                tots = 1.0
                rmrks.Text = "Passed!"
            ElseIf tot > 94.5 Then
                tots = 1.25
                rmrks.Text = "Passed!"
            ElseIf tot > 91.5 Then
                tots = 1.5
                rmrks.Text = "Passed!"
            ElseIf tot > 88.5 Then
                tots = 1.75
                rmrks.Text = "Passed!"
            ElseIf tot > 85.5 Then
                tots = 2.0
                rmrks.Text = "Passed!"
            ElseIf tot > 82.5 Then
                tots = 2.25
                rmrks.Text = "Passed!"
            ElseIf tot > 79.5 Then
                tots = 2.5
                rmrks.Text = "Passed!"
            ElseIf tot > 76.5 Then
                tots = 2.75
                rmrks.Text = "Passed!"
            ElseIf tot > 74.5 Then
                tots = 3.0
                rmrks.Text = "Passed!"
            Else
                tots = 3.25
                rmrks.Text = "Failed!"
            End If

            semGrade.Text = tots.ToString("0.00")
            semPer.Text = tot.ToString("0.00")
            semPer.Visible = True
            semGrade.Visible = True
            sgLbl.Visible = True
            rmrks.Visible = True

            fAtt.Enabled = False
            fQuiz.Enabled = False
            fExe.Enabled = False
            fExam.Enabled = False
            fProj.Enabled = False
            fCmpt.Enabled = False
            fClr.Enabled = False
            fSub.Enabled = False
        End If
    End Sub

    Private Sub mtRecit_KeyPress(sender As Object, e As KeyPressEventArgs)
        isNum(sender, e)
        If mtAtt.Text = "" OrElse mtQuiz.Text = "" OrElse mtExe.Text = "" OrElse mtExam.Text = "" OrElse mtCstud.Text = "" OrElse
                        mtRecit.Text = "" OrElse fAtt.Text = "" OrElse fQuiz.Text = "" OrElse fExe.Text = "" OrElse fExam.Text = "" OrElse
                        fProj.Text = "" Then
            mtSub.Enabled = False
            fSub.Enabled = False
        End If

    End Sub

    Private Sub mtClr_Click(sender As Object, e As EventArgs) Handles mtClr.Click
        If mtAtt.Text <> "" OrElse mtAttOv.Text <> "" OrElse mtAttPer.Text <> "" OrElse mtQuiz.Text <> "" OrElse mtQuizOv.Text <> "" OrElse mtQuizPer.Text <> "" OrElse mtExe.Text <> "" OrElse mtExeOv.Text <> "" OrElse
            mtExePer.Text <> "" OrElse mtExam.Text <> "" OrElse mtExamOv.Text <> "" OrElse mtExamPer.Text <> "" OrElse mtCstud.Text <> "" OrElse mtCstudOv.Text <> "" OrElse mtCstudPer.Text <> "" OrElse mtRecit.Text <> "" OrElse mtRecitOv.Text <> "" OrElse mtRecitPer.Text <> "" Then

            Dim result = MessageBox.Show("Delete the entire Midterm Grade? Your data won't be saved.", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)

            If result = DialogResult.OK Then
                mtAtt.Text = ""
                mtAttOv.Text = ""
                mtAttPer.Text = ""
                mtQuiz.Text = ""
                mtQuizOv.Text = ""
                mtQuizPer.Text = ""
                mtExe.Text = ""
                mtExeOv.Text = ""
                mtExePer.Text = ""
                mtExam.Text = ""
                mtExamOv.Text = ""
                mtExamPer.Text = ""
                mtCstud.Text = ""
                mtCstudOv.Text = ""
                mtCstudPer.Text = ""
                mtRecit.Text = ""
                mtRecitOv.Text = ""
                mtRecitPer.Text = ""
                mtGrade.Text = "00.00"
            End If
        End If
        mtSub.Enabled = False
    End Sub

    Private Sub fClr_Click(sender As Object, e As EventArgs) Handles fClr.Click
        If fAtt.Text <> "" OrElse fAttOv.Text <> "" OrElse fAttPer.Text <> "" OrElse fQuiz.Text <> "" OrElse fQuizOv.Text <> "" OrElse fQuizPer.Text <> "" OrElse fExe.Text <> "" OrElse fExeOv.Text <> "" OrElse
            fExePer.Text <> "" OrElse fExam.Text <> "" OrElse fExamOv.Text <> "" OrElse fExamPer.Text <> "" OrElse fProj.Text <> "" OrElse fProjOv.Text <> "" OrElse fProjPer.Text <> "" Then

            Dim result = MessageBox.Show("Delete the entire Finals Grade? Your data won't be saved.", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)

            If result = DialogResult.OK Then
                fAtt.Text = ""
                fAttOv.Text = ""
                fAttPer.Text = ""
                fQuiz.Text = ""
                fQuizOv.Text = ""
                fQuizPer.Text = ""
                fExe.Text = ""
                fExeOv.Text = ""
                fExePer.Text = ""
                fExam.Text = ""
                fExamOv.Text = ""
                fExamPer.Text = ""
                fProj.Text = ""
                fProjOv.Text = ""
                fProjPer.Text = ""
                fGrade.Text = "00.00"
            End If
        End If
        fSub.Enabled = False
    End Sub

    Private Sub mtSub_Click(sender As Object, e As EventArgs) Handles mtSub.Click
        If mtAtt.Text = "" OrElse mtQuiz.Text = "" OrElse mtExe.Text = "" OrElse
            mtExam.Text = "" OrElse mtCstud.Text = "" OrElse mtRecit.Text = "" Then

            MessageBox.Show("Please ensure all fields are filled with valid numeric inputs.")
        Else
            disMT()
            enF()
        End If


    End Sub

    Private Sub sid_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles sid.Validating
        If sid.Text = "" Then

        Else
            Dim pattern As String = "^\d{2}-\d{5}$"

            If sid.Text.Length < 8 Then
                MessageBox.Show("Input must be exactly 8 characters long.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                e.Cancel = True ' Prevents the focus from leaving the TextBox
                Exit Sub
            End If

            Dim isValid As Boolean = Regex.IsMatch(sid.Text, pattern)

            If Not isValid Then
                MessageBox.Show("Invalid input! Please use the format 00-00000.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                e.Cancel = True
            End If
        End If
    End Sub
    Private Sub sid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles sid.KeyPress
        isNum(sender, e)
    End Sub

    Private Sub sname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles sname.KeyPress
        isLet(sender, e)
    End Sub

    Private Sub TextBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles mtRecit.KeyPress, mtQuiz.KeyPress, mtExe.KeyPress, mtExam.KeyPress, mtCstud.KeyPress, mtAtt.KeyPress, fQuiz.KeyPress, fProj.KeyPress, fExe.KeyPress, fExam.KeyPress, fAtt.KeyPress
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub MtTotal_TextChanged(sender As Object, e As EventArgs) Handles mtAttOv.TextChanged, mtQuizOv.TextChanged, mtExeOv.TextChanged, mtExamOv.TextChanged, mtCstudOv.TextChanged, mtRecitOv.TextChanged
        ToggleScoreField(mtAttOv, mtAtt)
        ToggleScoreField(mtQuizOv, mtQuiz)
        ToggleScoreField(mtExeOv, mtExe)
        ToggleScoreField(mtExamOv, mtExam)
        ToggleScoreField(mtCstudOv, mtCstud)
        ToggleScoreField(mtRecitOv, mtRecit)
    End Sub

    Private Sub MtScore_TextChanged(sender As Object, e As EventArgs) Handles mtAtt.TextChanged, mtQuiz.TextChanged, mtExe.TextChanged, mtExam.TextChanged, mtCstud.TextChanged, mtRecit.TextChanged
        ValidateAndCalculate(mtAtt, mtAttOv, mtAttPer, 0.05)
        ValidateAndCalculate(mtQuiz, mtQuizOv, mtQuizPer, 0.15)
        ValidateAndCalculate(mtExe, mtExeOv, mtExePer, 0.2)
        ValidateAndCalculate(mtExam, mtExamOv, mtExamPer, 0.3)
        ValidateAndCalculate(mtCstud, mtCstudOv, mtCstudPer, 0.2)
        ValidateAndCalculate(mtRecit, mtRecitOv, mtRecitPer, 0.1)
    End Sub

    Private Sub FTotal_TextChanged(sender As Object, e As EventArgs) Handles fQuizOv.TextChanged, fProjOv.TextChanged, fExamOv.TextChanged, fExeOv.TextChanged, fAttOv.TextChanged
        ToggleScoreField(fAttOv, fAtt)
        ToggleScoreField(fQuizOv, fQuiz)
        ToggleScoreField(fExeOv, fExe)
        ToggleScoreField(fExamOv, fExam)
        ToggleScoreField(fProjOv, fProj)
    End Sub

    Private Sub FScore_TextChanged(sender As Object, e As EventArgs) Handles fQuiz.TextChanged, fProj.TextChanged, fExam.TextChanged, fExe.TextChanged, fAtt.TextChanged
        ValidateAndCalculate(fAtt, fAttOv, fAttPer, 0.05)
        ValidateAndCalculate(fQuiz, fQuizOv, fQuizPer, 0.15)
        ValidateAndCalculate(fExe, fExeOv, fExePer, 0.2)
        ValidateAndCalculate(fExam, fExamOv, fExamPer, 0.3)
        ValidateAndCalculate(fProj, fProjOv, fProjPer, 0.3)
    End Sub

    Private Sub ToggleScoreField(totalTextBox As TextBox, scoreTextBox As TextBox)
        Dim total As Double
        If Double.TryParse(totalTextBox.Text, total) AndAlso total > 0 Then
            scoreTextBox.Enabled = True
        Else
            scoreTextBox.Clear()
            scoreTextBox.Enabled = False
        End If
    End Sub

    Private Sub ValidateAndCalculate(scoreTextBox As TextBox, totalTextBox As TextBox, percentageTextBox As TextBox, weight As Double)
        If scoreTextBox.Text = String.Empty OrElse totalTextBox.Text = String.Empty Then
            percentageTextBox.Clear()
            Return
        End If

        Dim score As Double
        Dim total As Double

        If Not Double.TryParse(scoreTextBox.Text, score) Then
            MessageBox.Show("Please enter a valid number in the Score field.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            scoreTextBox.Clear()
            percentageTextBox.Clear()
            Return
        End If

        If Not Double.TryParse(totalTextBox.Text, total) Then
            MessageBox.Show("Please enter a valid number in the Total field.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            totalTextBox.Clear()
            percentageTextBox.Clear()
            Return
        End If

        If total > 100 Then
            Dim result As DialogResult = MessageBox.Show("Are you sure this is a valid grade? Should I delete it for you?", "Grade Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)
            If result = DialogResult.OK Then
                totalTextBox.Clear()
                percentageTextBox.Clear()
                Return
            End If
        End If

        If score > total Then
            MessageBox.Show("Score cannot be greater than Total.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            scoreTextBox.Clear()
            percentageTextBox.Clear()
            Return
        End If

        If total > 0 Then
            Dim percentage = ((score / total * 50 + 50) * weight)
            percentageTextBox.Text = percentage.ToString("F2")
        Else
            percentageTextBox.Clear()
        End If
    End Sub

    Private Sub syr_KeyPress(sender As Object, e As KeyPressEventArgs) Handles syr.KeyPress

    End Sub

    Private Sub fProjOv_KeyPress(sender As Object, e As KeyPressEventArgs) Handles mtRecitOv.KeyPress, mtQuizOv.KeyPress, mtExeOv.KeyPress, mtExamOv.KeyPress, mtCstudOv.KeyPress, mtAttOv.KeyPress, fQuizOv.KeyPress, fProjOv.KeyPress, fExeOv.KeyPress, fExamOv.KeyPress, fAttOv.KeyPress
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
End Class
