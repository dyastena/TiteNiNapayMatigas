﻿Imports MySql.Data.MySqlClient
Module moduleDB
    Public ConnString As String = "Server=localhost;Database=oopimDB;Uid=root;"
    Public Function GetConnection() As MySqlConnection
        Return New MySqlConnection(ConnString)
    End Function

    Public Sub LogError(message As String)
        MessageBox.Show("Error: " & message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub

    Public Sub isLet(ByVal sender As Object, ByVal e As KeyPressEventArgs)
        If (Asc(e.KeyChar) >= 65 And Asc(e.KeyChar) <= 90) Or (Asc(e.KeyChar) >= 97 And Asc(e.KeyChar) <= 122) Or
            Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 46 Or Asc(e.KeyChar) = 44 Or Asc(e.KeyChar) = 32 Then
        Else
            e.Handled = True
            MessageBox.Show("Please input your name properly.")
        End If
    End Sub

    Public Sub isNum(ByVal sender As Object, ByVal e As KeyPressEventArgs)
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Or Asc(e.KeyChar) = 45 Then
            ' Valid input
        Else
            e.Handled = True
            MessageBox.Show("Please input numeric values only.")
        End If
    End Sub

    Public Sub cap(textBox As TextBox)
        If textBox.Text.Length > 0 Then
            Dim cursorPosition As Integer = textBox.SelectionStart
            Dim words As String() = textBox.Text.Split(" "c)
            For i As Integer = 0 To words.Length - 1
                If words(i).Length > 0 Then
                    words(i) = Char.ToUpper(words(i)(0)) & words(i).Substring(1).ToLower()
                End If
            Next
            textBox.Text = String.Join(" ", words)
            textBox.SelectionStart = cursorPosition
        End If
    End Sub


End Module

