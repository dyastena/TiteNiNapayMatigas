﻿Public Class AdminForm
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ShowPanel(AdminHome)
        HighlightActiveButton(HomeBtn)
    End Sub

    Private Sub ShowPanel(panelToShow As Form)
        AdminHome.Hide()
        AdminEnroll.Hide()
        AdminAssign.Hide()
        AdminLog.Hide()
        AdminSettings.Hide()

        panelToShow.TopLevel = False
        panelToShow.Parent = AdminPanel
        panelToShow.Dock = DockStyle.Fill
        panelToShow.Show()
    End Sub

    Private Sub HighlightActiveButton(activeButton As Button)
        HomeBtn.BackColor = Color.Transparent
        EnrollBtn.BackColor = Color.Transparent
        AssignBtn.BackColor = Color.Transparent
        LogBtn.BackColor = Color.Transparent
        SettingsBtn.BackColor = Color.Transparent

        activeButton.BackColor = Color.Gray
    End Sub

    Private Sub HomeBtn_Click(sender As Object, e As EventArgs) Handles HomeBtn.Click
        ShowPanel(AdminHome)
        HighlightActiveButton(HomeBtn)
    End Sub

    Private Sub EnrollBtn_Click(sender As Object, e As EventArgs) Handles EnrollBtn.Click
        ShowPanel(AdminEnroll)
        HighlightActiveButton(EnrollBtn)
    End Sub

    Private Sub AssignBtn_Click(sender As Object, e As EventArgs) Handles AssignBtn.Click
        ShowPanel(AdminAssign)
        HighlightActiveButton(AssignBtn)
    End Sub

    Private Sub LogBtn_Click(sender As Object, e As EventArgs) Handles LogBtn.Click
        ShowPanel(AdminLog)
        HighlightActiveButton(LogBtn)
    End Sub

    Private Sub SettingsBtn_Click(sender As Object, e As EventArgs) Handles SettingsBtn.Click
        ShowPanel(AdminSettings)
        HighlightActiveButton(SettingsBtn)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Form1.Show()

    End Sub
End Class
