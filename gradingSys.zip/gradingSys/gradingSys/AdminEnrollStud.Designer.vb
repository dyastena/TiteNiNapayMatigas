﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminEnrollStud
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As DataGridViewCellStyle = New DataGridViewCellStyle()
        EnrStudPnl = New Panel()
        ClrBtn = New Button()
        Label2 = New Label()
        DeptCmb = New ComboBox()
        GenPwBtn = New Button()
        Label13 = New Label()
        PwTxb = New TextBox()
        EnrollStudBtn = New Button()
        Label11 = New Label()
        MnameTxb = New TextBox()
        Label10 = New Label()
        SnameTxb = New TextBox()
        Label8 = New Label()
        Label7 = New Label()
        Label6 = New Label()
        ProgCmb = New ComboBox()
        SecCmb = New ComboBox()
        YearCmb = New ComboBox()
        Label5 = New Label()
        FnameTxb = New TextBox()
        Label1 = New Label()
        SNTxb = New TextBox()
        EnrollStudentsGV = New DataGridView()
        EnrStudPnl.SuspendLayout()
        CType(EnrollStudentsGV, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' EnrStudPnl
        ' 
        EnrStudPnl.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        EnrStudPnl.Controls.Add(ClrBtn)
        EnrStudPnl.Controls.Add(Label2)
        EnrStudPnl.Controls.Add(DeptCmb)
        EnrStudPnl.Controls.Add(GenPwBtn)
        EnrStudPnl.Controls.Add(Label13)
        EnrStudPnl.Controls.Add(PwTxb)
        EnrStudPnl.Controls.Add(EnrollStudBtn)
        EnrStudPnl.Controls.Add(Label11)
        EnrStudPnl.Controls.Add(MnameTxb)
        EnrStudPnl.Controls.Add(Label10)
        EnrStudPnl.Controls.Add(SnameTxb)
        EnrStudPnl.Controls.Add(Label8)
        EnrStudPnl.Controls.Add(Label7)
        EnrStudPnl.Controls.Add(Label6)
        EnrStudPnl.Controls.Add(ProgCmb)
        EnrStudPnl.Controls.Add(SecCmb)
        EnrStudPnl.Controls.Add(YearCmb)
        EnrStudPnl.Controls.Add(Label5)
        EnrStudPnl.Controls.Add(FnameTxb)
        EnrStudPnl.Controls.Add(Label1)
        EnrStudPnl.Controls.Add(SNTxb)
        EnrStudPnl.Location = New Point(52, 32)
        EnrStudPnl.Name = "EnrStudPnl"
        EnrStudPnl.Size = New Size(1436, 382)
        EnrStudPnl.TabIndex = 27
        ' 
        ' ClrBtn
        ' 
        ClrBtn.Font = New Font("Cascadia Code", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        ClrBtn.Location = New Point(39, 223)
        ClrBtn.Name = "ClrBtn"
        ClrBtn.Size = New Size(183, 25)
        ClrBtn.TabIndex = 55
        ClrBtn.Text = "Clear all fields"
        ClrBtn.UseVisualStyleBackColor = True
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(924, 63)
        Label2.Name = "Label2"
        Label2.Size = New Size(109, 20)
        Label2.TabIndex = 53
        Label2.Text = "Department"
        ' 
        ' DeptCmb
        ' 
        DeptCmb.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        DeptCmb.FlatStyle = FlatStyle.Flat
        DeptCmb.Font = New Font("Courier New", 10.2F)
        DeptCmb.FormattingEnabled = True
        DeptCmb.Location = New Point(914, 82)
        DeptCmb.Name = "DeptCmb"
        DeptCmb.Size = New Size(480, 28)
        DeptCmb.TabIndex = 54
        ' 
        ' GenPwBtn
        ' 
        GenPwBtn.Font = New Font("Cascadia Code", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        GenPwBtn.Location = New Point(1220, 175)
        GenPwBtn.Name = "GenPwBtn"
        GenPwBtn.Size = New Size(174, 27)
        GenPwBtn.TabIndex = 5
        GenPwBtn.Text = "Generate Password"
        GenPwBtn.UseVisualStyleBackColor = True
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label13.Location = New Point(927, 156)
        Label13.Name = "Label13"
        Label13.Size = New Size(89, 20)
        Label13.TabIndex = 51
        Label13.Text = "Password"
        ' 
        ' PwTxb
        ' 
        PwTxb.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        PwTxb.BorderStyle = BorderStyle.FixedSingle
        PwTxb.Enabled = False
        PwTxb.Font = New Font("Courier New", 10.2F)
        PwTxb.Location = New Point(918, 175)
        PwTxb.Name = "PwTxb"
        PwTxb.Size = New Size(300, 27)
        PwTxb.TabIndex = 50
        ' 
        ' EnrollStudBtn
        ' 
        EnrollStudBtn.Font = New Font("Cascadia Code", 10.2F)
        EnrollStudBtn.Location = New Point(442, 282)
        EnrollStudBtn.Name = "EnrollStudBtn"
        EnrollStudBtn.Size = New Size(535, 56)
        EnrollStudBtn.TabIndex = 6
        EnrollStudBtn.Text = "Enroll Student"
        EnrollStudBtn.UseVisualStyleBackColor = True
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label11.Location = New Point(364, 157)
        Label11.Name = "Label11"
        Label11.Size = New Size(119, 20)
        Label11.TabIndex = 49
        Label11.Text = "Middle Name"
        ' 
        ' MnameTxb
        ' 
        MnameTxb.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        MnameTxb.BorderStyle = BorderStyle.FixedSingle
        MnameTxb.Font = New Font("Courier New", 10.2F)
        MnameTxb.Location = New Point(357, 174)
        MnameTxb.MaxLength = 50
        MnameTxb.Name = "MnameTxb"
        MnameTxb.Size = New Size(260, 27)
        MnameTxb.TabIndex = 3
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label10.Location = New Point(647, 157)
        Label10.Name = "Label10"
        Label10.Size = New Size(79, 20)
        Label10.TabIndex = 47
        Label10.Text = "Surname"
        ' 
        ' SnameTxb
        ' 
        SnameTxb.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        SnameTxb.BorderStyle = BorderStyle.FixedSingle
        SnameTxb.Font = New Font("Courier New", 10.2F)
        SnameTxb.Location = New Point(640, 174)
        SnameTxb.MaxLength = 50
        SnameTxb.Name = "SnameTxb"
        SnameTxb.Size = New Size(260, 27)
        SnameTxb.TabIndex = 4
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(767, 64)
        Label8.Name = "Label8"
        Label8.Size = New Size(79, 20)
        Label8.TabIndex = 43
        Label8.Text = "Section"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(624, 64)
        Label7.Name = "Label7"
        Label7.Size = New Size(49, 20)
        Label7.TabIndex = 42
        Label7.Text = "Year"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(366, 64)
        Label6.Name = "Label6"
        Label6.Size = New Size(79, 20)
        Label6.TabIndex = 37
        Label6.Text = "Program"
        ' 
        ' ProgCmb
        ' 
        ProgCmb.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        ProgCmb.FlatStyle = FlatStyle.Flat
        ProgCmb.Font = New Font("Courier New", 10.2F)
        ProgCmb.FormattingEnabled = True
        ProgCmb.Items.AddRange(New Object() {"BSIT", "BSCS", "BSN"})
        ProgCmb.Location = New Point(356, 83)
        ProgCmb.Name = "ProgCmb"
        ProgCmb.Size = New Size(246, 28)
        ProgCmb.TabIndex = 5
        ' 
        ' SecCmb
        ' 
        SecCmb.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        SecCmb.FlatStyle = FlatStyle.Flat
        SecCmb.Font = New Font("Courier New", 10.2F)
        SecCmb.FormattingEnabled = True
        SecCmb.Items.AddRange(New Object() {"A", "B", "C", "D"})
        SecCmb.Location = New Point(760, 83)
        SecCmb.Name = "SecCmb"
        SecCmb.Size = New Size(130, 28)
        SecCmb.TabIndex = 7
        ' 
        ' YearCmb
        ' 
        YearCmb.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        YearCmb.FlatStyle = FlatStyle.Flat
        YearCmb.Font = New Font("Courier New", 10.2F)
        YearCmb.FormattingEnabled = True
        YearCmb.Items.AddRange(New Object() {"1", "2", "3", "4"})
        YearCmb.Location = New Point(617, 83)
        YearCmb.Name = "YearCmb"
        YearCmb.Size = New Size(130, 28)
        YearCmb.TabIndex = 6
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(48, 156)
        Label5.Name = "Label5"
        Label5.Size = New Size(109, 20)
        Label5.TabIndex = 35
        Label5.Text = "First Name"
        ' 
        ' FnameTxb
        ' 
        FnameTxb.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        FnameTxb.BorderStyle = BorderStyle.FixedSingle
        FnameTxb.Font = New Font("Courier New", 10.2F)
        FnameTxb.Location = New Point(40, 175)
        FnameTxb.MaxLength = 50
        FnameTxb.Name = "FnameTxb"
        FnameTxb.Size = New Size(289, 27)
        FnameTxb.TabIndex = 2
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(48, 64)
        Label1.Name = "Label1"
        Label1.Size = New Size(149, 20)
        Label1.TabIndex = 30
        Label1.Text = "Student Number"
        ' 
        ' SNTxb
        ' 
        SNTxb.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        SNTxb.BorderStyle = BorderStyle.FixedSingle
        SNTxb.Font = New Font("Courier New", 10.2F)
        SNTxb.Location = New Point(39, 83)
        SNTxb.MaxLength = 8
        SNTxb.Name = "SNTxb"
        SNTxb.Size = New Size(289, 27)
        SNTxb.TabIndex = 1
        ' 
        ' EnrollStudentsGV
        ' 
        EnrollStudentsGV.AllowUserToAddRows = False
        EnrollStudentsGV.AllowUserToDeleteRows = False
        EnrollStudentsGV.AllowUserToResizeColumns = False
        EnrollStudentsGV.AllowUserToResizeRows = False
        EnrollStudentsGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        EnrollStudentsGV.BorderStyle = BorderStyle.None
        DataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = SystemColors.Control
        DataGridViewCellStyle1.Font = New Font("Segoe UI", 7.20000029F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        DataGridViewCellStyle1.ForeColor = SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = DataGridViewTriState.True
        EnrollStudentsGV.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        EnrollStudentsGV.ColumnHeadersHeight = 29
        EnrollStudentsGV.Location = New Point(52, 447)
        EnrollStudentsGV.Name = "EnrollStudentsGV"
        EnrollStudentsGV.RowHeadersWidth = 51
        EnrollStudentsGV.Size = New Size(1436, 388)
        EnrollStudentsGV.TabIndex = 28
        ' 
        ' AdminEnrollStud
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(41), CByte(28), CByte(14))
        ClientSize = New Size(1541, 836)
        Controls.Add(EnrollStudentsGV)
        Controls.Add(EnrStudPnl)
        FormBorderStyle = FormBorderStyle.None
        Name = "AdminEnrollStud"
        Text = "AdminEnrollStud"
        EnrStudPnl.ResumeLayout(False)
        EnrStudPnl.PerformLayout()
        CType(EnrollStudentsGV, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents EnrStudPnl As Panel
    Friend WithEvents GenPwBtn As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents PwTxb As TextBox
    Friend WithEvents EnrollStudBtn As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents MnameTxb As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents SnameTxb As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents ProgCmb As ComboBox
    Friend WithEvents SecCmb As ComboBox
    Friend WithEvents YearCmb As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents FnameTxb As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents SNTxb As TextBox
    Friend WithEvents EnrollStudentsGV As DataGridView
    Friend WithEvents Label2 As Label
    Friend WithEvents DeptCmb As ComboBox
    Friend WithEvents ClrBtn As Button
End Class
