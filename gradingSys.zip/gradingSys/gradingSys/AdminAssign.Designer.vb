﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminAssign
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        ProfBtn = New Button()
        Panel2 = New Panel()
        Label3 = New Label()
        Label2 = New Label()
        StudBtn = New Button()
        AdminAssignPnl = New Panel()
        Panel2.SuspendLayout()
        SuspendLayout()
        ' 
        ' ProfBtn
        ' 
        ProfBtn.Font = New Font("Cascadia Code", 16.2F)
        ProfBtn.Location = New Point(778, 70)
        ProfBtn.Name = "ProfBtn"
        ProfBtn.Size = New Size(754, 98)
        ProfBtn.TabIndex = 20
        ProfBtn.Text = "Assign Subjects to Professors"
        ProfBtn.UseVisualStyleBackColor = True
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.FromArgb(CByte(167), CByte(141), CByte(120))
        Panel2.Controls.Add(Label3)
        Panel2.Controls.Add(Label2)
        Panel2.Location = New Point(12, 2)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(1520, 54)
        Panel2.TabIndex = 17
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(22, 18)
        Label3.Name = "Label3"
        Label3.Size = New Size(149, 20)
        Label3.TabIndex = 7
        Label3.Text = "Assign Classes"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Cascadia Mono", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(1259, 6)
        Label2.Name = "Label2"
        Label2.Size = New Size(241, 37)
        Label2.TabIndex = 6
        Label2.Text = "Hi, Superadmin"
        ' 
        ' StudBtn
        ' 
        StudBtn.Font = New Font("Cascadia Code", 16.2F)
        StudBtn.Location = New Point(12, 70)
        StudBtn.Name = "StudBtn"
        StudBtn.Size = New Size(754, 98)
        StudBtn.TabIndex = 18
        StudBtn.Text = "Assign Professors to Classes"
        StudBtn.UseVisualStyleBackColor = True
        ' 
        ' AdminAssignPnl
        ' 
        AdminAssignPnl.Location = New Point(-1, 167)
        AdminAssignPnl.Name = "AdminAssignPnl"
        AdminAssignPnl.Size = New Size(1548, 835)
        AdminAssignPnl.TabIndex = 81
        ' 
        ' AdminAssign
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(41), CByte(28), CByte(14))
        ClientSize = New Size(1544, 1001)
        Controls.Add(AdminAssignPnl)
        Controls.Add(ProfBtn)
        Controls.Add(Panel2)
        Controls.Add(StudBtn)
        FormBorderStyle = FormBorderStyle.None
        Name = "AdminAssign"
        Text = "AdminAssign"
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents ProfBtn As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents StudBtn As Button
    Friend WithEvents EnrProfPnl As Panel
    Friend WithEvents Button2 As Button
    Friend WithEvents EnrStudPnl As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents ComboBox4 As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents ComboBox6 As ComboBox
    Friend WithEvents ComboBox7 As ComboBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents ComboBox8 As ComboBox
    Friend WithEvents Label11 As Label
    Friend WithEvents ComboBox9 As ComboBox
    Friend WithEvents ComboBox10 As ComboBox
    Friend WithEvents AdminAssignPnl As Panel
End Class
