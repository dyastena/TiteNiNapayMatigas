﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminAssignProf
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        EnrStudPnl = New Panel()
        Label8 = New Label()
        Label1 = New Label()
        Label9 = New Label()
        ComboBox1 = New ComboBox()
        ComboBox6 = New ComboBox()
        ComboBox7 = New ComboBox()
        Label5 = New Label()
        ComboBox4 = New ComboBox()
        Label7 = New Label()
        ComboBox3 = New ComboBox()
        Label6 = New Label()
        ComboBox2 = New ComboBox()
        Button1 = New Button()
        DataGridView1 = New DataGridView()
        EnrStudPnl.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' EnrStudPnl
        ' 
        EnrStudPnl.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        EnrStudPnl.Controls.Add(Label8)
        EnrStudPnl.Controls.Add(Label1)
        EnrStudPnl.Controls.Add(Label9)
        EnrStudPnl.Controls.Add(ComboBox1)
        EnrStudPnl.Controls.Add(ComboBox6)
        EnrStudPnl.Controls.Add(ComboBox7)
        EnrStudPnl.Controls.Add(Label5)
        EnrStudPnl.Controls.Add(ComboBox4)
        EnrStudPnl.Controls.Add(Label7)
        EnrStudPnl.Controls.Add(ComboBox3)
        EnrStudPnl.Controls.Add(Label6)
        EnrStudPnl.Controls.Add(ComboBox2)
        EnrStudPnl.Controls.Add(Button1)
        EnrStudPnl.Enabled = False
        EnrStudPnl.Location = New Point(45, 23)
        EnrStudPnl.Name = "EnrStudPnl"
        EnrStudPnl.Size = New Size(707, 796)
        EnrStudPnl.TabIndex = 29
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(493, 406)
        Label8.Name = "Label8"
        Label8.Size = New Size(79, 20)
        Label8.TabIndex = 73
        Label8.Text = "Section"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(350, 406)
        Label1.Name = "Label1"
        Label1.Size = New Size(49, 20)
        Label1.TabIndex = 72
        Label1.Text = "Year"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label9.Location = New Point(88, 406)
        Label9.Name = "Label9"
        Label9.Size = New Size(79, 20)
        Label9.TabIndex = 68
        Label9.Text = "Program"
        ' 
        ' ComboBox1
        ' 
        ComboBox1.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        ComboBox1.DropDownStyle = ComboBoxStyle.DropDownList
        ComboBox1.FlatStyle = FlatStyle.Flat
        ComboBox1.Font = New Font("Courier New", 10.2F)
        ComboBox1.FormattingEnabled = True
        ComboBox1.Items.AddRange(New Object() {"BSIT", "BSCS"})
        ComboBox1.Location = New Point(82, 425)
        ComboBox1.Name = "ComboBox1"
        ComboBox1.Size = New Size(246, 28)
        ComboBox1.TabIndex = 71
        ' 
        ' ComboBox6
        ' 
        ComboBox6.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        ComboBox6.DropDownStyle = ComboBoxStyle.DropDownList
        ComboBox6.FlatStyle = FlatStyle.Flat
        ComboBox6.Font = New Font("Courier New", 10.2F)
        ComboBox6.FormattingEnabled = True
        ComboBox6.Items.AddRange(New Object() {"A", "B", "C", "D"})
        ComboBox6.Location = New Point(486, 425)
        ComboBox6.Name = "ComboBox6"
        ComboBox6.Size = New Size(130, 28)
        ComboBox6.TabIndex = 70
        ' 
        ' ComboBox7
        ' 
        ComboBox7.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        ComboBox7.DropDownStyle = ComboBoxStyle.DropDownList
        ComboBox7.FlatStyle = FlatStyle.Flat
        ComboBox7.Font = New Font("Courier New", 10.2F)
        ComboBox7.FormattingEnabled = True
        ComboBox7.Items.AddRange(New Object() {"1st Year", "2nd Year", "3rd Year", "4th Year"})
        ComboBox7.Location = New Point(343, 425)
        ComboBox7.Name = "ComboBox7"
        ComboBox7.Size = New Size(130, 28)
        ComboBox7.TabIndex = 69
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(92, 327)
        Label5.Name = "Label5"
        Label5.Size = New Size(69, 20)
        Label5.TabIndex = 35
        Label5.Text = "Course"
        ' 
        ' ComboBox4
        ' 
        ComboBox4.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        ComboBox4.DropDownStyle = ComboBoxStyle.DropDownList
        ComboBox4.FlatStyle = FlatStyle.Flat
        ComboBox4.Font = New Font("Courier New", 10.2F)
        ComboBox4.FormattingEnabled = True
        ComboBox4.Items.AddRange(New Object() {"CCS", "CBA"})
        ComboBox4.Location = New Point(81, 346)
        ComboBox4.Name = "ComboBox4"
        ComboBox4.Size = New Size(534, 28)
        ComboBox4.TabIndex = 66
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(87, 237)
        Label7.Name = "Label7"
        Label7.Size = New Size(99, 20)
        Label7.TabIndex = 64
        Label7.Text = "Professor"
        ' 
        ' ComboBox3
        ' 
        ComboBox3.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        ComboBox3.DropDownStyle = ComboBoxStyle.DropDownList
        ComboBox3.FlatStyle = FlatStyle.Flat
        ComboBox3.Font = New Font("Courier New", 10.2F)
        ComboBox3.FormattingEnabled = True
        ComboBox3.Items.AddRange(New Object() {"CCS", "CBA"})
        ComboBox3.Location = New Point(81, 256)
        ComboBox3.Name = "ComboBox3"
        ComboBox3.Size = New Size(534, 28)
        ComboBox3.TabIndex = 65
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(89, 149)
        Label6.Name = "Label6"
        Label6.Size = New Size(109, 20)
        Label6.TabIndex = 62
        Label6.Text = "Department"
        ' 
        ' ComboBox2
        ' 
        ComboBox2.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        ComboBox2.DropDownStyle = ComboBoxStyle.DropDownList
        ComboBox2.FlatStyle = FlatStyle.Flat
        ComboBox2.Font = New Font("Courier New", 10.2F)
        ComboBox2.FormattingEnabled = True
        ComboBox2.Items.AddRange(New Object() {"CCS", "CBA"})
        ComboBox2.Location = New Point(83, 168)
        ComboBox2.Name = "ComboBox2"
        ComboBox2.Size = New Size(534, 28)
        ComboBox2.TabIndex = 63
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Cascadia Code", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(82, 540)
        Button1.Name = "Button1"
        Button1.Size = New Size(535, 61)
        Button1.TabIndex = 28
        Button1.Text = "Assign Professor"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(794, 23)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowHeadersWidth = 51
        DataGridView1.Size = New Size(707, 796)
        DataGridView1.TabIndex = 82
        ' 
        ' AdminAssignProf
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(41), CByte(28), CByte(14))
        ClientSize = New Size(1548, 835)
        Controls.Add(DataGridView1)
        Controls.Add(EnrStudPnl)
        FormBorderStyle = FormBorderStyle.None
        Name = "AdminAssignProf"
        Text = "AdminAssignProf"
        EnrStudPnl.ResumeLayout(False)
        EnrStudPnl.PerformLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents EnrStudPnl As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents ComboBox6 As ComboBox
    Friend WithEvents ComboBox7 As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents ComboBox4 As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents Button1 As Button
    Friend WithEvents DataGridView1 As DataGridView
End Class
