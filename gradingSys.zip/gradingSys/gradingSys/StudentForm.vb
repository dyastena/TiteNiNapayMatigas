﻿Public Class StudentForm
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim main As New Form1

        main.Show()
        Me.Hide()

    End Sub
End Class