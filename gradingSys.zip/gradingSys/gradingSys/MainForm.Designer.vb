﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        Panel3 = New Panel()
        Panel7 = New Panel()
        LinkLabel2 = New LinkLabel()
        Label4 = New Label()
        Button5 = New LinkLabel()
        Button3 = New Button()
        Panel8 = New Panel()
        Button4 = New Button()
        TextBox1 = New TextBox()
        PictureBox3 = New PictureBox()
        Panel9 = New Panel()
        TextBox2 = New TextBox()
        PictureBox4 = New PictureBox()
        Label2 = New Label()
        Panel2 = New Panel()
        Label3 = New Label()
        LinkLabelAdmin = New LinkLabel()
        LinkLabel1 = New LinkLabel()
        Button1 = New Button()
        Panel6 = New Panel()
        Button2 = New Button()
        pwTx = New TextBox()
        PictureBox2 = New PictureBox()
        Panel5 = New Panel()
        usernameTx = New TextBox()
        PictureBox1 = New PictureBox()
        Label1 = New Label()
        Panel4 = New Panel()
        Panel1.SuspendLayout()
        Panel7.SuspendLayout()
        Panel8.SuspendLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        Panel9.SuspendLayout()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        Panel2.SuspendLayout()
        Panel6.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        Panel5.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        Panel4.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(190), CByte(181), CByte(169))
        Panel1.Controls.Add(Panel3)
        Panel1.Controls.Add(Panel7)
        Panel1.Controls.Add(Panel2)
        Panel1.Location = New Point(92, 68)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1753, 904)
        Panel1.TabIndex = 0
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.FromArgb(CByte(167), CByte(141), CByte(120))
        Panel3.Location = New Point(899, 0)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(854, 904)
        Panel3.TabIndex = 2
        ' 
        ' Panel7
        ' 
        Panel7.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        Panel7.Controls.Add(LinkLabel2)
        Panel7.Controls.Add(Label4)
        Panel7.Controls.Add(Button5)
        Panel7.Controls.Add(Button3)
        Panel7.Controls.Add(Panel8)
        Panel7.Controls.Add(Panel9)
        Panel7.Controls.Add(Label2)
        Panel7.Location = New Point(932, 66)
        Panel7.Name = "Panel7"
        Panel7.Size = New Size(765, 771)
        Panel7.TabIndex = 2
        ' 
        ' LinkLabel2
        ' 
        LinkLabel2.AutoSize = True
        LinkLabel2.Font = New Font("Courier New", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        LinkLabel2.LinkColor = Color.Green
        LinkLabel2.Location = New Point(151, 403)
        LinkLabel2.Name = "LinkLabel2"
        LinkLabel2.Size = New Size(190, 22)
        LinkLabel2.TabIndex = 10
        LinkLabel2.TabStop = True
        LinkLabel2.Text = "Recover Account"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(409, 153)
        Label4.Name = "Label4"
        Label4.Size = New Size(59, 20)
        Label4.TabIndex = 9
        Label4.Text = "Admin"
        ' 
        ' Button5
        ' 
        Button5.AutoSize = True
        Button5.Font = New Font("Courier New", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button5.LinkColor = Color.Green
        Button5.Location = New Point(314, 721)
        Button5.Name = "Button5"
        Button5.Size = New Size(154, 22)
        Button5.TabIndex = 7
        Button5.TabStop = True
        Button5.Text = "Not an Admin"
        ' 
        ' Button3
        ' 
        Button3.Font = New Font("Cascadia Code", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button3.Location = New Point(91, 478)
        Button3.Name = "Button3"
        Button3.Size = New Size(594, 51)
        Button3.TabIndex = 4
        Button3.Text = "Login"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Panel8
        ' 
        Panel8.BackColor = Color.White
        Panel8.Controls.Add(Button4)
        Panel8.Controls.Add(TextBox1)
        Panel8.Controls.Add(PictureBox3)
        Panel8.Location = New Point(136, 332)
        Panel8.Name = "Panel8"
        Panel8.Size = New Size(505, 58)
        Panel8.TabIndex = 2
        ' 
        ' Button4
        ' 
        Button4.BackColor = Color.Transparent
        Button4.BackgroundImage = My.Resources.Resources._6405909
        Button4.BackgroundImageLayout = ImageLayout.Stretch
        Button4.FlatStyle = FlatStyle.Flat
        Button4.Location = New Point(448, 10)
        Button4.Name = "Button4"
        Button4.Size = New Size(47, 40)
        Button4.TabIndex = 5
        Button4.UseVisualStyleBackColor = False
        ' 
        ' TextBox1
        ' 
        TextBox1.BorderStyle = BorderStyle.None
        TextBox1.Font = New Font("Courier New", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        TextBox1.Location = New Point(93, 16)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(391, 31)
        TextBox1.TabIndex = 2
        ' 
        ' PictureBox3
        ' 
        PictureBox3.BackgroundImage = My.Resources.Resources.lock_password_1
        PictureBox3.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox3.Location = New Point(30, 16)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(36, 32)
        PictureBox3.TabIndex = 1
        PictureBox3.TabStop = False
        ' 
        ' Panel9
        ' 
        Panel9.BackColor = Color.White
        Panel9.Controls.Add(TextBox2)
        Panel9.Controls.Add(PictureBox4)
        Panel9.Location = New Point(136, 246)
        Panel9.Name = "Panel9"
        Panel9.Size = New Size(505, 58)
        Panel9.TabIndex = 1
        ' 
        ' TextBox2
        ' 
        TextBox2.BorderStyle = BorderStyle.None
        TextBox2.Font = New Font("Courier New", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        TextBox2.Location = New Point(93, 16)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(391, 31)
        TextBox2.TabIndex = 1
        ' 
        ' PictureBox4
        ' 
        PictureBox4.BackgroundImage = My.Resources.Resources.image_removebg_preview__3_
        PictureBox4.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox4.Location = New Point(15, -1)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(61, 59)
        PictureBox4.TabIndex = 0
        PictureBox4.TabStop = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Cascadia Code", 28.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(474, 127)
        Label2.Name = "Label2"
        Label2.Size = New Size(167, 62)
        Label2.TabIndex = 0
        Label2.Text = "Login"
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        Panel2.Controls.Add(Label3)
        Panel2.Controls.Add(LinkLabelAdmin)
        Panel2.Controls.Add(LinkLabel1)
        Panel2.Controls.Add(Button1)
        Panel2.Controls.Add(Panel6)
        Panel2.Controls.Add(Panel5)
        Panel2.Controls.Add(Label1)
        Panel2.Location = New Point(62, 66)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(765, 771)
        Panel2.TabIndex = 1
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(291, 153)
        Label3.Name = "Label3"
        Label3.Size = New Size(179, 20)
        Label3.TabIndex = 8
        Label3.Text = "Student/Professor"
        ' 
        ' LinkLabelAdmin
        ' 
        LinkLabelAdmin.AutoSize = True
        LinkLabelAdmin.Font = New Font("Courier New", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        LinkLabelAdmin.LinkColor = Color.Green
        LinkLabelAdmin.Location = New Point(277, 721)
        LinkLabelAdmin.Name = "LinkLabelAdmin"
        LinkLabelAdmin.Size = New Size(214, 22)
        LinkLabelAdmin.TabIndex = 7
        LinkLabelAdmin.TabStop = True
        LinkLabelAdmin.Text = "Are you an admin?"
        ' 
        ' LinkLabel1
        ' 
        LinkLabel1.AutoSize = True
        LinkLabel1.Font = New Font("Courier New", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        LinkLabel1.LinkColor = Color.Green
        LinkLabel1.Location = New Point(151, 403)
        LinkLabel1.Name = "LinkLabel1"
        LinkLabel1.Size = New Size(190, 22)
        LinkLabel1.TabIndex = 6
        LinkLabel1.TabStop = True
        LinkLabel1.Text = "Recover Account"
        ' 
        ' Button1
        ' 
        Button1.Font = New Font("Cascadia Code", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(91, 478)
        Button1.Name = "Button1"
        Button1.Size = New Size(594, 51)
        Button1.TabIndex = 4
        Button1.Text = "Login"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Panel6
        ' 
        Panel6.BackColor = Color.White
        Panel6.Controls.Add(Button2)
        Panel6.Controls.Add(pwTx)
        Panel6.Controls.Add(PictureBox2)
        Panel6.Location = New Point(136, 332)
        Panel6.Name = "Panel6"
        Panel6.Size = New Size(505, 58)
        Panel6.TabIndex = 2
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.Transparent
        Button2.BackgroundImage = My.Resources.Resources._6405909
        Button2.BackgroundImageLayout = ImageLayout.Stretch
        Button2.FlatStyle = FlatStyle.Flat
        Button2.Location = New Point(448, 10)
        Button2.Name = "Button2"
        Button2.Size = New Size(47, 40)
        Button2.TabIndex = 5
        Button2.UseVisualStyleBackColor = False
        ' 
        ' pwTx
        ' 
        pwTx.BorderStyle = BorderStyle.None
        pwTx.Font = New Font("Courier New", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        pwTx.Location = New Point(93, 16)
        pwTx.Name = "pwTx"
        pwTx.Size = New Size(391, 31)
        pwTx.TabIndex = 2
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackgroundImage = My.Resources.Resources.lock_password_1
        PictureBox2.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox2.Location = New Point(30, 16)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(36, 32)
        PictureBox2.TabIndex = 1
        PictureBox2.TabStop = False
        ' 
        ' Panel5
        ' 
        Panel5.BackColor = Color.White
        Panel5.Controls.Add(usernameTx)
        Panel5.Controls.Add(PictureBox1)
        Panel5.Location = New Point(136, 246)
        Panel5.Name = "Panel5"
        Panel5.Size = New Size(505, 58)
        Panel5.TabIndex = 1
        ' 
        ' usernameTx
        ' 
        usernameTx.BorderStyle = BorderStyle.None
        usernameTx.Font = New Font("Courier New", 16.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        usernameTx.Location = New Point(93, 16)
        usernameTx.Name = "usernameTx"
        usernameTx.Size = New Size(391, 31)
        usernameTx.TabIndex = 1
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackgroundImage = My.Resources.Resources.image_removebg_preview__3_
        PictureBox1.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox1.Location = New Point(15, -1)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(61, 59)
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Cascadia Code", 28.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(130, 127)
        Label1.Name = "Label1"
        Label1.Size = New Size(167, 62)
        Label1.TabIndex = 0
        Label1.Text = "Login"
        ' 
        ' Panel4
        ' 
        Panel4.BackColor = Color.FromArgb(CByte(41), CByte(28), CByte(14))
        Panel4.Controls.Add(Panel1)
        Panel4.Location = New Point(1, 1)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(1924, 1054)
        Panel4.TabIndex = 3
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(41), CByte(28), CByte(14))
        ClientSize = New Size(1924, 1055)
        Controls.Add(Panel4)
        DoubleBuffered = True
        Name = "Form1"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Form1"
        WindowState = FormWindowState.Maximized
        Panel1.ResumeLayout(False)
        Panel7.ResumeLayout(False)
        Panel7.PerformLayout()
        Panel8.ResumeLayout(False)
        Panel8.PerformLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        Panel9.ResumeLayout(False)
        Panel9.PerformLayout()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel6.ResumeLayout(False)
        Panel6.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        Panel5.ResumeLayout(False)
        Panel5.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        Panel4.ResumeLayout(False)
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents usernameTx As TextBox
    Friend WithEvents pwTx As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents LinkLabelAdmin As LinkLabel
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Button5 As LinkLabel
    Friend WithEvents Button3 As Button
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Button4 As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Panel9 As Panel
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents LinkLabel2 As LinkLabel

End Class
