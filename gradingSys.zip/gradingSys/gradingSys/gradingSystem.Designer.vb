﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class GradingSystem
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        rmrks = New TextBox()
        semGrade = New TextBox()
        semPer = New TextBox()
        Label33 = New Label()
        Label32 = New Label()
        ssem = New ComboBox()
        Label19 = New Label()
        scrs = New ComboBox()
        Label10 = New Label()
        Label18 = New Label()
        ssub = New TextBox()
        ssec = New ComboBox()
        syr = New ComboBox()
        Label1 = New Label()
        sgLbl = New Label()
        fGrade = New Label()
        mtGrade = New Label()
        Label17 = New Label()
        Label16 = New Label()
        Panel2 = New Panel()
        Label14 = New Label()
        Label5 = New Label()
        Label24 = New Label()
        fProjPer = New TextBox()
        fExamPer = New TextBox()
        Label23 = New Label()
        fExePer = New TextBox()
        fQuizPer = New TextBox()
        fAttPer = New TextBox()
        Label22 = New Label()
        mtRecitPer = New TextBox()
        mtCstudPer = New TextBox()
        mtExamPer = New TextBox()
        Label21 = New Label()
        mtExePer = New TextBox()
        mtQuizPer = New TextBox()
        mtAttPer = New TextBox()
        Label40 = New Label()
        Label41 = New Label()
        Label38 = New Label()
        Label39 = New Label()
        Label36 = New Label()
        Label37 = New Label()
        Label35 = New Label()
        Label34 = New Label()
        fProjOv = New TextBox()
        fExamOv = New TextBox()
        fExeOv = New TextBox()
        mtRecitOv = New TextBox()
        fQuizOv = New TextBox()
        mtCstudOv = New TextBox()
        fAttOv = New TextBox()
        mtExamOv = New TextBox()
        mtExeOv = New TextBox()
        mtQuizOv = New TextBox()
        mtAttOv = New TextBox()
        fSub = New Button()
        fClr = New Button()
        fCmpt = New Button()
        mtSub = New Button()
        mtClr = New Button()
        fProj = New TextBox()
        fExam = New TextBox()
        Label11 = New Label()
        Label12 = New Label()
        fExe = New TextBox()
        fQuiz = New TextBox()
        fAtt = New TextBox()
        Label13 = New Label()
        Label15 = New Label()
        mtCmpt = New Button()
        mtRecit = New TextBox()
        mtCstud = New TextBox()
        mtExam = New TextBox()
        Label9 = New Label()
        Label8 = New Label()
        Label7 = New Label()
        mtExe = New TextBox()
        mtQuiz = New TextBox()
        mtAtt = New TextBox()
        Label6 = New Label()
        Label4 = New Label()
        TextBox6 = New TextBox()
        TextBox5 = New TextBox()
        Splitter1 = New Splitter()
        Label3 = New Label()
        Label2 = New Label()
        sname = New TextBox()
        sid = New TextBox()
        TextBox1 = New TextBox()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.LightYellow
        Panel1.Controls.Add(rmrks)
        Panel1.Controls.Add(semGrade)
        Panel1.Controls.Add(semPer)
        Panel1.Controls.Add(Label33)
        Panel1.Controls.Add(Label32)
        Panel1.Controls.Add(ssem)
        Panel1.Controls.Add(Label19)
        Panel1.Controls.Add(scrs)
        Panel1.Controls.Add(Label10)
        Panel1.Controls.Add(Label18)
        Panel1.Controls.Add(ssub)
        Panel1.Controls.Add(ssec)
        Panel1.Controls.Add(syr)
        Panel1.Controls.Add(Label1)
        Panel1.Controls.Add(sgLbl)
        Panel1.Controls.Add(fGrade)
        Panel1.Controls.Add(mtGrade)
        Panel1.Controls.Add(Label17)
        Panel1.Controls.Add(Label16)
        Panel1.Controls.Add(Panel2)
        Panel1.Controls.Add(Label3)
        Panel1.Controls.Add(Label2)
        Panel1.Controls.Add(sname)
        Panel1.Controls.Add(sid)
        Panel1.Controls.Add(TextBox1)
        Panel1.Location = New Point(12, 15)
        Panel1.Margin = New Padding(3, 4, 3, 4)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(1447, 818)
        Panel1.TabIndex = 1
        ' 
        ' rmrks
        ' 
        rmrks.BackColor = Color.LightYellow
        rmrks.BorderStyle = BorderStyle.None
        rmrks.Font = New Font("Courier New", 12F, FontStyle.Bold)
        rmrks.Location = New Point(1214, 248)
        rmrks.Margin = New Padding(3, 4, 3, 4)
        rmrks.Name = "rmrks"
        rmrks.Size = New Size(186, 23)
        rmrks.TabIndex = 115
        rmrks.TextAlign = HorizontalAlignment.Center
        ' 
        ' semGrade
        ' 
        semGrade.BackColor = Color.LightYellow
        semGrade.BorderStyle = BorderStyle.None
        semGrade.Font = New Font("Courier New", 24F, FontStyle.Bold)
        semGrade.Location = New Point(1214, 182)
        semGrade.Margin = New Padding(3, 4, 3, 4)
        semGrade.Name = "semGrade"
        semGrade.Size = New Size(186, 46)
        semGrade.TabIndex = 114
        semGrade.Text = "00.00"
        semGrade.TextAlign = HorizontalAlignment.Center
        ' 
        ' semPer
        ' 
        semPer.BackColor = Color.LightYellow
        semPer.BorderStyle = BorderStyle.None
        semPer.Font = New Font("Courier New", 12F, FontStyle.Bold)
        semPer.Location = New Point(1214, 142)
        semPer.Margin = New Padding(3, 4, 3, 4)
        semPer.Name = "semPer"
        semPer.Size = New Size(186, 23)
        semPer.TabIndex = 113
        semPer.Text = "00.00"
        semPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label33
        ' 
        Label33.AutoSize = True
        Label33.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label33.Location = New Point(29, 751)
        Label33.Name = "Label33"
        Label33.Size = New Size(175, 21)
        Label33.TabIndex = 111
        Label33.Text = "T : Total Items"
        ' 
        ' Label32
        ' 
        Label32.AutoSize = True
        Label32.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label32.Location = New Point(29, 712)
        Label32.Name = "Label32"
        Label32.Size = New Size(208, 21)
        Label32.TabIndex = 110
        Label32.Text = "S : Score Obtained"
        ' 
        ' ssem
        ' 
        ssem.DropDownStyle = ComboBoxStyle.DropDownList
        ssem.FlatStyle = FlatStyle.System
        ssem.Font = New Font("Microsoft Sans Serif", 10.2F)
        ssem.ForeColor = Color.Black
        ssem.FormattingEnabled = True
        ssem.Items.AddRange(New Object() {"1st Semester", "2nd Semester"})
        ssem.Location = New Point(671, 180)
        ssem.Margin = New Padding(3, 4, 3, 4)
        ssem.Name = "ssem"
        ssem.Size = New Size(265, 28)
        ssem.TabIndex = 6
        ' 
        ' Label19
        ' 
        Label19.AutoSize = True
        Label19.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label19.Location = New Point(546, 185)
        Label19.Name = "Label19"
        Label19.Size = New Size(109, 21)
        Label19.TabIndex = 90
        Label19.Text = "Semester:"
        ' 
        ' scrs
        ' 
        scrs.DropDownStyle = ComboBoxStyle.DropDownList
        scrs.FlatStyle = FlatStyle.System
        scrs.Font = New Font("Microsoft Sans Serif", 10.2F)
        scrs.ForeColor = Color.Black
        scrs.FormattingEnabled = True
        scrs.Items.AddRange(New Object() {"Information Technology", "Computer Science", "Education", "Hotel Management", "Nursing", "Engineering", "Psychology"})
        scrs.Location = New Point(671, 130)
        scrs.Margin = New Padding(3, 4, 3, 4)
        scrs.Name = "scrs"
        scrs.Size = New Size(265, 28)
        scrs.TabIndex = 5
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label10.Location = New Point(547, 231)
        Label10.Name = "Label10"
        Label10.Size = New Size(98, 21)
        Label10.TabIndex = 90
        Label10.Text = "Subject:"
        ' 
        ' Label18
        ' 
        Label18.AutoSize = True
        Label18.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label18.Location = New Point(547, 132)
        Label18.Name = "Label18"
        Label18.Size = New Size(87, 21)
        Label18.TabIndex = 90
        Label18.Text = "Course:"
        ' 
        ' ssub
        ' 
        ssub.BorderStyle = BorderStyle.FixedSingle
        ssub.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        ssub.Location = New Point(672, 226)
        ssub.Margin = New Padding(3, 4, 3, 4)
        ssub.MaxLength = 30
        ssub.Name = "ssub"
        ssub.Size = New Size(264, 27)
        ssub.TabIndex = 7
        ' 
        ' ssec
        ' 
        ssec.DropDownStyle = ComboBoxStyle.DropDownList
        ssec.DropDownWidth = 5
        ssec.FlatStyle = FlatStyle.System
        ssec.Font = New Font("Microsoft Sans Serif", 10.2F)
        ssec.ForeColor = Color.Black
        ssec.FormattingEnabled = True
        ssec.Items.AddRange(New Object() {"A", "B", "C", "D"})
        ssec.Location = New Point(354, 226)
        ssec.Margin = New Padding(3, 4, 3, 4)
        ssec.Name = "ssec"
        ssec.Size = New Size(127, 28)
        ssec.TabIndex = 4
        ' 
        ' syr
        ' 
        syr.DropDownStyle = ComboBoxStyle.DropDownList
        syr.FlatStyle = FlatStyle.System
        syr.Font = New Font("Microsoft Sans Serif", 10.2F)
        syr.ForeColor = Color.Black
        syr.FormattingEnabled = True
        syr.Items.AddRange(New Object() {"1", "2", "3", "4"})
        syr.Location = New Point(217, 226)
        syr.Margin = New Padding(3, 4, 3, 4)
        syr.Name = "syr"
        syr.Size = New Size(127, 28)
        syr.TabIndex = 3
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(35, 234)
        Label1.Name = "Label1"
        Label1.Size = New Size(131, 21)
        Label1.TabIndex = 90
        Label1.Text = "Year && Sec."
        ' 
        ' sgLbl
        ' 
        sgLbl.AutoSize = True
        sgLbl.Font = New Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        sgLbl.Location = New Point(1210, 98)
        sgLbl.Name = "sgLbl"
        sgLbl.Size = New Size(190, 23)
        sgLbl.TabIndex = 90
        sgLbl.Text = "Semestral Grade"
        ' 
        ' fGrade
        ' 
        fGrade.AutoSize = True
        fGrade.Font = New Font("Courier New", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        fGrade.Location = New Point(1285, 720)
        fGrade.Name = "fGrade"
        fGrade.Size = New Size(82, 27)
        fGrade.TabIndex = 90
        fGrade.Text = "00.00"
        ' 
        ' mtGrade
        ' 
        mtGrade.AutoSize = True
        mtGrade.Font = New Font("Courier New", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        mtGrade.Location = New Point(602, 720)
        mtGrade.Name = "mtGrade"
        mtGrade.Size = New Size(82, 27)
        mtGrade.TabIndex = 90
        mtGrade.Text = "00.00"
        ' 
        ' Label17
        ' 
        Label17.AutoSize = True
        Label17.Font = New Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label17.Location = New Point(1125, 725)
        Label17.Name = "Label17"
        Label17.Size = New Size(154, 23)
        Label17.TabIndex = 90
        Label17.Text = "Final Grade:"
        ' 
        ' Label16
        ' 
        Label16.AutoSize = True
        Label16.Font = New Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label16.Location = New Point(418, 724)
        Label16.Name = "Label16"
        Label16.Size = New Size(178, 23)
        Label16.TabIndex = 90
        Label16.Text = "Midterm Grade:"
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.GhostWhite
        Panel2.BorderStyle = BorderStyle.FixedSingle
        Panel2.Controls.Add(Label14)
        Panel2.Controls.Add(Label5)
        Panel2.Controls.Add(Label24)
        Panel2.Controls.Add(fProjPer)
        Panel2.Controls.Add(fExamPer)
        Panel2.Controls.Add(Label23)
        Panel2.Controls.Add(fExePer)
        Panel2.Controls.Add(fQuizPer)
        Panel2.Controls.Add(fAttPer)
        Panel2.Controls.Add(Label22)
        Panel2.Controls.Add(mtRecitPer)
        Panel2.Controls.Add(mtCstudPer)
        Panel2.Controls.Add(mtExamPer)
        Panel2.Controls.Add(Label21)
        Panel2.Controls.Add(mtExePer)
        Panel2.Controls.Add(mtQuizPer)
        Panel2.Controls.Add(mtAttPer)
        Panel2.Controls.Add(Label40)
        Panel2.Controls.Add(Label41)
        Panel2.Controls.Add(Label38)
        Panel2.Controls.Add(Label39)
        Panel2.Controls.Add(Label36)
        Panel2.Controls.Add(Label37)
        Panel2.Controls.Add(Label35)
        Panel2.Controls.Add(Label34)
        Panel2.Controls.Add(fProjOv)
        Panel2.Controls.Add(fExamOv)
        Panel2.Controls.Add(fExeOv)
        Panel2.Controls.Add(mtRecitOv)
        Panel2.Controls.Add(fQuizOv)
        Panel2.Controls.Add(mtCstudOv)
        Panel2.Controls.Add(fAttOv)
        Panel2.Controls.Add(mtExamOv)
        Panel2.Controls.Add(mtExeOv)
        Panel2.Controls.Add(mtQuizOv)
        Panel2.Controls.Add(mtAttOv)
        Panel2.Controls.Add(fSub)
        Panel2.Controls.Add(fClr)
        Panel2.Controls.Add(fCmpt)
        Panel2.Controls.Add(mtSub)
        Panel2.Controls.Add(mtClr)
        Panel2.Controls.Add(fProj)
        Panel2.Controls.Add(fExam)
        Panel2.Controls.Add(Label11)
        Panel2.Controls.Add(Label12)
        Panel2.Controls.Add(fExe)
        Panel2.Controls.Add(fQuiz)
        Panel2.Controls.Add(fAtt)
        Panel2.Controls.Add(Label13)
        Panel2.Controls.Add(Label15)
        Panel2.Controls.Add(mtCmpt)
        Panel2.Controls.Add(mtRecit)
        Panel2.Controls.Add(mtCstud)
        Panel2.Controls.Add(mtExam)
        Panel2.Controls.Add(Label9)
        Panel2.Controls.Add(Label8)
        Panel2.Controls.Add(Label7)
        Panel2.Controls.Add(mtExe)
        Panel2.Controls.Add(mtQuiz)
        Panel2.Controls.Add(mtAtt)
        Panel2.Controls.Add(Label6)
        Panel2.Controls.Add(Label4)
        Panel2.Controls.Add(TextBox6)
        Panel2.Controls.Add(TextBox5)
        Panel2.Controls.Add(Splitter1)
        Panel2.Location = New Point(32, 294)
        Panel2.Margin = New Padding(3, 4, 3, 4)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(1379, 384)
        Panel2.TabIndex = 90
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label14.Location = New Point(708, 156)
        Label14.Name = "Label14"
        Label14.Size = New Size(76, 21)
        Label14.TabIndex = 138
        Label14.Text = "Quiz: "
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(24, 160)
        Label5.Name = "Label5"
        Label5.Size = New Size(76, 21)
        Label5.TabIndex = 137
        Label5.Text = "Quiz: "
        ' 
        ' Label24
        ' 
        Label24.AutoSize = True
        Label24.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label24.Location = New Point(1325, 70)
        Label24.Name = "Label24"
        Label24.Size = New Size(21, 21)
        Label24.TabIndex = 134
        Label24.Text = "%"
        ' 
        ' fProjPer
        ' 
        fProjPer.BackColor = Color.GhostWhite
        fProjPer.BorderStyle = BorderStyle.None
        fProjPer.Enabled = False
        fProjPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fProjPer.Location = New Point(1310, 154)
        fProjPer.Margin = New Padding(3, 4, 3, 4)
        fProjPer.MaxLength = 3
        fProjPer.Name = "fProjPer"
        fProjPer.Size = New Size(46, 20)
        fProjPer.TabIndex = 133
        fProjPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' fExamPer
        ' 
        fExamPer.BackColor = Color.GhostWhite
        fExamPer.BorderStyle = BorderStyle.None
        fExamPer.Enabled = False
        fExamPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fExamPer.Location = New Point(1310, 99)
        fExamPer.Margin = New Padding(3, 4, 3, 4)
        fExamPer.MaxLength = 3
        fExamPer.Name = "fExamPer"
        fExamPer.Size = New Size(46, 20)
        fExamPer.TabIndex = 132
        fExamPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label23
        ' 
        Label23.AutoSize = True
        Label23.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label23.Location = New Point(997, 68)
        Label23.Name = "Label23"
        Label23.Size = New Size(21, 21)
        Label23.TabIndex = 131
        Label23.Text = "%"
        ' 
        ' fExePer
        ' 
        fExePer.BackColor = Color.GhostWhite
        fExePer.BorderStyle = BorderStyle.None
        fExePer.Enabled = False
        fExePer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fExePer.Location = New Point(985, 209)
        fExePer.Margin = New Padding(3, 4, 3, 4)
        fExePer.MaxLength = 3
        fExePer.Name = "fExePer"
        fExePer.Size = New Size(46, 20)
        fExePer.TabIndex = 130
        fExePer.TextAlign = HorizontalAlignment.Center
        ' 
        ' fQuizPer
        ' 
        fQuizPer.BackColor = Color.GhostWhite
        fQuizPer.BorderStyle = BorderStyle.None
        fQuizPer.Enabled = False
        fQuizPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fQuizPer.Location = New Point(985, 152)
        fQuizPer.Margin = New Padding(3, 4, 3, 4)
        fQuizPer.MaxLength = 3
        fQuizPer.Name = "fQuizPer"
        fQuizPer.Size = New Size(46, 20)
        fQuizPer.TabIndex = 129
        fQuizPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' fAttPer
        ' 
        fAttPer.BackColor = Color.GhostWhite
        fAttPer.BorderStyle = BorderStyle.None
        fAttPer.Enabled = False
        fAttPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fAttPer.Location = New Point(985, 98)
        fAttPer.Margin = New Padding(3, 4, 3, 4)
        fAttPer.MaxLength = 3
        fAttPer.Name = "fAttPer"
        fAttPer.Size = New Size(46, 20)
        fAttPer.TabIndex = 128
        fAttPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label22
        ' 
        Label22.AutoSize = True
        Label22.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label22.Location = New Point(625, 68)
        Label22.Name = "Label22"
        Label22.Size = New Size(21, 21)
        Label22.TabIndex = 127
        Label22.Text = "%"
        ' 
        ' mtRecitPer
        ' 
        mtRecitPer.BackColor = Color.GhostWhite
        mtRecitPer.BorderStyle = BorderStyle.None
        mtRecitPer.Enabled = False
        mtRecitPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtRecitPer.Location = New Point(612, 209)
        mtRecitPer.Margin = New Padding(3, 4, 3, 4)
        mtRecitPer.MaxLength = 3
        mtRecitPer.Name = "mtRecitPer"
        mtRecitPer.Size = New Size(46, 20)
        mtRecitPer.TabIndex = 126
        mtRecitPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtCstudPer
        ' 
        mtCstudPer.BackColor = Color.GhostWhite
        mtCstudPer.BorderStyle = BorderStyle.None
        mtCstudPer.Enabled = False
        mtCstudPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtCstudPer.Location = New Point(612, 152)
        mtCstudPer.Margin = New Padding(3, 4, 3, 4)
        mtCstudPer.MaxLength = 3
        mtCstudPer.Name = "mtCstudPer"
        mtCstudPer.Size = New Size(46, 20)
        mtCstudPer.TabIndex = 125
        mtCstudPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtExamPer
        ' 
        mtExamPer.BackColor = Color.GhostWhite
        mtExamPer.BorderStyle = BorderStyle.None
        mtExamPer.Enabled = False
        mtExamPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtExamPer.Location = New Point(612, 98)
        mtExamPer.Margin = New Padding(3, 4, 3, 4)
        mtExamPer.MaxLength = 3
        mtExamPer.Name = "mtExamPer"
        mtExamPer.Size = New Size(46, 20)
        mtExamPer.TabIndex = 124
        mtExamPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label21
        ' 
        Label21.AutoSize = True
        Label21.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label21.Location = New Point(309, 68)
        Label21.Name = "Label21"
        Label21.Size = New Size(21, 21)
        Label21.TabIndex = 123
        Label21.Text = "%"
        ' 
        ' mtExePer
        ' 
        mtExePer.BackColor = Color.GhostWhite
        mtExePer.BorderStyle = BorderStyle.None
        mtExePer.Enabled = False
        mtExePer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtExePer.Location = New Point(296, 209)
        mtExePer.Margin = New Padding(3, 4, 3, 4)
        mtExePer.MaxLength = 3
        mtExePer.Name = "mtExePer"
        mtExePer.Size = New Size(46, 20)
        mtExePer.TabIndex = 122
        mtExePer.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtQuizPer
        ' 
        mtQuizPer.BackColor = Color.GhostWhite
        mtQuizPer.BorderStyle = BorderStyle.None
        mtQuizPer.Enabled = False
        mtQuizPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtQuizPer.Location = New Point(296, 152)
        mtQuizPer.Margin = New Padding(3, 4, 3, 4)
        mtQuizPer.MaxLength = 3
        mtQuizPer.Name = "mtQuizPer"
        mtQuizPer.Size = New Size(46, 20)
        mtQuizPer.TabIndex = 121
        mtQuizPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtAttPer
        ' 
        mtAttPer.BackColor = Color.GhostWhite
        mtAttPer.BorderStyle = BorderStyle.None
        mtAttPer.Enabled = False
        mtAttPer.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtAttPer.Location = New Point(296, 98)
        mtAttPer.Margin = New Padding(3, 4, 3, 4)
        mtAttPer.MaxLength = 3
        mtAttPer.Name = "mtAttPer"
        mtAttPer.Size = New Size(46, 20)
        mtAttPer.TabIndex = 120
        mtAttPer.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label40
        ' 
        Label40.AutoSize = True
        Label40.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label40.Location = New Point(1273, 69)
        Label40.Name = "Label40"
        Label40.Size = New Size(21, 21)
        Label40.TabIndex = 119
        Label40.Text = "T"
        ' 
        ' Label41
        ' 
        Label41.AutoSize = True
        Label41.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label41.Location = New Point(1218, 69)
        Label41.Name = "Label41"
        Label41.Size = New Size(21, 21)
        Label41.TabIndex = 118
        Label41.Text = "S"
        ' 
        ' Label38
        ' 
        Label38.AutoSize = True
        Label38.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label38.Location = New Point(942, 68)
        Label38.Name = "Label38"
        Label38.Size = New Size(21, 21)
        Label38.TabIndex = 117
        Label38.Text = "T"
        ' 
        ' Label39
        ' 
        Label39.AutoSize = True
        Label39.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label39.Location = New Point(885, 68)
        Label39.Name = "Label39"
        Label39.Size = New Size(21, 21)
        Label39.TabIndex = 116
        Label39.Text = "S"
        ' 
        ' Label36
        ' 
        Label36.AutoSize = True
        Label36.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label36.Location = New Point(572, 69)
        Label36.Name = "Label36"
        Label36.Size = New Size(21, 21)
        Label36.TabIndex = 115
        Label36.Text = "T"
        ' 
        ' Label37
        ' 
        Label37.AutoSize = True
        Label37.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label37.Location = New Point(518, 69)
        Label37.Name = "Label37"
        Label37.Size = New Size(21, 21)
        Label37.TabIndex = 114
        Label37.Text = "S"
        ' 
        ' Label35
        ' 
        Label35.AutoSize = True
        Label35.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label35.Location = New Point(255, 68)
        Label35.Name = "Label35"
        Label35.Size = New Size(21, 21)
        Label35.TabIndex = 113
        Label35.Text = "T"
        ' 
        ' Label34
        ' 
        Label34.AutoSize = True
        Label34.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label34.Location = New Point(201, 68)
        Label34.Name = "Label34"
        Label34.Size = New Size(21, 21)
        Label34.TabIndex = 112
        Label34.Text = "S"
        ' 
        ' fProjOv
        ' 
        fProjOv.BackColor = SystemColors.Window
        fProjOv.BorderStyle = BorderStyle.FixedSingle
        fProjOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fProjOv.Location = New Point(1258, 152)
        fProjOv.Margin = New Padding(3, 4, 3, 4)
        fProjOv.MaxLength = 3
        fProjOv.Name = "fProjOv"
        fProjOv.Size = New Size(46, 27)
        fProjOv.TabIndex = 32
        fProjOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' fExamOv
        ' 
        fExamOv.BackColor = SystemColors.Window
        fExamOv.BorderStyle = BorderStyle.FixedSingle
        fExamOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fExamOv.Location = New Point(1258, 98)
        fExamOv.Margin = New Padding(3, 4, 3, 4)
        fExamOv.MaxLength = 3
        fExamOv.Name = "fExamOv"
        fExamOv.Size = New Size(46, 27)
        fExamOv.TabIndex = 30
        fExamOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' fExeOv
        ' 
        fExeOv.BackColor = SystemColors.Window
        fExeOv.BorderStyle = BorderStyle.FixedSingle
        fExeOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fExeOv.Location = New Point(930, 209)
        fExeOv.Margin = New Padding(3, 4, 3, 4)
        fExeOv.MaxLength = 3
        fExeOv.Name = "fExeOv"
        fExeOv.Size = New Size(46, 27)
        fExeOv.TabIndex = 26
        fExeOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtRecitOv
        ' 
        mtRecitOv.BackColor = SystemColors.Window
        mtRecitOv.BorderStyle = BorderStyle.FixedSingle
        mtRecitOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtRecitOv.Location = New Point(560, 209)
        mtRecitOv.Margin = New Padding(3, 4, 3, 4)
        mtRecitOv.MaxLength = 3
        mtRecitOv.Name = "mtRecitOv"
        mtRecitOv.Size = New Size(46, 27)
        mtRecitOv.TabIndex = 18
        mtRecitOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' fQuizOv
        ' 
        fQuizOv.BackColor = SystemColors.Window
        fQuizOv.BorderStyle = BorderStyle.FixedSingle
        fQuizOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fQuizOv.Location = New Point(930, 152)
        fQuizOv.Margin = New Padding(3, 4, 3, 4)
        fQuizOv.MaxLength = 3
        fQuizOv.Name = "fQuizOv"
        fQuizOv.Size = New Size(46, 27)
        fQuizOv.TabIndex = 24
        fQuizOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtCstudOv
        ' 
        mtCstudOv.BackColor = SystemColors.Window
        mtCstudOv.BorderStyle = BorderStyle.FixedSingle
        mtCstudOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtCstudOv.Location = New Point(560, 152)
        mtCstudOv.Margin = New Padding(3, 4, 3, 4)
        mtCstudOv.MaxLength = 3
        mtCstudOv.Name = "mtCstudOv"
        mtCstudOv.Size = New Size(46, 27)
        mtCstudOv.TabIndex = 16
        mtCstudOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' fAttOv
        ' 
        fAttOv.BackColor = SystemColors.Window
        fAttOv.BorderStyle = BorderStyle.FixedSingle
        fAttOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fAttOv.Location = New Point(930, 98)
        fAttOv.Margin = New Padding(3, 4, 3, 4)
        fAttOv.MaxLength = 3
        fAttOv.Name = "fAttOv"
        fAttOv.Size = New Size(46, 27)
        fAttOv.TabIndex = 22
        fAttOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtExamOv
        ' 
        mtExamOv.BackColor = SystemColors.Window
        mtExamOv.BorderStyle = BorderStyle.FixedSingle
        mtExamOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtExamOv.Location = New Point(560, 98)
        mtExamOv.Margin = New Padding(3, 4, 3, 4)
        mtExamOv.MaxLength = 3
        mtExamOv.Name = "mtExamOv"
        mtExamOv.Size = New Size(46, 27)
        mtExamOv.TabIndex = 14
        mtExamOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtExeOv
        ' 
        mtExeOv.BackColor = SystemColors.Window
        mtExeOv.BorderStyle = BorderStyle.FixedSingle
        mtExeOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtExeOv.Location = New Point(242, 209)
        mtExeOv.Margin = New Padding(3, 4, 3, 4)
        mtExeOv.MaxLength = 3
        mtExeOv.Name = "mtExeOv"
        mtExeOv.Size = New Size(46, 27)
        mtExeOv.TabIndex = 12
        mtExeOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtQuizOv
        ' 
        mtQuizOv.BackColor = SystemColors.Window
        mtQuizOv.BorderStyle = BorderStyle.FixedSingle
        mtQuizOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtQuizOv.Location = New Point(242, 152)
        mtQuizOv.Margin = New Padding(3, 4, 3, 4)
        mtQuizOv.MaxLength = 3
        mtQuizOv.Name = "mtQuizOv"
        mtQuizOv.Size = New Size(46, 27)
        mtQuizOv.TabIndex = 10
        mtQuizOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtAttOv
        ' 
        mtAttOv.BackColor = SystemColors.Window
        mtAttOv.BorderStyle = BorderStyle.FixedSingle
        mtAttOv.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtAttOv.Location = New Point(242, 98)
        mtAttOv.Margin = New Padding(3, 4, 3, 4)
        mtAttOv.MaxLength = 3
        mtAttOv.Name = "mtAttOv"
        mtAttOv.Size = New Size(46, 27)
        mtAttOv.TabIndex = 8
        mtAttOv.TextAlign = HorizontalAlignment.Center
        ' 
        ' fSub
        ' 
        fSub.BackColor = Color.AliceBlue
        fSub.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        fSub.Location = New Point(717, 289)
        fSub.Margin = New Padding(3, 4, 3, 4)
        fSub.Name = "fSub"
        fSub.Size = New Size(203, 58)
        fSub.TabIndex = 22
        fSub.Text = "Submit"
        fSub.UseVisualStyleBackColor = False
        ' 
        ' fClr
        ' 
        fClr.BackColor = Color.AliceBlue
        fClr.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        fClr.Location = New Point(926, 289)
        fClr.Margin = New Padding(3, 4, 3, 4)
        fClr.Name = "fClr"
        fClr.Size = New Size(203, 58)
        fClr.TabIndex = 90
        fClr.Text = "Clear"
        fClr.UseVisualStyleBackColor = False
        ' 
        ' fCmpt
        ' 
        fCmpt.BackColor = Color.AliceBlue
        fCmpt.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        fCmpt.Location = New Point(1135, 289)
        fCmpt.Margin = New Padding(3, 4, 3, 4)
        fCmpt.Name = "fCmpt"
        fCmpt.Size = New Size(203, 58)
        fCmpt.TabIndex = 21
        fCmpt.Text = "Compute"
        fCmpt.UseVisualStyleBackColor = False
        ' 
        ' mtSub
        ' 
        mtSub.BackColor = Color.AliceBlue
        mtSub.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        mtSub.Location = New Point(28, 289)
        mtSub.Margin = New Padding(3, 4, 3, 4)
        mtSub.Name = "mtSub"
        mtSub.Size = New Size(203, 58)
        mtSub.TabIndex = 21
        mtSub.Text = "Submit"
        mtSub.UseVisualStyleBackColor = False
        ' 
        ' mtClr
        ' 
        mtClr.BackColor = Color.AliceBlue
        mtClr.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        mtClr.Location = New Point(237, 289)
        mtClr.Margin = New Padding(3, 4, 3, 4)
        mtClr.Name = "mtClr"
        mtClr.Size = New Size(203, 58)
        mtClr.TabIndex = 90
        mtClr.Text = "Clear"
        mtClr.UseVisualStyleBackColor = False
        ' 
        ' fProj
        ' 
        fProj.BackColor = SystemColors.Window
        fProj.BorderStyle = BorderStyle.FixedSingle
        fProj.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fProj.Location = New Point(1201, 154)
        fProj.Margin = New Padding(3, 4, 3, 4)
        fProj.MaxLength = 3
        fProj.Name = "fProj"
        fProj.Size = New Size(48, 27)
        fProj.TabIndex = 33
        fProj.TextAlign = HorizontalAlignment.Center
        ' 
        ' fExam
        ' 
        fExam.BackColor = SystemColors.Window
        fExam.BorderStyle = BorderStyle.FixedSingle
        fExam.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fExam.Location = New Point(1201, 99)
        fExam.Margin = New Padding(3, 4, 3, 4)
        fExam.MaxLength = 3
        fExam.Name = "fExam"
        fExam.Size = New Size(48, 27)
        fExam.TabIndex = 31
        fExam.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label11.Location = New Point(1037, 156)
        Label11.Name = "Label11"
        Label11.Size = New Size(164, 21)
        Label11.TabIndex = 90
        Label11.Text = "Final Project:"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label12.Location = New Point(1037, 100)
        Label12.Name = "Label12"
        Label12.Size = New Size(142, 21)
        Label12.TabIndex = 90
        Label12.Text = "Finals Exam:"
        ' 
        ' fExe
        ' 
        fExe.BackColor = SystemColors.Window
        fExe.BorderStyle = BorderStyle.FixedSingle
        fExe.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fExe.Location = New Point(871, 209)
        fExe.Margin = New Padding(3, 4, 3, 4)
        fExe.MaxLength = 3
        fExe.Name = "fExe"
        fExe.Size = New Size(48, 27)
        fExe.TabIndex = 27
        fExe.TextAlign = HorizontalAlignment.Center
        ' 
        ' fQuiz
        ' 
        fQuiz.BackColor = SystemColors.Window
        fQuiz.BorderStyle = BorderStyle.FixedSingle
        fQuiz.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fQuiz.Location = New Point(871, 152)
        fQuiz.Margin = New Padding(3, 4, 3, 4)
        fQuiz.MaxLength = 3
        fQuiz.Name = "fQuiz"
        fQuiz.Size = New Size(48, 27)
        fQuiz.TabIndex = 25
        fQuiz.TextAlign = HorizontalAlignment.Center
        ' 
        ' fAtt
        ' 
        fAtt.BackColor = SystemColors.Window
        fAtt.BorderStyle = BorderStyle.FixedSingle
        fAtt.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        fAtt.Location = New Point(871, 98)
        fAtt.Margin = New Padding(3, 4, 3, 4)
        fAtt.MaxLength = 3
        fAtt.Name = "fAtt"
        fAtt.Size = New Size(48, 27)
        fAtt.TabIndex = 23
        fAtt.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label13.Location = New Point(708, 212)
        Label13.Name = "Label13"
        Label13.Size = New Size(164, 21)
        Label13.TabIndex = 90
        Label13.Text = "Lab Exercises:"
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label15.Location = New Point(708, 101)
        Label15.Name = "Label15"
        Label15.Size = New Size(131, 21)
        Label15.TabIndex = 90
        Label15.Text = "Attendance:"
        ' 
        ' mtCmpt
        ' 
        mtCmpt.BackColor = Color.AliceBlue
        mtCmpt.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        mtCmpt.Location = New Point(446, 289)
        mtCmpt.Margin = New Padding(3, 4, 3, 4)
        mtCmpt.Name = "mtCmpt"
        mtCmpt.Size = New Size(203, 58)
        mtCmpt.TabIndex = 20
        mtCmpt.Text = "Compute"
        mtCmpt.UseVisualStyleBackColor = False
        ' 
        ' mtRecit
        ' 
        mtRecit.BackColor = SystemColors.Window
        mtRecit.BorderStyle = BorderStyle.FixedSingle
        mtRecit.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtRecit.Location = New Point(504, 208)
        mtRecit.Margin = New Padding(3, 4, 3, 4)
        mtRecit.MaxLength = 3
        mtRecit.Name = "mtRecit"
        mtRecit.Size = New Size(48, 27)
        mtRecit.TabIndex = 19
        mtRecit.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtCstud
        ' 
        mtCstud.BackColor = SystemColors.Window
        mtCstud.BorderStyle = BorderStyle.FixedSingle
        mtCstud.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtCstud.Location = New Point(504, 154)
        mtCstud.Margin = New Padding(3, 4, 3, 4)
        mtCstud.MaxLength = 3
        mtCstud.Name = "mtCstud"
        mtCstud.Size = New Size(48, 27)
        mtCstud.TabIndex = 17
        mtCstud.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtExam
        ' 
        mtExam.BackColor = SystemColors.Window
        mtExam.BorderStyle = BorderStyle.FixedSingle
        mtExam.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtExam.Location = New Point(504, 99)
        mtExam.Margin = New Padding(3, 4, 3, 4)
        mtExam.MaxLength = 3
        mtExam.Name = "mtExam"
        mtExam.Size = New Size(48, 27)
        mtExam.TabIndex = 15
        mtExam.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label9.Location = New Point(353, 211)
        Label9.Name = "Label9"
        Label9.Size = New Size(131, 21)
        Label9.TabIndex = 90
        Label9.Text = "Recitation:"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label8.Location = New Point(353, 156)
        Label8.Name = "Label8"
        Label8.Size = New Size(153, 21)
        Label8.TabIndex = 90
        Label8.Text = "Case Study  :"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(353, 100)
        Label7.Name = "Label7"
        Label7.Size = New Size(153, 21)
        Label7.TabIndex = 90
        Label7.Text = "Midterm Exam:"
        ' 
        ' mtExe
        ' 
        mtExe.BackColor = SystemColors.Window
        mtExe.BorderStyle = BorderStyle.FixedSingle
        mtExe.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtExe.Location = New Point(186, 209)
        mtExe.Margin = New Padding(3, 4, 3, 4)
        mtExe.MaxLength = 3
        mtExe.Name = "mtExe"
        mtExe.Size = New Size(48, 27)
        mtExe.TabIndex = 13
        mtExe.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtQuiz
        ' 
        mtQuiz.BackColor = SystemColors.Window
        mtQuiz.BorderStyle = BorderStyle.FixedSingle
        mtQuiz.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtQuiz.Location = New Point(186, 152)
        mtQuiz.Margin = New Padding(3, 4, 3, 4)
        mtQuiz.MaxLength = 3
        mtQuiz.Name = "mtQuiz"
        mtQuiz.Size = New Size(48, 27)
        mtQuiz.TabIndex = 11
        mtQuiz.TextAlign = HorizontalAlignment.Center
        ' 
        ' mtAtt
        ' 
        mtAtt.BackColor = SystemColors.Window
        mtAtt.BorderStyle = BorderStyle.FixedSingle
        mtAtt.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        mtAtt.Location = New Point(186, 98)
        mtAtt.Margin = New Padding(3, 4, 3, 4)
        mtAtt.MaxLength = 3
        mtAtt.Name = "mtAtt"
        mtAtt.Size = New Size(48, 27)
        mtAtt.TabIndex = 9
        mtAtt.TextAlign = HorizontalAlignment.Center
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(24, 212)
        Label6.Name = "Label6"
        Label6.Size = New Size(164, 21)
        Label6.TabIndex = 90
        Label6.Text = "Lab Exercises:"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(24, 101)
        Label4.Name = "Label4"
        Label4.Size = New Size(131, 21)
        Label4.TabIndex = 90
        Label4.Text = "Attendance:"
        ' 
        ' TextBox6
        ' 
        TextBox6.BackColor = Color.Lavender
        TextBox6.BorderStyle = BorderStyle.FixedSingle
        TextBox6.Font = New Font("Courier New", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        TextBox6.Location = New Point(710, 21)
        TextBox6.Margin = New Padding(3, 4, 3, 4)
        TextBox6.Name = "TextBox6"
        TextBox6.ReadOnly = True
        TextBox6.Size = New Size(643, 34)
        TextBox6.TabIndex = 90
        TextBox6.Text = "FINALS"
        TextBox6.TextAlign = HorizontalAlignment.Center
        ' 
        ' TextBox5
        ' 
        TextBox5.BackColor = Color.Lavender
        TextBox5.BorderStyle = BorderStyle.FixedSingle
        TextBox5.Font = New Font("Courier New", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        TextBox5.Location = New Point(18, 21)
        TextBox5.Margin = New Padding(3, 4, 3, 4)
        TextBox5.Name = "TextBox5"
        TextBox5.ReadOnly = True
        TextBox5.Size = New Size(643, 34)
        TextBox5.TabIndex = 90
        TextBox5.Text = "MIDTERM"
        TextBox5.TextAlign = HorizontalAlignment.Center
        ' 
        ' Splitter1
        ' 
        Splitter1.BackColor = Color.GhostWhite
        Splitter1.BorderStyle = BorderStyle.FixedSingle
        Splitter1.Location = New Point(0, 0)
        Splitter1.Margin = New Padding(3, 4, 3, 4)
        Splitter1.Name = "Splitter1"
        Splitter1.Size = New Size(685, 382)
        Splitter1.TabIndex = 90
        Splitter1.TabStop = False
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(35, 189)
        Label3.Name = "Label3"
        Label3.Size = New Size(153, 21)
        Label3.TabIndex = 90
        Label3.Text = "Student Name:"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Courier New", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(35, 138)
        Label2.Name = "Label2"
        Label2.Size = New Size(131, 21)
        Label2.TabIndex = 90
        Label2.Text = "Student ID:"
        ' 
        ' sname
        ' 
        sname.BorderStyle = BorderStyle.FixedSingle
        sname.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        sname.Location = New Point(217, 180)
        sname.Margin = New Padding(3, 4, 3, 4)
        sname.MaxLength = 100
        sname.Name = "sname"
        sname.Size = New Size(264, 27)
        sname.TabIndex = 2
        ' 
        ' sid
        ' 
        sid.BorderStyle = BorderStyle.FixedSingle
        sid.Font = New Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        sid.Location = New Point(217, 131)
        sid.Margin = New Padding(3, 4, 3, 4)
        sid.MaxLength = 8
        sid.Name = "sid"
        sid.Size = New Size(264, 27)
        sid.TabIndex = 1
        ' 
        ' TextBox1
        ' 
        TextBox1.BackColor = Color.LightBlue
        TextBox1.Enabled = False
        TextBox1.Font = New Font("Courier New", 24F)
        TextBox1.Location = New Point(0, 0)
        TextBox1.Margin = New Padding(3, 4, 3, 4)
        TextBox1.Name = "TextBox1"
        TextBox1.ReadOnly = True
        TextBox1.Size = New Size(1447, 53)
        TextBox1.TabIndex = 90
        TextBox1.Text = "Grading System"
        TextBox1.TextAlign = HorizontalAlignment.Center
        ' 
        ' GradingSystem
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.SkyBlue
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(1469, 841)
        Controls.Add(Panel1)
        Margin = New Padding(3, 4, 3, 4)
        Name = "GradingSystem"
        StartPosition = FormStartPosition.CenterScreen
        Text = "gradingSystem"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents sname As TextBox
    Friend WithEvents sid As TextBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Splitter1 As Splitter
    Friend WithEvents Label6 As Label
    Friend WithEvents mtCmpt As Button
    Friend WithEvents mtRecit As TextBox
    Friend WithEvents mtCstud As TextBox
    Friend WithEvents mtExam As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents mtExe As TextBox
    Friend WithEvents mtQuiz As TextBox
    Friend WithEvents mtAtt As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents fProj As TextBox
    Friend WithEvents fExam As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents fExe As TextBox
    Friend WithEvents fQuiz As TextBox
    Friend WithEvents fAtt As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents fGrade As Label
    Friend WithEvents mtGrade As Label
    Friend WithEvents sgLbl As Label
    Friend WithEvents mtSub As Button
    Friend WithEvents mtClr As Button
    Friend WithEvents fSub As Button
    Friend WithEvents fClr As Button
    Friend WithEvents fCmpt As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents syr As ComboBox
    Friend WithEvents ssec As ComboBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents ssub As TextBox
    Friend WithEvents scrs As ComboBox
    Friend WithEvents ssem As ComboBox
    Friend WithEvents Label19 As Label
    Friend WithEvents fProjOv As TextBox
    Friend WithEvents fExamOv As TextBox
    Friend WithEvents fExeOv As TextBox
    Friend WithEvents mtRecitOv As TextBox
    Friend WithEvents fQuizOv As TextBox
    Friend WithEvents mtCstudOv As TextBox
    Friend WithEvents fAttOv As TextBox
    Friend WithEvents mtExamOv As TextBox
    Friend WithEvents mtExeOv As TextBox
    Friend WithEvents mtQuizOv As TextBox
    Friend WithEvents mtAttOv As TextBox
    Friend WithEvents Label33 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents fExePer As TextBox
    Friend WithEvents fQuizPer As TextBox
    Friend WithEvents fAttPer As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents mtRecitPer As TextBox
    Friend WithEvents mtCstudPer As TextBox
    Friend WithEvents mtExamPer As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents mtExePer As TextBox
    Friend WithEvents mtQuizPer As TextBox
    Friend WithEvents mtAttPer As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents fProjPer As TextBox
    Friend WithEvents fExamPer As TextBox
    Friend WithEvents semGrade As TextBox
    Friend WithEvents semPer As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents rmrks As TextBox
End Class
