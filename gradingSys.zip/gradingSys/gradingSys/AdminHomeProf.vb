﻿Public Class AdminHomeProf
    Public Property ParentForm As AdminHome
    Public Sub AdminHomeProf_Load(sender As Object, e As EventArgs) Handles Me.Load
        ParentForm?.RefreshData2()
    End Sub
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        ParentForm?.RefreshData2()
    End Sub


End Class