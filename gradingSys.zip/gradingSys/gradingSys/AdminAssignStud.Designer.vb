﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminAssignStud
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        EnrProfPnl = New Panel()
        Label12 = New Label()
        Label10 = New Label()
        Button2 = New Button()
        ComboBox8 = New ComboBox()
        Label11 = New Label()
        ComboBox9 = New ComboBox()
        ComboBox10 = New ComboBox()
        DataGridView1 = New DataGridView()
        EnrProfPnl.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' EnrProfPnl
        ' 
        EnrProfPnl.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        EnrProfPnl.Controls.Add(Label12)
        EnrProfPnl.Controls.Add(Label10)
        EnrProfPnl.Controls.Add(Button2)
        EnrProfPnl.Controls.Add(ComboBox8)
        EnrProfPnl.Controls.Add(Label11)
        EnrProfPnl.Controls.Add(ComboBox9)
        EnrProfPnl.Controls.Add(ComboBox10)
        EnrProfPnl.Enabled = False
        EnrProfPnl.Location = New Point(45, 23)
        EnrProfPnl.Name = "EnrProfPnl"
        EnrProfPnl.Size = New Size(707, 796)
        EnrProfPnl.TabIndex = 30
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label12.Location = New Point(91, 176)
        Label12.Name = "Label12"
        Label12.Size = New Size(109, 20)
        Label12.TabIndex = 76
        Label12.Text = "Department"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label10.Location = New Point(96, 347)
        Label10.Name = "Label10"
        Label10.Size = New Size(69, 20)
        Label10.TabIndex = 74
        Label10.Text = "Course"
        ' 
        ' Button2
        ' 
        Button2.Font = New Font("Cascadia Code", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button2.Location = New Point(84, 540)
        Button2.Name = "Button2"
        Button2.Size = New Size(535, 61)
        Button2.TabIndex = 50
        Button2.Text = "Assign Subject"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' ComboBox8
        ' 
        ComboBox8.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        ComboBox8.DropDownStyle = ComboBoxStyle.DropDownList
        ComboBox8.FlatStyle = FlatStyle.Flat
        ComboBox8.Font = New Font("Courier New", 10.2F)
        ComboBox8.FormattingEnabled = True
        ComboBox8.Items.AddRange(New Object() {"CCS", "CBA"})
        ComboBox8.Location = New Point(85, 366)
        ComboBox8.Name = "ComboBox8"
        ComboBox8.Size = New Size(534, 28)
        ComboBox8.TabIndex = 80
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label11.Location = New Point(91, 257)
        Label11.Name = "Label11"
        Label11.Size = New Size(99, 20)
        Label11.TabIndex = 78
        Label11.Text = "Professor"
        ' 
        ' ComboBox9
        ' 
        ComboBox9.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        ComboBox9.DropDownStyle = ComboBoxStyle.DropDownList
        ComboBox9.FlatStyle = FlatStyle.Flat
        ComboBox9.Font = New Font("Courier New", 10.2F)
        ComboBox9.FormattingEnabled = True
        ComboBox9.Items.AddRange(New Object() {"CCS", "CBA"})
        ComboBox9.Location = New Point(85, 276)
        ComboBox9.Name = "ComboBox9"
        ComboBox9.Size = New Size(534, 28)
        ComboBox9.TabIndex = 79
        ' 
        ' ComboBox10
        ' 
        ComboBox10.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        ComboBox10.DropDownStyle = ComboBoxStyle.DropDownList
        ComboBox10.FlatStyle = FlatStyle.Flat
        ComboBox10.Font = New Font("Courier New", 10.2F)
        ComboBox10.FormattingEnabled = True
        ComboBox10.Items.AddRange(New Object() {"CCS", "CBA"})
        ComboBox10.Location = New Point(85, 195)
        ComboBox10.Name = "ComboBox10"
        ComboBox10.Size = New Size(534, 28)
        ComboBox10.TabIndex = 77
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(794, 23)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowHeadersWidth = 51
        DataGridView1.Size = New Size(707, 796)
        DataGridView1.TabIndex = 81
        ' 
        ' AdminAssignStud
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(41), CByte(28), CByte(14))
        ClientSize = New Size(1548, 835)
        Controls.Add(DataGridView1)
        Controls.Add(EnrProfPnl)
        FormBorderStyle = FormBorderStyle.None
        Name = "AdminAssignStud"
        Text = "AdminAssignStud"
        EnrProfPnl.ResumeLayout(False)
        EnrProfPnl.PerformLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents EnrProfPnl As Panel
    Friend WithEvents Label12 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents ComboBox8 As ComboBox
    Friend WithEvents Label11 As Label
    Friend WithEvents ComboBox9 As ComboBox
    Friend WithEvents ComboBox10 As ComboBox
    Friend WithEvents DataGridView1 As DataGridView
End Class
