﻿Public Class AdminAssign
    Private Sub SNTxb_TextChanged(sender As Object, e As EventArgs)

    End Sub
End Class