﻿Imports System.Security.Cryptography
Imports System.Text.RegularExpressions
Imports MySql.Data.MySqlClient

Public Class AdminEnrollStud

    Dim dal As New DataAccessLayer()

    Private Sub GenPwBtn_Click(sender As Object, e As EventArgs) Handles GenPwBtn.Click
        Dim studentNumber = SNTxb.Text
        Dim firstName = FnameTxb.Text
        Dim middleName = MnameTxb.Text
        Dim surName = SnameTxb.Text.Replace(" ", "")

        If String.IsNullOrEmpty(studentNumber) OrElse
           String.IsNullOrEmpty(firstName) OrElse
           String.IsNullOrEmpty(middleName) OrElse
           String.IsNullOrEmpty(surName) Then
            MessageBox.Show("Please fill in all fields before generating the password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        Dim firstInitials = ""
        Dim firstNameParts = firstName.Split(" "c)
        For Each namePart In firstNameParts
            firstInitials &= namePart.Substring(0, 1).ToUpper
        Next
        Dim middleInitials = ""
        Dim middleNameParts = middleName.Split(" "c)
        For Each namePart In middleNameParts
            middleInitials &= namePart.Substring(0, 1).ToLower
            If middleInitials.Length >= 2 Then
                Exit For
            End If
        Next
        Dim password = $"{studentNumber}@{firstInitials}{middleInitials}{surName}"

        PwTxb.Text = password
    End Sub

    Private Sub AdminEnrollStud_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        EnrollStudentsGV.AllowUserToResizeColumns = False
        EnrollStudentsGV.AllowUserToResizeRows = False
        EnrollStudentsGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        RefreshData()
        LoadDepartments()
    End Sub

    Private Sub LoadDepartments()
        Try
            DeptCmb.Items.Clear()

            Dim query As String = "SELECT DepartmentName FROM departments"

            Using conn As MySqlConnection = moduleDB.GetConnection()
                conn.Open()
                Using cmd As New MySqlCommand(query, conn)
                    Using reader As MySqlDataReader = cmd.ExecuteReader()
                        While reader.Read()
                            DeptCmb.Items.Add(reader("DepartmentName").ToString())
                        End While
                    End Using
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show("Failed to load departments: " & ex.Message)
        End Try
    End Sub

    Private Sub RefreshData()
        Dim dataTable As DataTable = dal.GetStudents()
        EnrollStudentsGV.DataSource = dataTable

        AdjustColumnSizesByIndex()
    End Sub
    Private Sub AdjustColumnSizesByIndex()
        For colIndex As Integer = 0 To EnrollStudentsGV.Columns.Count - 1
            Dim column As DataGridViewColumn = EnrollStudentsGV.Columns(colIndex)

            Select Case colIndex
                Case 0
                    column.Width = 30
                Case 1
                    column.Width = 30
                Case 2
                    column.Width = 30
                Case 3
                    column.Width = 30
                Case 4
                    column.Width = 20
                Case 5
                    column.Width = 20
                Case 6
                    column.Width = 20
                Case 8
                    column.Width = 200
                Case Else
                    column.Width = 50
            End Select
        Next
    End Sub


    Private Sub EnrollStudentsGV_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles EnrollStudentsGV.CellClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = EnrollStudentsGV.Rows(e.RowIndex)
            SNTxb.Text = row.Cells("StudentID").Value.ToString()
            FnameTxb.Text = row.Cells("FName").Value.ToString()
            MnameTxb.Text = row.Cells("MName").Value.ToString()
            SnameTxb.Text = row.Cells("LName").Value.ToString()
            ProgCmb.Text = row.Cells("Program").Value.ToString()
            YearCmb.Text = row.Cells("Year").Value.ToString()
            SecCmb.Text = row.Cells("Section").Value.ToString()
            DeptCmb.Text = row.Cells("DepartmentName").Value.ToString()
            PwTxb.Text = row.Cells("Password").Value.ToString()
        End If
    End Sub

    Private Sub EnrollStudBtn_Click(sender As Object, e As EventArgs) Handles EnrollStudBtn.Click
        ' Check if all required fields are filled
        If Not IsNullOrWhiteSpace(SNTxb.Text) AndAlso
       Not IsNullOrWhiteSpace(FnameTxb.Text) AndAlso
       Not IsNullOrWhiteSpace(MnameTxb.Text) AndAlso
       Not IsNullOrWhiteSpace(SnameTxb.Text) AndAlso
       Not IsNullOrWhiteSpace(ProgCmb.Text) AndAlso
       Not IsNullOrWhiteSpace(YearCmb.Text) AndAlso
       Not IsNullOrWhiteSpace(SecCmb.Text) AndAlso
       Not IsNullOrWhiteSpace(DeptCmb.Text) AndAlso
       Not IsNullOrWhiteSpace(PwTxb.Text) Then

            ' Find the ClassID based on Year, Section (removed AcademicYearID from the query)
            Dim classID As Integer
            Dim query As String = "SELECT ClassID FROM classes 
                               WHERE Year = @Year 
                               AND Section = @Section"

            Using conn As MySqlConnection = moduleDB.GetConnection()
                conn.Open()
                Using cmd As New MySqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@Year", Convert.ToInt32(YearCmb.Text))
                    cmd.Parameters.AddWithValue("@Section", SecCmb.Text)
                    classID = Convert.ToInt32(cmd.ExecuteScalar())
                End Using
            End Using

            If classID > 0 Then
                ' Fetch DepartmentID based on the DepartmentName selected from DeptCmb
                Dim departmentID As Integer
                Dim deptQuery As String = "SELECT DepartmentID FROM departments WHERE DepartmentName = @DeptName"
                Using conn As MySqlConnection = moduleDB.GetConnection()
                    conn.Open()
                    Using cmd As New MySqlCommand(deptQuery, conn)
                        cmd.Parameters.AddWithValue("@DeptName", DeptCmb.Text)
                        departmentID = Convert.ToInt32(cmd.ExecuteScalar())
                    End Using
                End Using

                ' Now call SaveStudentWithPassword with all 9 required parameters (including password)
                Dim result As Boolean = dal.SaveStudentWithPassword(SNTxb.Text, FnameTxb.Text, MnameTxb.Text, SnameTxb.Text,
                                                        ProgCmb.Text, Convert.ToInt32(YearCmb.Text), SecCmb.Text, DeptCmb.Text,
                                                        PwTxb.Text) ' Pass the password

                If result Then
                    MessageBox.Show("Record saved successfully!")
                    RefreshData() ' Assuming this refreshes the data grid or list view
                Else
                    MessageBox.Show("The password already exists. Please regenerate a unique password.", "Duplicate Password", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End If
            Else
                MessageBox.Show("The class for the selected year and section does not exist.", "Class Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Else
            MessageBox.Show("Please fill in all the fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub




    Private Function IsNullOrWhiteSpace(value As String) As Boolean
        Return String.IsNullOrWhiteSpace(value)
    End Function

    Private Sub SNTxb_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles SNTxb.Validating
        If SNTxb.Text = "" Then
        Else
            Dim pattern As String = "^\d{2}-\d{5}$"

            If SNTxb.Text.Length < 8 Then
                MessageBox.Show("Input must be exactly 8 characters long.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                e.Cancel = True ' Prevents the focus from leaving the TextBox
                Exit Sub
            End If

            Dim isValid As Boolean = Regex.IsMatch(SNTxb.Text, pattern)

            If Not isValid Then
                MessageBox.Show("Invalid input! Please use the format 00-00000.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                e.Cancel = True
            End If
        End If
    End Sub

    Private Sub SNTxb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles SNTxb.KeyPress
        moduleDB.isNum(sender, e)
    End Sub

    Private Sub ClrBtn_Click(sender As Object, e As EventArgs) Handles ClrBtn.Click
        If Not String.IsNullOrWhiteSpace(SNTxb.Text) OrElse
           Not String.IsNullOrWhiteSpace(FnameTxb.Text) OrElse
           Not String.IsNullOrWhiteSpace(MnameTxb.Text) OrElse
           Not String.IsNullOrWhiteSpace(SnameTxb.Text) OrElse
           Not String.IsNullOrWhiteSpace(ProgCmb.Text) OrElse
           Not String.IsNullOrWhiteSpace(YearCmb.Text) OrElse
           Not String.IsNullOrWhiteSpace(SecCmb.Text) OrElse
           Not String.IsNullOrWhiteSpace(DeptCmb.Text) OrElse
           Not String.IsNullOrWhiteSpace(PwTxb.Text) Then

            Dim result As DialogResult = MessageBox.Show("Are you sure you want to clear all fields? Your data will not be saved.",
                                                         "Confirm Action",
                                                         MessageBoxButtons.YesNo,
                                                         MessageBoxIcon.Warning)

            If result = DialogResult.Yes Then
                SNTxb.Text = ""
                FnameTxb.Text = ""
                MnameTxb.Text = ""
                SnameTxb.Text = ""
                ProgCmb.Text = ""
                YearCmb.Text = ""
                SecCmb.Text = ""
                DeptCmb.Text = ""
                PwTxb.Text = ""
            End If
        End If
    End Sub
    Private Sub SecCmb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles SecCmb.KeyPress, ProgCmb.KeyPress, DeptCmb.KeyPress, YearCmb.KeyPress
        e.Handled = True
    End Sub

    Private Sub NameTxb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles MnameTxb.KeyPress, SnameTxb.KeyPress, FnameTxb.KeyPress
        moduleDB.isLet(sender, e)
    End Sub

    Private Sub FnameTxb_TextChanged(sender As Object, e As EventArgs) Handles FnameTxb.TextChanged
        moduleDB.cap(FnameTxb)
    End Sub

    Private Sub MnameTxb_TextChanged(sender As Object, e As EventArgs) Handles MnameTxb.TextChanged
        moduleDB.cap(MnameTxb)
    End Sub

    Private Sub SnameTxb_TextChanged(sender As Object, e As EventArgs) Handles SnameTxb.TextChanged
        moduleDB.cap(SnameTxb)
    End Sub

    Private Sub DeptCmb_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DeptCmb.SelectedIndexChanged

    End Sub

    Private Sub ProgCmb_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ProgCmb.SelectedIndexChanged
        If ProgCmb.Text = "BSIT" Then
            DeptCmb.Text = "College of Computer Studies"
        ElseIf ProgCmb.Text = "BSCS" Then
            DeptCmb.Text = "College of Computer Studies"
        ElseIf ProgCmb.Text = "BSN" Then
            DeptCmb.Text = "College of Nursing"
        End If
    End Sub
End Class
