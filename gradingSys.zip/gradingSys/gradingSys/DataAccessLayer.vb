﻿Imports MySql.Data.MySqlClient

Public Class DataAccessLayer
    ' Fetch student data including passwords
    Public Function GetStudents() As DataTable
        Using conn As MySqlConnection = moduleDB.GetConnection()
            ' Updated query to fetch student details along with class and department information
            Dim query As String = "SELECT s.StudentID, s.FName, s.MName, s.LName, 
                                  c.Program, c.Year, c.Section, 
                                  d.DepartmentName, u.Password
                               FROM students s
                               JOIN classes c ON s.ClassID = c.ClassID
                               JOIN departments d ON s.DepartmentID = d.DepartmentID
                               LEFT JOIN users u ON s.StudentID = u.StudentID"
            Dim cmd As New MySqlCommand(query, conn)
            Dim adapter As New MySqlDataAdapter(cmd)
            Dim table As New DataTable()
            adapter.Fill(table)
            Return table
        End Using
    End Function





    ' Save or update student and user data
    Public Function SaveStudentWithPassword(studentID As String, fname As String, mname As String, lname As String,
                              program As String, year As Integer, section As String, departmentName As String,
                              password As String) As Boolean

        Using conn As MySqlConnection = moduleDB.GetConnection()
            conn.Open()

            ' Check if the password is different from the current one
            Dim currentPasswordCmd As New MySqlCommand("SELECT Password FROM users WHERE StudentID = @StudentID", conn)
            currentPasswordCmd.Parameters.AddWithValue("@StudentID", studentID)
            Dim currentPassword As String = Convert.ToString(currentPasswordCmd.ExecuteScalar())

            If password <> currentPassword Then
                Dim checkPasswordCmd As New MySqlCommand("SELECT COUNT(*) FROM users WHERE Password = @Password", conn)
                checkPasswordCmd.Parameters.AddWithValue("@Password", password)
                Dim passwordExists As Integer = Convert.ToInt32(checkPasswordCmd.ExecuteScalar())

                If passwordExists > 0 Then
                    Return False ' Password already exists
                End If
            End If

            ' Ensure the class exists or create it
            Dim classID As Integer
            Dim checkClassCmd As New MySqlCommand("SELECT ClassID FROM classes 
                                               
                                               WHERE Year = @Year 
                                               AND Section = @Section
                                               AND Program = @Program", conn)
            checkClassCmd.Parameters.AddWithValue("@Year", year)
            checkClassCmd.Parameters.AddWithValue("@Section", section)
            checkClassCmd.Parameters.AddWithValue("@Program", program)
            Dim result As Object = checkClassCmd.ExecuteScalar()

            If result Is Nothing Then
                ' Class doesn't exist, create it
                Dim insertClassCmd As New MySqlCommand("INSERT INTO classes (Year, Section, Program) 
                                                   VALUES (@Year, @Section,@Program);
                                                   SELECT LAST_INSERT_ID();", conn) ' Removed AcademicYearID
                insertClassCmd.Parameters.AddWithValue("@Year", year)
                insertClassCmd.Parameters.AddWithValue("@Section", section)
                insertClassCmd.Parameters.AddWithValue("@Program", program)
                classID = Convert.ToInt32(insertClassCmd.ExecuteScalar())
            Else
                classID = Convert.ToInt32(result)
            End If

            ' Ensure the department exists or get the DepartmentID
            Dim departmentID As Integer
            Dim checkDepartmentCmd As New MySqlCommand("SELECT DepartmentID FROM departments WHERE DepartmentName = @DeptName", conn)
            checkDepartmentCmd.Parameters.AddWithValue("@DeptName", departmentName)
            departmentID = Convert.ToInt32(checkDepartmentCmd.ExecuteScalar())

            If departmentID = 0 Then
                Return False ' Department doesn't exist
            End If

            ' Check if the student exists
            Dim checkStudentCmd As New MySqlCommand("SELECT COUNT(*) FROM students WHERE StudentID = @StudentID", conn)
            checkStudentCmd.Parameters.AddWithValue("@StudentID", studentID)
            Dim studentExists As Integer = Convert.ToInt32(checkStudentCmd.ExecuteScalar())

            If studentExists > 0 Then
                ' Update existing student
                Dim updateStudentCmd As New MySqlCommand("UPDATE students 
                                             SET FName = @FName, MName = @MName, LName = @LName, 
                                                 ClassID = @ClassID, 
                                                 DepartmentID = @DepartmentID
                                             WHERE StudentID = @StudentID", conn)
                updateStudentCmd.Parameters.AddWithValue("@FName", fname)
                updateStudentCmd.Parameters.AddWithValue("@MName", mname)
                updateStudentCmd.Parameters.AddWithValue("@LName", lname)
                updateStudentCmd.Parameters.AddWithValue("@ClassID", classID)
                updateStudentCmd.Parameters.AddWithValue("@DepartmentID", departmentID)
                updateStudentCmd.Parameters.AddWithValue("@StudentID", studentID)
                updateStudentCmd.ExecuteNonQuery()
            Else
                ' Insert new student
                Dim insertStudentCmd As New MySqlCommand("INSERT INTO students 
                                             (StudentID, FName, MName, LName, Program, ClassID, DepartmentID)
                                             VALUES (@StudentID, @FName, @MName, @LName, @Program, @ClassID, @DepartmentID)", conn)
                insertStudentCmd.Parameters.AddWithValue("@StudentID", studentID)
                insertStudentCmd.Parameters.AddWithValue("@FName", fname)
                insertStudentCmd.Parameters.AddWithValue("@MName", mname)
                insertStudentCmd.Parameters.AddWithValue("@LName", lname)
                insertStudentCmd.Parameters.AddWithValue("@ClassID", classID)
                insertStudentCmd.Parameters.AddWithValue("@DepartmentID", departmentID)
                insertStudentCmd.ExecuteNonQuery()
            End If

            ' Check if the user exists
            Dim checkUserCmd As New MySqlCommand("SELECT COUNT(*) FROM users WHERE StudentID = @StudentID", conn)
            checkUserCmd.Parameters.AddWithValue("@StudentID", studentID)
            Dim userExists As Integer = Convert.ToInt32(checkUserCmd.ExecuteScalar())

            If userExists > 0 Then
                ' Update password if necessary
                If password <> currentPassword Then
                    Dim updateUserCmd As New MySqlCommand("UPDATE users SET Password = @Password WHERE StudentID = @StudentID", conn)
                    updateUserCmd.Parameters.AddWithValue("@Password", password)
                    updateUserCmd.Parameters.AddWithValue("@StudentID", studentID)
                    updateUserCmd.ExecuteNonQuery()
                End If
            Else
                ' Insert new user
                Dim insertUserCmd As New MySqlCommand("INSERT INTO users (StudentID, Password, Role) 
                                           VALUES (@StudentID, @Password, 'Student')", conn)
                insertUserCmd.Parameters.AddWithValue("@StudentID", studentID)
                insertUserCmd.Parameters.AddWithValue("@Password", password)
                insertUserCmd.ExecuteNonQuery()
            End If
        End Using
        Return True ' Success
    End Function



    Public Function SaveOrUpdateProfessor(facultyID As String, fName As String, mName As String, lName As String, departmentName As String, password As String) As Boolean
        Using conn As MySqlConnection = moduleDB.GetConnection()
            conn.Open()

            ' Check if the current password exists
            Dim currentPasswordCmd As New MySqlCommand("SELECT Password FROM users WHERE FacultyID = @FacultyID", conn)
            currentPasswordCmd.Parameters.AddWithValue("@FacultyID", facultyID)
            Dim currentPassword As String = Convert.ToString(currentPasswordCmd.ExecuteScalar())

            ' If the password is different, check for duplicates
            If password <> currentPassword Then
                Dim checkPasswordCmd As New MySqlCommand("SELECT COUNT(*) FROM users WHERE Password = @Password", conn)
                checkPasswordCmd.Parameters.AddWithValue("@Password", password)
                Dim passwordExists As Integer = Convert.ToInt32(checkPasswordCmd.ExecuteScalar())

                If passwordExists > 0 Then
                    ' Duplicate password found
                    Return False
                End If
            End If

            ' Check if facultyID exists
            Dim checkFacultyCmd As New MySqlCommand("SELECT COUNT(*) FROM faculty WHERE FacultyID = @FacultyID", conn)
            checkFacultyCmd.Parameters.AddWithValue("@FacultyID", facultyID)
            Dim facultyExists As Integer = Convert.ToInt32(checkFacultyCmd.ExecuteScalar())

            If facultyExists > 0 Then
                ' Update the professor record
                Dim checkNameCmd As New MySqlCommand("SELECT COUNT(*) FROM faculty 
                                              WHERE prof_FName = @prof_FName AND prof_MName = @prof_MName AND prof_LName = @prof_LName 
                                              AND DepartmentID = (SELECT DepartmentID FROM departments WHERE DepartmentName = @DeptName)", conn)
                checkNameCmd.Parameters.AddWithValue("@prof_FName", fName)
                checkNameCmd.Parameters.AddWithValue("@prof_MName", mName)
                checkNameCmd.Parameters.AddWithValue("@prof_LName", lName)
                checkNameCmd.Parameters.AddWithValue("@DeptName", departmentName)
                Dim nameExists As Integer = Convert.ToInt32(checkNameCmd.ExecuteScalar())

                If nameExists > 0 Then
                    ' Duplicate professor found
                    Return False

                End If


                Dim updateCmd As New MySqlCommand("UPDATE faculty 
                                           SET prof_FName = @prof_FName, prof_MName = @prof_MName, prof_LName = @prof_LName, 
                                               DepartmentID = (SELECT DepartmentID FROM departments WHERE DepartmentName = @DeptName) 
                                           WHERE FacultyID = @FacultyID", conn)
                updateCmd.Parameters.AddWithValue("@prof_FName", fName)
                updateCmd.Parameters.AddWithValue("@prof_MName", mName)
                updateCmd.Parameters.AddWithValue("@prof_LName", lName)
                updateCmd.Parameters.AddWithValue("@DeptName", departmentName)
                updateCmd.Parameters.AddWithValue("@FacultyID", facultyID)
                updateCmd.ExecuteNonQuery()

                ' Update the password in the users table if it has changed
                If password <> currentPassword Then
                    Dim updateUserCmd As New MySqlCommand("UPDATE users SET Password = @Password WHERE FacultyID = @FacultyID", conn)
                    updateUserCmd.Parameters.AddWithValue("@Password", password)
                    updateUserCmd.Parameters.AddWithValue("@FacultyID", facultyID)
                    updateUserCmd.ExecuteNonQuery()
                End If
            Else
                ' Check if a professor with the same name exists in the same department
                Dim checkNameCmd As New MySqlCommand("SELECT COUNT(*) FROM faculty 
                                              WHERE prof_FName = @prof_FName AND prof_MName = @prof_MName AND prof_LName = @prof_LName 
                                              AND DepartmentID = (SELECT DepartmentID FROM departments WHERE DepartmentName = @DeptName)", conn)
                checkNameCmd.Parameters.AddWithValue("@prof_FName", fName)
                checkNameCmd.Parameters.AddWithValue("@prof_MName", mName)
                checkNameCmd.Parameters.AddWithValue("@prof_LName", lName)
                checkNameCmd.Parameters.AddWithValue("@DeptName", departmentName)
                Dim nameExists As Integer = Convert.ToInt32(checkNameCmd.ExecuteScalar())

                If nameExists > 0 Then
                    ' Duplicate professor found
                    Return False
                Else
                    ' Insert a new professor record
                    Dim insertCmd As New MySqlCommand("INSERT INTO faculty (FacultyID, prof_FName, prof_MName, prof_LName, DepartmentID) 
                                               VALUES (@FacultyID, @prof_FName, @prof_MName, @prof_LName, 
                                               (SELECT DepartmentID FROM departments WHERE DepartmentName = @DeptName))", conn)
                    insertCmd.Parameters.AddWithValue("@FacultyID", facultyID)
                    insertCmd.Parameters.AddWithValue("@prof_FName", fName)
                    insertCmd.Parameters.AddWithValue("@prof_MName", mName)
                    insertCmd.Parameters.AddWithValue("@prof_LName", lName)
                    insertCmd.Parameters.AddWithValue("@DeptName", departmentName)
                    insertCmd.ExecuteNonQuery()

                    ' Insert a new password for the professor in the users table
                    Dim insertUserCmd As New MySqlCommand("INSERT INTO users (FacultyID, Password, Role) VALUES (@FacultyID, @Password, 'Professor')", conn)
                    insertUserCmd.Parameters.AddWithValue("@FacultyID", facultyID)
                    insertUserCmd.Parameters.AddWithValue("@Password", password)
                    insertUserCmd.ExecuteNonQuery()
                End If
            End If

            Return True
        End Using
    End Function



    Public Function GetProfessors() As DataTable
        Dim query As String = "
        SELECT 
            f.FacultyID, 
            f.prof_FName AS Prof_FName, 
            f.prof_MName AS Prof_MName, 
            f.prof_LName AS Prof_LName, 
            d.DepartmentName AS DepartmentName,
            u.Password
        FROM 
            faculty f
        LEFT JOIN 
            departments d ON f.DepartmentID = d.DepartmentID
        LEFT JOIN 
            users u ON f.FacultyID = u.FacultyID
    "

        Dim dataTable As New DataTable()

        Using conn As MySqlConnection = moduleDB.GetConnection()
            conn.Open()
            Using cmd As New MySqlCommand(query, conn)
                Using adapter As New MySqlDataAdapter(cmd)
                    adapter.Fill(dataTable)
                End Using
            End Using
        End Using

        Return dataTable
    End Function

    Public Function GetProfessors2() As DataTable
        Dim query As String = "
        SELECT 
            f.FacultyID, 
            f.prof_FName AS First_Name, 
            f.prof_MName AS Middle_Name, 
            f.prof_LName AS Last_Name, 
            d.DepartmentName AS Department_Name,
            c.CourseCode AS Course
        FROM 
            faculty f
        INNER JOIN 
            departments d ON f.DepartmentID = d.DepartmentID
        INNER JOIN 
            assignments a ON f.FacultyID = a.FacultyID
        INNER JOIN 
            Courses c ON a.CourseID = c.CourseID;

    "

        Dim dataTable As New DataTable()

        Using conn As MySqlConnection = moduleDB.GetConnection()
            conn.Open()
            Using cmd As New MySqlCommand(query, conn)
                Using adapter As New MySqlDataAdapter(cmd)
                    adapter.Fill(dataTable)
                End Using
            End Using
        End Using

        Return dataTable
    End Function

End Class
