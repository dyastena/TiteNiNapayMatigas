﻿Imports System.Runtime.InteropServices.JavaScript.JSType

Public Class Form1
    Public valid As Boolean = False
    Dim Sliding As Boolean = False
    Dim SlideSpeed As Integer = 40
    Dim Timer1 As New Timer()
    Dim SlideToLeft As Boolean = True
    Dim OriginalPanelPosition As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        OriginalPanelPosition = Panel3.Left ' Store the original position of Panel3
        Timer1.Interval = 10
        AddHandler Timer1.Tick, AddressOf Timer1_Tick
        AddHandler LinkLabelAdmin.Click, AddressOf LinkLabelAdmin_Click
        AddHandler Button5.Click, AddressOf Button5_Click
    End Sub

    Private Sub LinkLabelAdmin_Click(sender As Object, e As EventArgs)
        If Not Sliding Then
            Sliding = True
            SlideToLeft = True
            Timer1.Start()
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs)
        If Not Sliding Then
            Sliding = True
            SlideToLeft = False
            Timer1.Start()
        End If
    End Sub


    Private Sub Timer1_Tick(sender As Object, e As EventArgs)
        If SlideToLeft Then
            If Panel3.Left > Me.Left Then
                Panel3.Left -= SlideSpeed
            Else
                Panel3.Left = Me.Left
                Timer1.Stop()
                Sliding = False
            End If
        Else
            If Panel3.Left < OriginalPanelPosition Then
                Panel3.Left += SlideSpeed
            Else
                Panel3.Left = OriginalPanelPosition
                Timer1.Stop()
                Sliding = False
            End If
        End If
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint
        ApplyRoundedCorners(Panel1, 100)
    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint
        ApplyRoundedCorners(Panel2, 50)
    End Sub

    Private Sub Panel3_Paint(sender As Object, e As PaintEventArgs) Handles Panel3.Paint
        ApplyRoundedCorners(Panel3, 100)
    End Sub

    Private Sub Panel5_Paint(sender As Object, e As PaintEventArgs) Handles Panel5.Paint
        ApplyRoundedCorners(Panel5, 40)
    End Sub

    Private Sub Panel6_Paint(sender As Object, e As PaintEventArgs) Handles Panel6.Paint
        ApplyRoundedCorners(Panel6, 40)
    End Sub

    Private Sub ApplyRoundedCorners(control As Control, cornerRadius As Integer)
        Dim panelWidth As Integer = control.Width
        Dim panelHeight As Integer = control.Height
        Dim path As New Drawing2D.GraphicsPath()

        path.AddArc(0, 0, cornerRadius, cornerRadius, 180, 90)
        path.AddArc(panelWidth - cornerRadius, 0, cornerRadius, cornerRadius, 270, 90)
        path.AddArc(panelWidth - cornerRadius, panelHeight - cornerRadius, cornerRadius, cornerRadius, 0, 90)
        path.AddArc(0, panelHeight - cornerRadius, cornerRadius, cornerRadius, 90, 90)

        path.CloseAllFigures()
        control.Region = New Region(path)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If pwTx.PasswordChar = "*"c Then
            pwTx.PasswordChar = ControlChars.NullChar
        Else
            pwTx.PasswordChar = "*"c
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Hide()
        AdminForm.Show()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim user = "student"
        Dim pass = "pass"

        Dim userProf = "prof"
        Dim passProf = "pwprof"

        Dim username As String
        Dim password As String

        username = usernameTx.Text
        password = pwTx.Text



        If usernameTx.Text = "" OrElse pwTx.Text = "" Then
            MessageBox.Show("ERROR! No data", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            If (username.Equals(user) And password.Equals(pass)) Then
                MessageBox.Show("Login Success!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Me.Hide()
                StudentForm.Show()
            ElseIf (username.Equals(userProf) And password.Equals(passprof)) Then
                MessageBox.Show("Login Success!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Me.Hide()
                ProfessorForm.Show()
            Else
                MessageBox.Show("ERROR! Invalid username or password", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub
End Class
