﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminHome
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        ProfBtn = New Button()
        Panel2 = New Panel()
        Label3 = New Label()
        Label2 = New Label()
        AdminHomeGV = New DataGridView()
        StudBtn = New Button()
        AdminHomePanel = New Panel()
        Panel2.SuspendLayout()
        CType(AdminHomeGV, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' ProfBtn
        ' 
        ProfBtn.Font = New Font("Cascadia Code", 16.2F)
        ProfBtn.Location = New Point(778, 71)
        ProfBtn.Name = "ProfBtn"
        ProfBtn.Size = New Size(754, 98)
        ProfBtn.TabIndex = 12
        ProfBtn.Text = "Professors"
        ProfBtn.UseVisualStyleBackColor = True
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.FromArgb(CByte(167), CByte(141), CByte(120))
        Panel2.Controls.Add(Label3)
        Panel2.Controls.Add(Label2)
        Panel2.Location = New Point(12, 3)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(1520, 54)
        Panel2.TabIndex = 9
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(22, 18)
        Label3.Name = "Label3"
        Label3.Size = New Size(49, 20)
        Label3.TabIndex = 7
        Label3.Text = "Home"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Cascadia Mono", 16.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(1259, 6)
        Label2.Name = "Label2"
        Label2.Size = New Size(241, 37)
        Label2.TabIndex = 6
        Label2.Text = "Hi, Superadmin"
        ' 
        ' AdminHomeGV
        ' 
        AdminHomeGV.AllowUserToAddRows = False
        AdminHomeGV.AllowUserToDeleteRows = False
        AdminHomeGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        AdminHomeGV.BackgroundColor = Color.FromArgb(CByte(190), CByte(181), CByte(169))
        AdminHomeGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        AdminHomeGV.Location = New Point(12, 186)
        AdminHomeGV.Name = "AdminHomeGV"
        AdminHomeGV.RowHeadersWidth = 51
        AdminHomeGV.Size = New Size(1520, 745)
        AdminHomeGV.TabIndex = 11
        ' 
        ' StudBtn
        ' 
        StudBtn.Font = New Font("Cascadia Code", 16.2F)
        StudBtn.Location = New Point(12, 71)
        StudBtn.Name = "StudBtn"
        StudBtn.Size = New Size(754, 98)
        StudBtn.TabIndex = 10
        StudBtn.Text = "Students"
        StudBtn.UseVisualStyleBackColor = True
        ' 
        ' AdminHomePanel
        ' 
        AdminHomePanel.Location = New Point(12, 938)
        AdminHomePanel.Name = "AdminHomePanel"
        AdminHomePanel.Size = New Size(1520, 62)
        AdminHomePanel.TabIndex = 16
        ' 
        ' AdminHome
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(41), CByte(28), CByte(14))
        ClientSize = New Size(1544, 1001)
        Controls.Add(AdminHomePanel)
        Controls.Add(ProfBtn)
        Controls.Add(Panel2)
        Controls.Add(AdminHomeGV)
        Controls.Add(StudBtn)
        FormBorderStyle = FormBorderStyle.None
        Name = "AdminHome"
        Text = "AdminHome"
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        CType(AdminHomeGV, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents ProfBtn As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents AdminHomeGV As DataGridView
    Friend WithEvents StudBtn As Button
    Friend WithEvents AdminHomePanel As Panel
End Class
