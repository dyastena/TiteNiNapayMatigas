﻿Imports System.Text.RegularExpressions
Imports MySql.Data.MySqlClient

Public Class AdminEnrollProf

    Dim dal As New DataAccessLayer()

    Private Sub AdminEnrollProf_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        EnrollProfessorGV.AllowUserToResizeColumns = False
        EnrollProfessorGV.AllowUserToResizeRows = False
        EnrollProfessorGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        RefreshData()
        LoadDepartments()
    End Sub

    Private Sub LoadDepartments()
        Try
            ProfDeptCmb.Items.Clear()

            Dim query As String = "SELECT DepartmentName FROM departments"

            Using conn As MySqlConnection = moduleDB.GetConnection()
                conn.Open()
                Using cmd As New MySqlCommand(query, conn)
                    Using reader As MySqlDataReader = cmd.ExecuteReader()
                        While reader.Read()
                            ProfDeptCmb.Items.Add(reader("DepartmentName").ToString())
                        End While
                    End Using
                End Using
            End Using

        Catch ex As Exception
            MessageBox.Show("Failed to load departments: " & ex.Message)
        End Try
    End Sub

    Private Sub RefreshData()
        Dim dataTable As DataTable = dal.GetProfessors()
        EnrollProfessorGV.DataSource = dataTable
        AdjustColumnSizesByIndex()
    End Sub

    Private Sub AdjustColumnSizesByIndex()
        For colIndex As Integer = 0 To EnrollProfessorGV.Columns.Count - 1
            Dim column As DataGridViewColumn = EnrollProfessorGV.Columns(colIndex)

            Select Case colIndex
                Case 0
                    column.Width = 20
                Case 1
                    column.Width = 20
                Case 2
                    column.Width = 20
                Case 3
                    column.Width = 20
                Case 5
                    column.Width = 350
                Case Else
                    column.Width = 50
            End Select
        Next
    End Sub

    Private Sub EnrollProfessorGV_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles EnrollProfessorGV.CellClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = EnrollProfessorGV.Rows(e.RowIndex)
            ProfIDTxb.Text = row.Cells("FacultyID").Value.ToString()
            ProfFNameTxb.Text = row.Cells("Prof_FName").Value.ToString()
            ProfMNameTxb.Text = row.Cells("Prof_MName").Value.ToString()
            ProfLNameTxb.Text = row.Cells("Prof_LName").Value.ToString()
            ProfDeptCmb.Text = row.Cells("DepartmentName").Value.ToString()
            ProfPwTxb.Text = row.Cells("Password").Value.ToString()
        End If
    End Sub

    Private Sub EnrollProfBtn_Click(sender As Object, e As EventArgs) Handles EnrollProfBtn.Click
        If Not IsNullOrWhiteSpace(ProfIDTxb.Text) AndAlso
       Not IsNullOrWhiteSpace(ProfFNameTxb.Text) AndAlso
       Not IsNullOrWhiteSpace(ProfMNameTxb.Text) AndAlso
       Not IsNullOrWhiteSpace(ProfLNameTxb.Text) AndAlso
       Not IsNullOrWhiteSpace(ProfDeptCmb.Text) AndAlso
       Not IsNullOrWhiteSpace(ProfPwTxb.Text) Then

            Dim result = dal.SaveOrUpdateProfessor(ProfIDTxb.Text, ProfFNameTxb.Text, ProfMNameTxb.Text, ProfLNameTxb.Text, ProfDeptCmb.Text, ProfPwTxb.Text)

            If result Then
                MessageBox.Show("Record saved successfully!")
                RefreshData()
            Else
                MessageBox.Show("Password is already in use or a duplicate professor exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Else
            MessageBox.Show("Please fill in all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub


    Private Sub ClrBtn_Click(sender As Object, e As EventArgs) Handles ClrBtn.Click
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to clear all fields?", "Confirm Action", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
        If result = DialogResult.Yes Then
            ProfIDTxb.Text = ""
            ProfFNameTxb.Text = ""
            ProfMNameTxb.Text = ""
            ProfLNameTxb.Text = ""
            ProfDeptCmb.Text = ""
        End If
    End Sub

    Private Function IsNullOrWhiteSpace(value As String) As Boolean
        Return String.IsNullOrWhiteSpace(value)
    End Function

    Private Sub GenPwBtn_Click(sender As Object, e As EventArgs) Handles GenPwBtn.Click
        EnrollProfBtn.Enabled = True
        Dim studentNumber = ProfIDTxb.Text
        Dim firstName = ProfFNameTxb.Text
        Dim middleName = ProfMNameTxb.Text
        Dim surName = ProfLNameTxb.Text.Replace(" ", "").ToLower()
        Try
            If String.IsNullOrEmpty(studentNumber) OrElse
           String.IsNullOrEmpty(firstName) OrElse
           String.IsNullOrEmpty(middleName) OrElse
           String.IsNullOrEmpty(surName) Then
                MessageBox.Show("Please fill in all fields before generating the password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If

            Dim firstInitials = ""
            Dim firstNameParts = firstName.Split(" "c)

            For Each namePart In firstNameParts
                firstInitials &= namePart.Substring(0, 1).ToUpper
            Next
            Dim middleInitials = ""
            Dim middleNameParts = middleName.Split(" "c)
            For Each namePart In middleNameParts
                middleInitials &= namePart.Substring(0, 1).ToLower
                If middleInitials.Length >= 2 Then
                    Exit For
                End If
            Next
            Dim password = $"{surName}{firstInitials}{middleInitials}@{studentNumber}"


            ProfPwTxb.Text = password
        Catch ex As Exception
            MessageBox.Show("Failed to load departments: " & ex.Message)
        End Try


    End Sub
    Private Sub ProfIDTxb_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles ProfIDTxb.Validating
        If ProfIDTxb.Text = "" Then
        Else
            Dim pattern As String = "^\d{5}$"

            If ProfIDTxb.Text.Length < 5 Then
                MessageBox.Show("Input must be exactly 5 characters long.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                e.Cancel = True ' Prevents the focus from leaving the TextBox
                Exit Sub
            End If

            Dim isValid As Boolean = Regex.IsMatch(ProfIDTxb.Text, pattern)

            If Not isValid Then
                MessageBox.Show("Invalid input! Please use the format 00000.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                e.Cancel = True
            End If
        End If
    End Sub

    Private Sub ProfFNameTxb_TextChanged(sender As Object, e As EventArgs)
        cap(ProfFNameTxb)
    End Sub

    Private Sub ProfMNameTxb_TextChanged(sender As Object, e As EventArgs)
        cap(ProfMNameTxb)
    End Sub

    Private Sub ProfLNameTxb_TextChanged(sender As Object, e As EventArgs)
        cap(ProfLNameTxb)
    End Sub

    Private Sub ProfLNameTxb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ProfFNameTxb.KeyPress, ProfMNameTxb.KeyPress, ProfLNameTxb.KeyPress
        moduleDB.isLet(sender, e)
    End Sub

    Private Sub ProfDeptCmb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ProfDeptCmb.KeyPress
        e.Handled = True
    End Sub

    Private Sub EnrollProfessorGV_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles EnrollProfessorGV.CellContentClick

    End Sub

    Private Sub ProfLNameTxb_TextChanged_1(sender As Object, e As EventArgs) Handles ProfIDTxb.TextChanged, ProfFNameTxb.TextChanged, ProfMNameTxb.TextChanged, ProfLNameTxb.TextChanged, ProfDeptCmb.TextChanged, ProfPwTxb.TextChanged
        EnrollProfBtn.Enabled = False
    End Sub
End Class
