﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        Button1 = New Button()
        SettingsBtn = New Button()
        LogBtn = New Button()
        AssignBtn = New Button()
        EnrollBtn = New Button()
        HomeBtn = New Button()
        Label1 = New Label()
        AdminPanel = New Panel()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        Panel1.Controls.Add(Button1)
        Panel1.Controls.Add(SettingsBtn)
        Panel1.Controls.Add(LogBtn)
        Panel1.Controls.Add(AssignBtn)
        Panel1.Controls.Add(EnrollBtn)
        Panel1.Controls.Add(HomeBtn)
        Panel1.Controls.Add(Label1)
        Panel1.Location = New Point(22, 28)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(330, 1001)
        Panel1.TabIndex = 0
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        Button1.FlatAppearance.BorderSize = 0
        Button1.FlatStyle = FlatStyle.Flat
        Button1.Font = New Font("Cascadia Code", 12F)
        Button1.Location = New Point(17, 916)
        Button1.Name = "Button1"
        Button1.Size = New Size(295, 55)
        Button1.TabIndex = 6
        Button1.Text = "Logout"
        Button1.TextAlign = ContentAlignment.MiddleLeft
        Button1.UseVisualStyleBackColor = False
        ' 
        ' SettingsBtn
        ' 
        SettingsBtn.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        SettingsBtn.FlatAppearance.BorderSize = 0
        SettingsBtn.FlatStyle = FlatStyle.Flat
        SettingsBtn.Font = New Font("Cascadia Code", 12F)
        SettingsBtn.Location = New Point(17, 339)
        SettingsBtn.Name = "SettingsBtn"
        SettingsBtn.Size = New Size(295, 55)
        SettingsBtn.TabIndex = 5
        SettingsBtn.Text = "Settings"
        SettingsBtn.TextAlign = ContentAlignment.MiddleLeft
        SettingsBtn.UseVisualStyleBackColor = False
        ' 
        ' LogBtn
        ' 
        LogBtn.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        LogBtn.FlatAppearance.BorderSize = 0
        LogBtn.FlatStyle = FlatStyle.Flat
        LogBtn.Font = New Font("Cascadia Code", 12F)
        LogBtn.Location = New Point(17, 278)
        LogBtn.Name = "LogBtn"
        LogBtn.Size = New Size(295, 55)
        LogBtn.TabIndex = 4
        LogBtn.Text = "Transaction Log"
        LogBtn.TextAlign = ContentAlignment.MiddleLeft
        LogBtn.UseVisualStyleBackColor = False
        ' 
        ' AssignBtn
        ' 
        AssignBtn.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        AssignBtn.FlatAppearance.BorderSize = 0
        AssignBtn.FlatStyle = FlatStyle.Flat
        AssignBtn.Font = New Font("Cascadia Code", 12F)
        AssignBtn.Location = New Point(17, 217)
        AssignBtn.Name = "AssignBtn"
        AssignBtn.Size = New Size(295, 55)
        AssignBtn.TabIndex = 3
        AssignBtn.Text = "Assign Classes"
        AssignBtn.TextAlign = ContentAlignment.MiddleLeft
        AssignBtn.UseVisualStyleBackColor = False
        ' 
        ' EnrollBtn
        ' 
        EnrollBtn.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        EnrollBtn.FlatAppearance.BorderSize = 0
        EnrollBtn.FlatStyle = FlatStyle.Flat
        EnrollBtn.Font = New Font("Cascadia Code", 12F)
        EnrollBtn.Location = New Point(17, 156)
        EnrollBtn.Name = "EnrollBtn"
        EnrollBtn.Size = New Size(295, 55)
        EnrollBtn.TabIndex = 2
        EnrollBtn.Text = "Enroll Accounts"
        EnrollBtn.TextAlign = ContentAlignment.MiddleLeft
        EnrollBtn.UseVisualStyleBackColor = False
        ' 
        ' HomeBtn
        ' 
        HomeBtn.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        HomeBtn.FlatAppearance.BorderSize = 0
        HomeBtn.FlatStyle = FlatStyle.Flat
        HomeBtn.Font = New Font("Cascadia Code", 12F)
        HomeBtn.Location = New Point(17, 95)
        HomeBtn.Name = "HomeBtn"
        HomeBtn.Size = New Size(295, 55)
        HomeBtn.TabIndex = 1
        HomeBtn.Text = "Home"
        HomeBtn.TextAlign = ContentAlignment.MiddleLeft
        HomeBtn.UseVisualStyleBackColor = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Cascadia Mono", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(41, 27)
        Label1.Name = "Label1"
        Label1.Size = New Size(120, 45)
        Label1.TabIndex = 0
        Label1.Text = "Admin"
        ' 
        ' AdminPanel
        ' 
        AdminPanel.BackColor = Color.FromArgb(CByte(41), CByte(28), CByte(14))
        AdminPanel.Location = New Point(368, 28)
        AdminPanel.Name = "AdminPanel"
        AdminPanel.Size = New Size(1544, 1001)
        AdminPanel.TabIndex = 7
        ' 
        ' AdminForm
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(41), CByte(28), CByte(14))
        ClientSize = New Size(1924, 1055)
        Controls.Add(AdminPanel)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "AdminForm"
        StartPosition = FormStartPosition.CenterScreen
        Text = "AdminForm"
        WindowState = FormWindowState.Maximized
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents SettingsBtn As Button
    Friend WithEvents LogBtn As Button
    Friend WithEvents AssignBtn As Button
    Friend WithEvents EnrollBtn As Button
    Friend WithEvents HomeBtn As Button
    Friend WithEvents AdminPanel As Panel
    Friend WithEvents Button1 As Button
End Class
