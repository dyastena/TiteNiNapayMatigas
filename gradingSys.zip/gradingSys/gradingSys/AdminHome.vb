﻿Public Class AdminHome
    Dim dal As New DataAccessLayer()
    Dim prof As New AdminHomeProf()

    Public Sub AdminHome_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        prof.ParentForm = Me ' Correctly set ParentForm
        ShowPanel(prof)
    End Sub
    Private Sub ShowPanel(panelToShow As Form)
        AdminHomeSub.Hide()
        AdminHomeProf.Hide()

        panelToShow.TopLevel = False
        panelToShow.Parent = AdminHomePanel
        panelToShow.Dock = DockStyle.Fill
        panelToShow.Show()
    End Sub

    Private Sub StudBtn_Click(sender As Object, e As EventArgs) Handles StudBtn.Click
        HighlightActiveButton(StudBtn)
        ShowPanel(AdminHomeSub)
        AdminHomeGV.AllowUserToResizeColumns = False
        AdminHomeGV.AllowUserToResizeRows = False
        AdminHomeGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        RefreshData()
    End Sub

    Private Sub ProfBtn_Click(sender As Object, e As EventArgs) Handles ProfBtn.Click
        HighlightActiveButton(ProfBtn)
        ShowPanel(AdminHomeProf)
        AdminHomeGV.AllowUserToResizeColumns = False
        AdminHomeGV.AllowUserToResizeRows = False
        AdminHomeGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
    End Sub

    Private Sub HighlightActiveButton(activeButton As Button)
        StudBtn.BackColor = Color.Transparent
        ProfBtn.BackColor = Color.Transparent

        activeButton.BackColor = Color.Gray
    End Sub
    Private Sub HighlightActiveButton2(activeButton As Button)
        StudBtn.BackColor = Color.Transparent
        ProfBtn.BackColor = Color.Transparent

        activeButton.BackColor = Color.Gray
    End Sub

    Private Sub RefreshData()
        AdminHomeGV.DataSource = Nothing
        Dim dataTable As DataTable = dal.GetStudents()
        AdminHomeGV.DataSource = dataTable

        AdjustColumnSizesByIndex()
    End Sub
    Public Sub RefreshData2()
        AdminHomeGV.DataSource = Nothing
        Dim dataTable As DataTable = dal.GetProfessors2()
        AdminHomeGV.DataSource = dataTable

        AdjustColumnSizesByIndex2()
    End Sub
    Private Sub AdjustColumnSizesByIndex()
        For colIndex As Integer = 0 To AdminHomeGV.Columns.Count - 1
            Dim column As DataGridViewColumn = AdminHomeGV.Columns(colIndex)

            Select Case colIndex
                Case 0
                    column.Width = 30
                Case 1
                    column.Width = 30
                Case 2
                    column.Width = 30
                Case 3
                    column.Width = 30
                Case 4
                    column.Width = 20
                Case 5
                    column.Width = 20
                Case 6
                    column.Width = 20
                Case 8
                    column.Width = 200
                Case Else
                    column.Width = 50
            End Select
        Next
    End Sub
    Public Sub AdjustColumnSizesByIndex2()
        For colIndex As Integer = 0 To AdminHomeGV.Columns.Count - 1
            Dim column As DataGridViewColumn = AdminHomeGV.Columns(colIndex)

            Select Case colIndex
                Case 0
                    column.Width = 20
                Case 1
                    column.Width = 20
                Case 2
                    column.Width = 20
                Case 3
                    column.Width = 20
                Case 5
                    column.Width = 350
                Case Else
                    column.Width = 50
            End Select
        Next
    End Sub
End Class