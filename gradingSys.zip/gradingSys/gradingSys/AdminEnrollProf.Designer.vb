﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminEnrollProf
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As DataGridViewCellStyle = New DataGridViewCellStyle()
        EnrProfPnl = New Panel()
        GenPwBtn = New Button()
        Label13 = New Label()
        ProfPwTxb = New TextBox()
        ClrBtn = New Button()
        EnrollProfBtn = New Button()
        Label9 = New Label()
        ProfMNameTxb = New TextBox()
        Label12 = New Label()
        ProfLNameTxb = New TextBox()
        Label15 = New Label()
        ProfDeptCmb = New ComboBox()
        Label16 = New Label()
        ProfFNameTxb = New TextBox()
        Label18 = New Label()
        ProfIDTxb = New TextBox()
        EnrollProfessorGV = New DataGridView()
        EnrProfPnl.SuspendLayout()
        CType(EnrollProfessorGV, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' EnrProfPnl
        ' 
        EnrProfPnl.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        EnrProfPnl.Controls.Add(GenPwBtn)
        EnrProfPnl.Controls.Add(Label13)
        EnrProfPnl.Controls.Add(ProfPwTxb)
        EnrProfPnl.Controls.Add(ClrBtn)
        EnrProfPnl.Controls.Add(EnrollProfBtn)
        EnrProfPnl.Controls.Add(Label9)
        EnrProfPnl.Controls.Add(ProfMNameTxb)
        EnrProfPnl.Controls.Add(Label12)
        EnrProfPnl.Controls.Add(ProfLNameTxb)
        EnrProfPnl.Controls.Add(Label15)
        EnrProfPnl.Controls.Add(ProfDeptCmb)
        EnrProfPnl.Controls.Add(Label16)
        EnrProfPnl.Controls.Add(ProfFNameTxb)
        EnrProfPnl.Controls.Add(Label18)
        EnrProfPnl.Controls.Add(ProfIDTxb)
        EnrProfPnl.Location = New Point(52, 32)
        EnrProfPnl.Name = "EnrProfPnl"
        EnrProfPnl.Size = New Size(1436, 382)
        EnrProfPnl.TabIndex = 28
        ' 
        ' GenPwBtn
        ' 
        GenPwBtn.Font = New Font("Cascadia Code", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        GenPwBtn.Location = New Point(1187, 91)
        GenPwBtn.Name = "GenPwBtn"
        GenPwBtn.Size = New Size(174, 27)
        GenPwBtn.TabIndex = 6
        GenPwBtn.Text = "Generate Password"
        GenPwBtn.UseVisualStyleBackColor = True
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label13.Location = New Point(894, 72)
        Label13.Name = "Label13"
        Label13.Size = New Size(89, 20)
        Label13.TabIndex = 71
        Label13.Text = "Password"
        ' 
        ' ProfPwTxb
        ' 
        ProfPwTxb.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        ProfPwTxb.BorderStyle = BorderStyle.FixedSingle
        ProfPwTxb.Enabled = False
        ProfPwTxb.Font = New Font("Courier New", 10.2F)
        ProfPwTxb.Location = New Point(885, 91)
        ProfPwTxb.Name = "ProfPwTxb"
        ProfPwTxb.Size = New Size(300, 27)
        ProfPwTxb.TabIndex = 70
        ' 
        ' ClrBtn
        ' 
        ClrBtn.Font = New Font("Cascadia Code", 7.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        ClrBtn.Location = New Point(64, 231)
        ClrBtn.Name = "ClrBtn"
        ClrBtn.Size = New Size(183, 25)
        ClrBtn.TabIndex = 68
        ClrBtn.Text = "Clear all fields"
        ClrBtn.UseVisualStyleBackColor = True
        ' 
        ' EnrollProfBtn
        ' 
        EnrollProfBtn.Font = New Font("Cascadia Code", 10.2F)
        EnrollProfBtn.Location = New Point(469, 281)
        EnrollProfBtn.Name = "EnrollProfBtn"
        EnrollProfBtn.Size = New Size(535, 61)
        EnrollProfBtn.TabIndex = 7
        EnrollProfBtn.Text = "Enroll Professor"
        EnrollProfBtn.UseVisualStyleBackColor = True
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label9.Location = New Point(658, 164)
        Label9.Name = "Label9"
        Label9.Size = New Size(119, 20)
        Label9.TabIndex = 67
        Label9.Text = "Middle Name"
        ' 
        ' ProfMNameTxb
        ' 
        ProfMNameTxb.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        ProfMNameTxb.BorderStyle = BorderStyle.FixedSingle
        ProfMNameTxb.Font = New Font("Courier New", 10.2F)
        ProfMNameTxb.Location = New Point(648, 181)
        ProfMNameTxb.Name = "ProfMNameTxb"
        ProfMNameTxb.Size = New Size(356, 27)
        ProfMNameTxb.TabIndex = 3
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label12.Location = New Point(1048, 164)
        Label12.Name = "Label12"
        Label12.Size = New Size(79, 20)
        Label12.TabIndex = 65
        Label12.Text = "Surname"
        ' 
        ' ProfLNameTxb
        ' 
        ProfLNameTxb.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        ProfLNameTxb.BorderStyle = BorderStyle.FixedSingle
        ProfLNameTxb.Font = New Font("Courier New", 10.2F)
        ProfLNameTxb.Location = New Point(1041, 181)
        ProfLNameTxb.Name = "ProfLNameTxb"
        ProfLNameTxb.Size = New Size(321, 27)
        ProfLNameTxb.TabIndex = 4
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label15.Location = New Point(402, 72)
        Label15.Name = "Label15"
        Label15.Size = New Size(109, 20)
        Label15.TabIndex = 58
        Label15.Text = "Department"
        ' 
        ' ProfDeptCmb
        ' 
        ProfDeptCmb.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        ProfDeptCmb.FlatStyle = FlatStyle.Flat
        ProfDeptCmb.Font = New Font("Courier New", 10.2F)
        ProfDeptCmb.FormattingEnabled = True
        ProfDeptCmb.Items.AddRange(New Object() {"CCS", "CBA"})
        ProfDeptCmb.Location = New Point(396, 91)
        ProfDeptCmb.Name = "ProfDeptCmb"
        ProfDeptCmb.Size = New Size(461, 28)
        ProfDeptCmb.TabIndex = 5
        ' 
        ' Label16
        ' 
        Label16.AutoSize = True
        Label16.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label16.Location = New Point(73, 162)
        Label16.Name = "Label16"
        Label16.Size = New Size(109, 20)
        Label16.TabIndex = 57
        Label16.Text = "First Name"
        ' 
        ' ProfFNameTxb
        ' 
        ProfFNameTxb.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        ProfFNameTxb.BorderStyle = BorderStyle.FixedSingle
        ProfFNameTxb.Font = New Font("Courier New", 10.2F)
        ProfFNameTxb.Location = New Point(64, 181)
        ProfFNameTxb.Name = "ProfFNameTxb"
        ProfFNameTxb.Size = New Size(533, 27)
        ProfFNameTxb.TabIndex = 2
        ' 
        ' Label18
        ' 
        Label18.AutoSize = True
        Label18.Font = New Font("Courier New", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label18.Location = New Point(72, 73)
        Label18.Name = "Label18"
        Label18.Size = New Size(109, 20)
        Label18.TabIndex = 52
        Label18.Text = "Faculty ID"
        ' 
        ' ProfIDTxb
        ' 
        ProfIDTxb.BackColor = Color.FromArgb(CByte(225), CByte(212), CByte(194))
        ProfIDTxb.BorderStyle = BorderStyle.FixedSingle
        ProfIDTxb.Font = New Font("Courier New", 10.2F)
        ProfIDTxb.Location = New Point(63, 92)
        ProfIDTxb.MaxLength = 5
        ProfIDTxb.Name = "ProfIDTxb"
        ProfIDTxb.Size = New Size(311, 27)
        ProfIDTxb.TabIndex = 1
        ' 
        ' EnrollProfessorGV
        ' 
        EnrollProfessorGV.AllowUserToAddRows = False
        EnrollProfessorGV.AllowUserToDeleteRows = False
        EnrollProfessorGV.AllowUserToResizeColumns = False
        EnrollProfessorGV.AllowUserToResizeRows = False
        EnrollProfessorGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        EnrollProfessorGV.BorderStyle = BorderStyle.None
        DataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = SystemColors.Control
        DataGridViewCellStyle1.Font = New Font("Segoe UI", 7.20000029F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        DataGridViewCellStyle1.ForeColor = SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = DataGridViewTriState.True
        EnrollProfessorGV.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        EnrollProfessorGV.ColumnHeadersHeight = 29
        EnrollProfessorGV.Location = New Point(52, 447)
        EnrollProfessorGV.Name = "EnrollProfessorGV"
        EnrollProfessorGV.RowHeadersWidth = 51
        EnrollProfessorGV.Size = New Size(1436, 388)
        EnrollProfessorGV.TabIndex = 68
        ' 
        ' AdminEnrollProf
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(41), CByte(28), CByte(14))
        ClientSize = New Size(1546, 835)
        Controls.Add(EnrollProfessorGV)
        Controls.Add(EnrProfPnl)
        FormBorderStyle = FormBorderStyle.None
        Name = "AdminEnrollProf"
        Text = "AdminEnrollProf"
        EnrProfPnl.ResumeLayout(False)
        EnrProfPnl.PerformLayout()
        CType(EnrollProfessorGV, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents EnrProfPnl As Panel
    Friend WithEvents EnrollProfBtn As Button
    Friend WithEvents Label9 As Label
    Friend WithEvents ProfMNameTxb As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents ProfLNameTxb As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents ProfDeptCmb As ComboBox
    Friend WithEvents Label16 As Label
    Friend WithEvents ProfFNameTxb As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents ProfIDTxb As TextBox
    Friend WithEvents EnrollProfessorGV As DataGridView
    Friend WithEvents ClrBtn As Button
    Friend WithEvents GenPwBtn As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents ProfPwTxb As TextBox
End Class
