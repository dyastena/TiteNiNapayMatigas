﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminHomeSub
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Button4 = New Button()
        SuspendLayout()
        ' 
        ' Button4
        ' 
        Button4.Font = New Font("Cascadia Code", 10.2F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Button4.Location = New Point(3, 2)
        Button4.Name = "Button4"
        Button4.Size = New Size(1517, 58)
        Button4.TabIndex = 17
        Button4.Text = "Generate report"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' AdminHomeStud
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(41), CByte(28), CByte(14))
        ClientSize = New Size(1520, 62)
        Controls.Add(Button4)
        FormBorderStyle = FormBorderStyle.None
        Name = "AdminHomeStud"
        Text = "AdminHomeStud"
        ResumeLayout(False)
    End Sub

    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
End Class
